import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static Connection connection;
    private static SellerDAO sellerDAO;
    private static BuyerDAO buyerDAO;
    private static ProductDAO productDAO;
    private static SaleDAO saleDAO;

    public static void main(String[] args) {
        try {
            // Establish the database connection
            connection = DatabaseConnection.getConnection();

            // Initialize DAOs
            sellerDAO = new SellerDAO(connection);
            buyerDAO = new BuyerDAO(connection);
            productDAO = new ProductDAO(connection);
            saleDAO = new SaleDAO(connection);

            // Main program loop
            Scanner scanner = new Scanner(System.in);
            boolean running = true;

            while (running) {
                displayMenu();
                int choice = scanner.nextInt();
                scanner.nextLine();  // Consume the newline character

                switch (choice) {
                    case 1:
                        // Display all sellers
                        displayAllSellers();
                        break;

                    case 2:
                        // Display all buyers
                        displayAllBuyers();
                        break;

                    case 3:
                        // Display all products
                        displayAllProducts();
                        break;

                    case 4:
                        // Display all sales
                        displayAllSales();
                        break;

                    case 5:
                        // Add a new seller
                        addSeller(scanner);
                        break;

                    case 6:
                        // Add a new buyer
                        addBuyer(scanner);
                        break;

                    case 7:
                        // Add a new product
                        addProduct(scanner);
                        break;

                    case 8:
                        // Add a new sale
                        addSale(scanner);
                        break;

                    case 9:
                        // Update a seller's information
                        updateSeller(scanner);
                        break;

                    case 10:
                        // Update a buyer's information
                        updateBuyer(scanner);
                        break;

                    case 11:
                        // Update a product's information
                        updateProduct(scanner);
                        break;

                    case 12:
                        // Update a sale
                        updateSale(scanner);
                        break;

                    case 13:
                        // Delete a seller
                        deleteSeller(scanner);
                        break;

                    case 14:
                        // Delete a buyer
                        deleteBuyer(scanner);
                        break;

                    case 15:
                        // Delete a product
                        deleteProduct(scanner);
                        break;

                    case 16:
                        // Delete a sale
                        deleteSale(scanner);
                        break;

                    case 17:
                        // Exit the application
                        System.out.println("Exiting the application...");
                        running = false;
                        break;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\nSales Management System");
        System.out.println("1. Display all sellers");
        System.out.println("2. Display all buyers");
        System.out.println("3. Display all products");
        System.out.println("4. Display all sales");
        System.out.println("5. Add a new seller");
        System.out.println("6. Add a new buyer");
        System.out.println("7. Add a new product");
        System.out.println("8. Add a new sale");
        System.out.println("9. Update a seller");
        System.out.println("10. Update a buyer");
        System.out.println("11. Update a product");
        System.out.println("12. Update a sale");
        System.out.println("13. Delete a seller");
        System.out.println("14. Delete a buyer");
        System.out.println("15. Delete a product");
        System.out.println("16. Delete a sale");
        System.out.println("17. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void displayAllSellers() {
        List<Seller> sellers = sellerDAO.getAllSellers();
        if (sellers.isEmpty()) {
            System.out.println("No sellers found.");
        } else {
            System.out.println("\nSellers:");
            for (Seller seller : sellers) {
                System.out.println(seller);
            }
        }
    }

    private static void displayAllBuyers() {
        List<Buyer> buyers = buyerDAO.getAllBuyers();
        if (buyers.isEmpty()) {
            System.out.println("No buyers found.");
        } else {
            System.out.println("\nBuyers:");
            for (Buyer buyer : buyers) {
                System.out.println(buyer);
            }
        }
    }

    private static void displayAllProducts() {
        List<Product> products = productDAO.getAllProducts();
        if (products.isEmpty()) {
            System.out.println("No products found.");
        } else {
            System.out.println("\nProducts:");
            for (Product product : products) {
                System.out.println(product);
            }
        }
    }

    private static void displayAllSales() {
        List<Sale> sales = saleDAO.getAllSales();
        if (sales.isEmpty()) {
            System.out.println("No sales found.");
        } else {
            System.out.println("\nSales:");
            for (Sale sale : sales) {
                System.out.println(sale);
            }
        }
    }

    private static void addSeller(Scanner scanner) {
        System.out.print("Enter seller's name: ");
        String name = scanner.nextLine();
        System.out.print("Enter seller's phone: ");
        String phone = scanner.nextLine();
        System.out.print("Enter seller's email: ");
        String email = scanner.nextLine();

        Seller seller = new Seller(0, name, phone, email);
        if (sellerDAO.addSeller(seller)) {
            System.out.println("Seller added successfully.");
        } else {
            System.out.println("Failed to add seller.");
        }
    }

    private static void addBuyer(Scanner scanner) {
        System.out.print("Enter buyer's name: ");
        String name = scanner.nextLine();
        System.out.print("Enter buyer's phone: ");
        String phone = scanner.nextLine();
        System.out.print("Enter buyer's email: ");
        String email = scanner.nextLine();

        Buyer buyer = new Buyer(0, name, phone, email);
        if (buyerDAO.addBuyer(buyer)) {
            System.out.println("Buyer added successfully.");
        } else {
            System.out.println("Failed to add buyer.");
        }
    }

    private static void addProduct(Scanner scanner) {
        System.out.print("Enter product name: ");
        String name = scanner.nextLine();
        System.out.print("Enter product price: ");
        double price = scanner.nextDouble();
        scanner.nextLine();  // Consume newline

        Product product = new Product(0, name, price);
        if (productDAO.addProduct(product)) {
            System.out.println("Product added successfully.");
        } else {
            System.out.println("Failed to add product.");
        }
    }

    private static void addSale(Scanner scanner) {
        System.out.print("Enter seller ID: ");
        int sellerId = scanner.nextInt();
        System.out.print("Enter buyer ID: ");
        int buyerId = scanner.nextInt();
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        System.out.print("Enter sale price: ");
        double salePrice = scanner.nextDouble();
        scanner.nextLine();  // Consume newline
        System.out.print("Enter sale date (YYYY-MM-DD): ");
        String saleDate = scanner.nextLine();

        Sale sale = new Sale(0, sellerId, buyerId, productId, salePrice, LocalDate.parse(saleDate));
        if (saleDAO.addSale(sale)) {
            System.out.println("Sale added successfully.");
        } else {
            System.out.println("Failed to add sale.");
        }
    }

    private static void updateSeller(Scanner scanner) {
        System.out.print("Enter seller ID to update: ");
        int sellerId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.print("Enter new seller's name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new seller's phone: ");
        String phone = scanner.nextLine();
        System.out.print("Enter new seller's email: ");
        String email = scanner.nextLine();

        Seller seller = new Seller(sellerId, name, phone, email);
        if (sellerDAO.updateSeller(seller)) {
            System.out.println("Seller updated successfully.");
        } else {
            System.out.println("Failed to update seller.");
        }
    }

    private static void updateBuyer(Scanner scanner) {
        System.out.print("Enter buyer ID to update: ");
        int buyerId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.print("Enter new buyer's name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new buyer's phone: ");
        String phone = scanner.nextLine();
        System.out.print("Enter new buyer's email: ");
        String email = scanner.nextLine();

        Buyer buyer = new Buyer(buyerId, name, phone, email);
        if (buyerDAO.updateBuyer(buyer)) {
            System.out.println("Buyer updated successfully.");
        } else {
            System.out.println("Failed to update buyer.");
        }
    }

    private static void updateProduct(Scanner scanner) {
        System.out.print("Enter product ID to update: ");
        int productId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.print("Enter new product name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new product price: ");
        double price = scanner.nextDouble();

        Product product = new Product(productId, name, price);
        if (productDAO.updateProduct(product)) {
            System.out.println("Product updated successfully.");
        } else {
            System.out.println("Failed to update product.");
        }
    }

    private static void updateSale(Scanner scanner) {
        System.out.print("Enter sale ID to update: ");
        int saleId = scanner.nextInt();
        System.out.print("Enter new sale price: ");
        double salePrice = scanner.nextDouble();
        scanner.nextLine();  // Consume newline
        System.out.print("Enter new sale date (YYYY-MM-DD): ");
        String saleDate = scanner.nextLine();

        Sale sale = new Sale(0, saleId, 0, 0, 0, LocalDate.parse(saleDate));
        if (saleDAO.updateSale(sale)) {
            System.out.println("Sale updated successfully.");
        } else {
            System.out.println("Failed to update sale.");
        }
    }

    private static void deleteSeller(Scanner scanner) {
        System.out.print("Enter seller ID to delete: ");
        int sellerId = scanner.nextInt();
        if (sellerDAO.deleteSeller(sellerId)) {
            System.out.println("Seller deleted successfully.");
        } else {
            System.out.println("Failed to delete seller.");
        }
    }

    private static void deleteBuyer(Scanner scanner) {
        System.out.print("Enter buyer ID to delete: ");
        int buyerId = scanner.nextInt();
        if (buyerDAO.deleteBuyer(buyerId)) {
            System.out.println("Buyer deleted successfully.");
        } else {
            System.out.println("Failed to delete buyer.");
        }
    }

    private static void deleteProduct(Scanner scanner) {
        System.out.print("Enter product ID to delete: ");
        int productId = scanner.nextInt();
        if (productDAO.deleteProduct(productId)) {
            System.out.println("Product deleted successfully.");
        } else {
            System.out.println("Failed to delete product.");
        }
    }

    private static void deleteSale(Scanner scanner) {
        System.out.print("Enter sale ID to delete: ");
        int saleId = scanner.nextInt();
        if (saleDAO.deleteSale(saleId)) {
            System.out.println("Sale deleted successfully.");
        } else {
            System.out.println("Failed to delete sale.");
        }
    }
}