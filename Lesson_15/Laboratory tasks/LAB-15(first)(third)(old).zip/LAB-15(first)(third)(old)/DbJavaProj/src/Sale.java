
import java.time.LocalDate;

public class Sale {

    private int id;
    private int salespersonId;
    private int customerId;
    private int productId;
    private double salePrice;
    private LocalDate saleDate;

    // Constructor
    public Sale(int id, int salespersonId, int customerId, int productId, double salePrice, LocalDate saleDate) {
        this.id = id;
        this.salespersonId = salespersonId;
        this.customerId = customerId;
        this.productId = productId;
        this.salePrice = salePrice;
        this.saleDate = saleDate;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSalespersonId() {
        return salespersonId;
    }

    public void setSalespersonId(int salespersonId) {
        this.salespersonId = salespersonId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public double getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(double salePrice) {
        this.salePrice = salePrice;
    }

    public LocalDate getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(LocalDate saleDate) {
        this.saleDate = saleDate;
    }
}