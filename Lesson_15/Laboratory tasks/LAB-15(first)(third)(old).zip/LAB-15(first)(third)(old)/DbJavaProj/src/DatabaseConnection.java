import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/your_database_name"; // Replace with your database URL
    private static final String USER = "your_database_user"; // Replace with your database username
    private static final String PASSWORD = "your_database_password"; // Replace with your database password
    private static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver"; // For MySQL JDBC driver

    // Singleton instance
    private static Connection connection;

    // Private constructor to prevent instantiation
    private DatabaseConnection() {
    }

    // Method to establish and return a database connection
    public static Connection getConnection() {
        if (connection == null) {
            try {
                // Load JDBC driver (only needed for some databases like MySQL)
                Class.forName(DRIVER_CLASS);

                // Establish the connection to the database
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
                throw new RuntimeException("Error connecting to the database", e);
            }
        }
        return connection;
    }

    // Method to close the connection (recommended to be called in finally blocks)
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null; // Reset the connection to null
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Check if the connection is active
    public static boolean isConnectionValid() {
        if (connection != null) {
            try {
                return connection.isValid(2); // Timeout in seconds
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    // Optional: You can implement additional utility methods for specific use cases, 
    // like getting the database metadata, starting transactions, etc.
}