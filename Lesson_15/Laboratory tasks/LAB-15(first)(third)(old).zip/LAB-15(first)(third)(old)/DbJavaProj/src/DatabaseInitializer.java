import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseInitializer {

    private Connection connection;

    // Constructor to accept the database connection
    public DatabaseInitializer(Connection connection) {
        this.connection = connection;
    }

    // Method to create the necessary tables
    public void initializeDatabase() {
        // SQL query to create the 'sellers' table
        String createSellersTable = """
                CREATE TABLE IF NOT EXISTS sellers (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    contact_phone VARCHAR(20),
                    contact_email VARCHAR(100)
                );
                """;

        // SQL query to create the 'buyers' table
        String createBuyersTable = """
                CREATE TABLE IF NOT EXISTS buyers (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    contact_phone VARCHAR(20),
                    contact_email VARCHAR(100)
                );
                """;

        // SQL query to create the 'products' table
        String createProductsTable = """
                CREATE TABLE IF NOT EXISTS products (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    price DOUBLE NOT NULL
                );
                """;

        // SQL query to create the 'sales' table
        String createSalesTable = """
                CREATE TABLE IF NOT EXISTS sales (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    seller_id INT NOT NULL,
                    buyer_id INT NOT NULL,
                    product_id INT NOT NULL,
                    sale_price DOUBLE NOT NULL,
                    sale_date DATE NOT NULL,
                    FOREIGN KEY (seller_id) REFERENCES sellers(id),
                    FOREIGN KEY (buyer_id) REFERENCES buyers(id),
                    FOREIGN KEY (product_id) REFERENCES products(id)
                );
                """;

        // Execute all the queries to create the tables
        try (Statement statement = connection.createStatement()) {
            // Creating sellers table
            statement.executeUpdate(createSellersTable);
            // Creating buyers table
            statement.executeUpdate(createBuyersTable);
            // Creating products table
            statement.executeUpdate(createProductsTable);
            // Creating sales table
            statement.executeUpdate(createSalesTable);
            System.out.println("Database tables created successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error initializing database: " + e.getMessage());
        }
    }

    // Method to insert some sample data into the database (optional)
    public void insertSampleData() {
        // Insert sample sellers
        String insertSellers = """
                INSERT INTO sellers (name, contact_phone, contact_email)
                VALUES
                    ('John Doe', '123-456-7890', 'john@example.com'),
                    ('Jane Smith', '987-654-3210', 'jane@example.com');
                """;

        // Insert sample buyers
        String insertBuyers = """
                INSERT INTO buyers (name, contact_phone, contact_email)
                VALUES
                    ('Alice Johnson', '555-1234', 'alice@example.com'),
                    ('Bob Brown', '555-5678', 'bob@example.com');
                """;

        // Insert sample products
        String insertProducts = """
                INSERT INTO products (name, price)
                VALUES
                    ('Product 1', 10.99),
                    ('Product 2', 25.50);
                """;

        // Insert sample sales
        String insertSales = """
                INSERT INTO sales (seller_id, buyer_id, product_id, sale_price, sale_date)
                VALUES
                    (1, 1, 1, 10.99, '2025-02-05'),
                    (2, 2, 2, 25.50, '2025-02-05');
                """;

        // Execute the queries to insert sample data
        try (PreparedStatement stmt = connection.prepareStatement(insertSellers)) {
            stmt.executeUpdate();
            try (PreparedStatement stmt2 = connection.prepareStatement(insertBuyers)) {
                stmt2.executeUpdate();
                try (PreparedStatement stmt3 = connection.prepareStatement(insertProducts)) {
                    stmt3.executeUpdate();
                    try (PreparedStatement stmt4 = connection.prepareStatement(insertSales)) {
                        stmt4.executeUpdate();
                        System.out.println("Sample data inserted successfully!");
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to initialize the database and insert sample data
    public void initialize() {
        initializeDatabase();
        insertSampleData(); // Optional: Insert sample data after tables are created
    }

}