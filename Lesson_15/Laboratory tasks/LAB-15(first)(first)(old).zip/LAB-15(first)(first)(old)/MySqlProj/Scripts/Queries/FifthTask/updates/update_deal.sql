UPDATE deals
SET product_name = ""
WHERE id = 1