UPDATE buyers
SET name = ""
WHERE id = 1