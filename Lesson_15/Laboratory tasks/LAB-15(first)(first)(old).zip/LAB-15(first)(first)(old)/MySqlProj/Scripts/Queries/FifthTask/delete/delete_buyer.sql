DELETE FROM buyers
WHERE id = 1