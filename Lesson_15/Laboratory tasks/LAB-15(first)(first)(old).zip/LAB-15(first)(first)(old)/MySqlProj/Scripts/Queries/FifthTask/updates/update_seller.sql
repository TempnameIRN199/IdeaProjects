UPDATE sellers
SET name = ""
WHERE id = 1