DELETE FROM deals
WHERE id = 1 