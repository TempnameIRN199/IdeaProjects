DELETE FROM sellers
WHERE id = 1