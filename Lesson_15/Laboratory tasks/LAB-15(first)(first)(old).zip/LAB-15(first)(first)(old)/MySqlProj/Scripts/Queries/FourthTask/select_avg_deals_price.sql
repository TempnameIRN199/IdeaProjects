SELECT AVG(deals.price) AS avg_deal_amount
FROM deals