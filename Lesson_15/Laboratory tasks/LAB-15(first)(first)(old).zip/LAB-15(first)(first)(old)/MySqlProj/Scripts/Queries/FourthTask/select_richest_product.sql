SELECT deals.product_name , COUNT(*) AS number_of_purchases
FROM deals
GROUP BY deals.product_name
ORDER BY number_of_purchases DESC
LIMIT 1