SELECT
	sellers.name, SUM(deals.price) AS total_amount

FROM deals
INNER JOIN sellers ON deals.seller_id = sellers.id

GROUP BY sellers.name

ORDER BY total_amount DESC
LIMIT 1
