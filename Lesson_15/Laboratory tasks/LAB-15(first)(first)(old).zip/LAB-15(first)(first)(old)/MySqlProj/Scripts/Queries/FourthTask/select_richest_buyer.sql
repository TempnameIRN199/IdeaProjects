SELECT
	buyers.name,
	SUM(deals.price) AS total_amount
	
FROM deals
INNER JOIN buyers ON deals.buyer_id = buyers.id

GROUP BY buyers.name

ORDER BY total_amount DESC
LIMIT 1