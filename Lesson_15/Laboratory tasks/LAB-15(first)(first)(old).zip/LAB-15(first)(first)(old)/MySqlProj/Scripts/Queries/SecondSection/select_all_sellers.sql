SELECT *
FROM sellers