SELECT *
FROM deals