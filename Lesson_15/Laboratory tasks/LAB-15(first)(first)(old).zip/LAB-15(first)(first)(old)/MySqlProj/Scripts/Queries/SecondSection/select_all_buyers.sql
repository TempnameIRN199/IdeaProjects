SELECT *
FROM buyers