SELECT *
FROM deals
INNER JOIN buyers ON deals.buyer_id = buyers.id
WHERE buyers.name = "John Doe"