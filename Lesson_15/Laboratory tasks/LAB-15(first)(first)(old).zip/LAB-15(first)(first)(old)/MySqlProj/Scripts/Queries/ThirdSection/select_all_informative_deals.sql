SELECT
	buyers.name AS buyer_name,
	sellers.name AS seller_name,
	product_name,
	price
FROM deals
INNER JOIN buyers ON deals.buyer_id = buyers.id
INNER JOIN sellers ON deals.seller_id = sellers.id
