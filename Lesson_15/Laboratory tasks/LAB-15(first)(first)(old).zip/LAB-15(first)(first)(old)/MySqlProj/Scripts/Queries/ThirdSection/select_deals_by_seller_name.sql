SELECT *
FROM deals
INNER JOIN sellers ON deals.seller_id = sellers.id
WHERE sellers.name = "Alice Johnson"
