SELECT *
FROM deals
WHERE date = ""