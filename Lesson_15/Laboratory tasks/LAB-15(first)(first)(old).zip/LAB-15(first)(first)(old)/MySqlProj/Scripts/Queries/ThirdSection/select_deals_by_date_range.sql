SELECT *
FROM deals
WHERE date BETWEEN "" AND ""