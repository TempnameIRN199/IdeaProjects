INSERT INTO buyers (name, telephone, email) VALUES
('John Doe', '111-222-3333', 'john.doe@example.com'),
('Emma Brown', '444-555-6666', 'emma.brown@example.com'),
('Michael Green', '777-888-9999', 'michael.green@example.com'),
('Sophia Davis', '123-456-7891', 'sophia.davis@example.com'),
('William Johnson', '234-567-8901', 'william.johnson@example.com'),
('Olivia Wilson', '345-678-9012', 'olivia.wilson@example.com'),
('James Taylor', '456-789-0123', 'james.taylor@example.com');