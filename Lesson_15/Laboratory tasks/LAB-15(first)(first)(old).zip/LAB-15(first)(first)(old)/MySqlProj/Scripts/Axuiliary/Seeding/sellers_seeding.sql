INSERT INTO sellers (name, telephone, email) VALUES
('Alice Johnson', '123-456-7890', 'alice.johnson@example.com'),
('Bob Smith', '987-654-3210', 'bob.smith@example.com'),
('Carol White', '555-123-4567', 'carol.white@example.com');