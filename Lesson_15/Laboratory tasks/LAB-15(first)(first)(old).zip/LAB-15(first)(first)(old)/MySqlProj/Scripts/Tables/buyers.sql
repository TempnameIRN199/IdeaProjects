CREATE TABLE buyers
(
	id SMALLINT AUTO_INCREMENT,
	name VARCHAR(64) NOT NULL,
	telephone VARCHAR(64) NOT NULL,
	email VARCHAR(64) NOT NULL,
	
	PRIMARY KEY (id),
	
	CHECK (name <> ""),
	CHECK (telephone <> ""),
	CHECK (email <> "")
)