CREATE TABLE deals
(
	id INTEGER AUTO_INCREMENT,
	product_name VARCHAR(64) NOT NULL,
	price FLOAT NOT NULL,
	date DATETIME NOT NULL,
	
	buyer_id SMALLINT NOT NULL,
	seller_id SMALLINT NOT NULL,
	
	PRIMARY KEY (id),
	FOREIGN KEY (buyer_id) REFERENCES buyers(id),
	FOREIGN KEY (seller_id) REFERENCES sellers(id),
	
	CHECK (product_name <> ""),
	CHECK (price >= 0.0)
)