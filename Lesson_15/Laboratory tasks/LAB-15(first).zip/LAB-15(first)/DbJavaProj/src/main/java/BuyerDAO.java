import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BuyerDAO {

    private Connection connection;

    // Constructor that accepts a database connection
    public BuyerDAO(Connection connection) {
        this.connection = connection;
    }

    // Create a new buyer
    public boolean addBuyer(Buyer buyer) {
        String query = "INSERT INTO buyers (name, phone, email) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, buyer.getName());
            stmt.setString(2, buyer.getPhone());
            stmt.setString(3, buyer.getEmail());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Update an existing buyer
    public boolean updateBuyer(Buyer buyer) {
        String query = "UPDATE buyers SET name = ?, phone = ?, email = ? WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, buyer.getName());
            stmt.setString(2, buyer.getPhone());
            stmt.setString(3, buyer.getEmail());
            stmt.setInt(4, buyer.getId());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete a buyer by ID
    public boolean deleteBuyer(int buyerId) {
        String query = "DELETE FROM buyers WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, buyerId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Retrieve a buyer by ID
    public Buyer getBuyerById(int buyerId) {
        String query = "SELECT * FROM buyers WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, buyerId);
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                return new Buyer(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("phone"),
                        resultSet.getString("email")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Retrieve all buyers
    public List<Buyer> getAllBuyers() {
        List<Buyer> buyers = new ArrayList<>();
        String query = "SELECT * FROM buyers";

        try (Statement stmt = connection.createStatement();
             ResultSet resultSet = stmt.executeQuery(query)) {

            while (resultSet.next()) {
                Buyer buyer = new Buyer(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("phone"),
                        resultSet.getString("email")
                );
                buyers.add(buyer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return buyers;
    }

    // Retrieve buyers who made purchases within a specific date range
    public List<Buyer> getBuyersByPurchaseDateRange(String startDate, String endDate) {
        List<Buyer> buyers = new ArrayList<>();
        String query = "SELECT DISTINCT b.id, b.name, b.phone, b.email " +
                "FROM buyers b JOIN sales sa ON b.id = sa.customer_id " +
                "WHERE sa.sale_date BETWEEN ? AND ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDate(1, Date.valueOf(startDate)); // Convert String to SQL Date
            stmt.setDate(2, Date.valueOf(endDate));   // Convert String to SQL Date
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Buyer buyer = new Buyer(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("phone"),
                        resultSet.getString("email")
                );
                buyers.add(buyer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return buyers;
    }

    // Retrieve the total amount spent by a buyer within a specific date range
    public double getTotalAmountSpentByBuyer(int buyerId, String startDate, String endDate) {
        String query = "SELECT SUM(sa.sale_price) AS total_spent " +
                "FROM sales sa WHERE sa.customer_id = ? " +
                "AND sa.sale_date BETWEEN ? AND ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, buyerId);
            stmt.setDate(2, Date.valueOf(startDate)); // Convert String to SQL Date
            stmt.setDate(3, Date.valueOf(endDate));   // Convert String to SQL Date
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                return resultSet.getDouble("total_spent");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    // Retrieve the most frequent buyer based on the number of purchases
    public Buyer getMostFrequentBuyer() {
        String query = "SELECT b.id, b.name, b.phone, b.email, COUNT(sa.id) AS purchase_count " +
                "FROM buyers b JOIN sales sa ON b.id = sa.customer_id " +
                "GROUP BY b.id ORDER BY purchase_count DESC LIMIT 1";

        try (Statement stmt = connection.createStatement();
             ResultSet resultSet = stmt.executeQuery(query)) {

            if (resultSet.next()) {
                return new Buyer(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("phone"),
                        resultSet.getString("email")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Retrieve the buyer who spent the most within a specific date range
    public Buyer getHighestSpendingBuyer(String startDate, String endDate) {
        String query = "SELECT b.id, b.name, b.phone, b.email, SUM(sa.sale_price) AS total_spent " +
                "FROM buyers b JOIN sales sa ON b.id = sa.customer_id " +
                "WHERE sa.sale_date BETWEEN ? AND ? " +
                "GROUP BY b.id ORDER BY total_spent DESC LIMIT 1";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDate(1, Date.valueOf(startDate)); // Convert String to SQL Date
            stmt.setDate(2, Date.valueOf(endDate));   // Convert String to SQL Date
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                return new Buyer(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("phone"),
                        resultSet.getString("email")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Retrieve all purchases made by a specific buyer
    public List<Buyer> getPurchasesByBuyer(int buyerId) {
        List<Buyer> buyers = new ArrayList<>();
        String query = "SELECT b.id, b.name, b.phone, b.email " +
                "FROM buyers b JOIN sales sa ON b.id = sa.customer_id " +
                "WHERE b.id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, buyerId);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Buyer buyer = new Buyer(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("phone"),
                        resultSet.getString("email")
                );
                buyers.add(buyer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return buyers;
    }
}