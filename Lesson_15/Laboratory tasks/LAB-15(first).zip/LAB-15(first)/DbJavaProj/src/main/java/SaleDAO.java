import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class SaleDAO {

    private Connection connection;

    // Constructor that accepts a database connection
    public SaleDAO(Connection connection) {
        this.connection = connection;
    }

    // Create a new sale record
    public boolean addSale(Sale sale) {
        String query = "INSERT INTO sales (seller_id, buyer_id, product_id, sale_price, sale_date) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, sale.getSalespersonId());
            stmt.setInt(2, sale.getCustomerId());
            stmt.setInt(3, sale.getProductId());
            stmt.setDouble(4, sale.getSalePrice());
            stmt.setDate(5, Date.valueOf(sale.getSaleDate())); // Convert LocalDate to SQL Date
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Update an existing sale record
    public boolean updateSale(Sale sale) {
        String query = "UPDATE sales SET seller_id = ?, buyer_id = ?, product_id = ?, sale_price = ?, sale_date = ? WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, sale.getSalespersonId());
            stmt.setInt(2, sale.getCustomerId());
            stmt.setInt(3, sale.getProductId());
            stmt.setDouble(4, sale.getSalePrice());
            stmt.setDate(5, Date.valueOf(sale.getSaleDate())); // Convert LocalDate to SQL Date
            stmt.setInt(6, sale.getId());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete a sale record by ID
    public boolean deleteSale(int saleId) {
        String query = "DELETE FROM sales WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, saleId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Retrieve a sale by ID
    public Sale getSaleById(int saleId) {
        String query = "SELECT * FROM sales WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, saleId);
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                return new Sale(
                        resultSet.getInt("id"),
                        resultSet.getInt("seller_id"),
                        resultSet.getInt("buyer_id"),
                        resultSet.getInt("product_id"),
                        resultSet.getDouble("sale_price"),
                        resultSet.getDate("sale_date").toLocalDate() // Convert SQL Date to LocalDate
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Retrieve all sales
    public List<Sale> getAllSales() {
        List<Sale> sales = new ArrayList<>();
        String query = "SELECT * FROM sales";

        try (Statement stmt = connection.createStatement();
             ResultSet resultSet = stmt.executeQuery(query)) {

            while (resultSet.next()) {
                Sale sale = new Sale(
                        resultSet.getInt("id"),
                        resultSet.getInt("seller_id"),
                        resultSet.getInt("buyer_id"),
                        resultSet.getInt("product_id"),
                        resultSet.getDouble("sale_price"),
                        resultSet.getDate("sale_date").toLocalDate() // Convert SQL Date to LocalDate
                );
                sales.add(sale);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sales;
    }

    // Retrieve sales by a specific seller
    public List<Sale> getSalesBySeller(int sellerId) {
        List<Sale> sales = new ArrayList<>();
        String query = "SELECT * FROM sales WHERE seller_id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, sellerId);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Sale sale = new Sale(
                        resultSet.getInt("id"),
                        resultSet.getInt("seller_id"),
                        resultSet.getInt("buyer_id"),
                        resultSet.getInt("product_id"),
                        resultSet.getDouble("sale_price"),
                        resultSet.getDate("sale_date").toLocalDate() // Convert SQL Date to LocalDate
                );
                sales.add(sale);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sales;
    }

    // Retrieve sales by a specific buyer
    public List<Sale> getSalesByBuyer(int buyerId) {
        List<Sale> sales = new ArrayList<>();
        String query = "SELECT * FROM sales WHERE buyer_id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, buyerId);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Sale sale = new Sale(
                        resultSet.getInt("id"),
                        resultSet.getInt("seller_id"),
                        resultSet.getInt("buyer_id"),
                        resultSet.getInt("product_id"),
                        resultSet.getDouble("sale_price"),
                        resultSet.getDate("sale_date").toLocalDate() // Convert SQL Date to LocalDate
                );
                sales.add(sale);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sales;
    }

    // Retrieve sales in a specific date range
    public List<Sale> getSalesInDateRange(String startDate, String endDate) {
        List<Sale> sales = new ArrayList<>();
        String query = "SELECT * FROM sales WHERE sale_date BETWEEN ? AND ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDate(1, Date.valueOf(startDate)); // Convert String to SQL Date
            stmt.setDate(2, Date.valueOf(endDate));   // Convert String to SQL Date
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Sale sale = new Sale(
                        resultSet.getInt("id"),
                        resultSet.getInt("seller_id"),
                        resultSet.getInt("buyer_id"),
                        resultSet.getInt("product_id"),
                        resultSet.getDouble("sale_price"),
                        resultSet.getDate("sale_date").toLocalDate() // Convert SQL Date to LocalDate
                );
                sales.add(sale);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sales;
    }

    // Retrieve the total sales amount in a given date range
    public double getTotalSalesAmountInDateRange(String startDate, String endDate) {
        String query = "SELECT SUM(sale_price) AS total_sales FROM sales WHERE sale_date BETWEEN ? AND ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDate(1, Date.valueOf(startDate)); // Convert String to SQL Date
            stmt.setDate(2, Date.valueOf(endDate));   // Convert String to SQL Date
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                return resultSet.getDouble("total_sales");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    // Retrieve the sales made by a specific product
    public List<Sale> getSalesByProduct(int productId) {
        List<Sale> sales = new ArrayList<>();
        String query = "SELECT * FROM sales WHERE product_id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, productId);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Sale sale = new Sale(
                        resultSet.getInt("id"),
                        resultSet.getInt("seller_id"),
                        resultSet.getInt("buyer_id"),
                        resultSet.getInt("product_id"),
                        resultSet.getDouble("sale_price"),
                        resultSet.getDate("sale_date").toLocalDate() // Convert SQL Date to LocalDate
                );
                sales.add(sale);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sales;
    }

    // Retrieve the most expensive sale made
    public Sale getMostExpensiveSale() {
        String query = "SELECT * FROM sales ORDER BY sale_price DESC LIMIT 1";

        try (Statement stmt = connection.createStatement();
             ResultSet resultSet = stmt.executeQuery(query)) {

            if (resultSet.next()) {
                return new Sale(
                        resultSet.getInt("id"),
                        resultSet.getInt("seller_id"),
                        resultSet.getInt("buyer_id"),
                        resultSet.getInt("product_id"),
                        resultSet.getDouble("sale_price"),
                        resultSet.getDate("sale_date").toLocalDate() // Convert SQL Date to LocalDate
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}