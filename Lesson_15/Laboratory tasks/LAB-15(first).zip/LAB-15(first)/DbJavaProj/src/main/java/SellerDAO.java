import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SellerDAO {

    private Connection connection;

    // Constructor that accepts a database connection
    public SellerDAO(Connection connection) {
        this.connection = connection;
    }

    // Create a new seller
    public boolean addSeller(Seller seller) {
        String query = "INSERT INTO sellers (name, phone, email) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, seller.getName());
            stmt.setString(2, seller.getPhone());
            stmt.setString(3, seller.getEmail());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Update an existing seller
    public boolean updateSeller(Seller seller) {
        String query = "UPDATE sellers SET name = ?, phone = ?, email = ? WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, seller.getName());
            stmt.setString(2, seller.getPhone());
            stmt.setString(3, seller.getEmail());
            stmt.setInt(4, seller.getId());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete a seller by ID
    public boolean deleteSeller(int sellerId) {
        String query = "DELETE FROM sellers WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, sellerId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Retrieve a seller by ID
    public Seller getSellerById(int sellerId) {
        String query = "SELECT * FROM sellers WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, sellerId);
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                return new Seller(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("phone"),
                        resultSet.getString("email")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Retrieve all sellers
    public List<Seller> getAllSellers() {
        List<Seller> sellers = new ArrayList<>();
        String query = "SELECT * FROM sellers";

        try (Statement stmt = connection.createStatement();
             ResultSet resultSet = stmt.executeQuery(query)) {

            while (resultSet.next()) {
                Seller seller = new Seller(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("phone"),
                        resultSet.getString("email")
                );
                sellers.add(seller);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sellers;
    }

    // Retrieve sellers who made sales within a specific date range
    public List<Seller> getSellersBySalesDateRange(String startDate, String endDate) {
        List<Seller> sellers = new ArrayList<>();
        String query = "SELECT DISTINCT s.id, s.name, s.phone, s.email " +
                "FROM sellers s JOIN sales sa ON s.id = sa.salesperson_id " +
                "WHERE sa.sale_date BETWEEN ? AND ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDate(1, Date.valueOf(startDate)); // Convert String to SQL Date
            stmt.setDate(2, Date.valueOf(endDate));   // Convert String to SQL Date
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Seller seller = new Seller(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("phone"),
                        resultSet.getString("email")
                );
                sellers.add(seller);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sellers;
    }

    // Retrieve the total sales amount for a seller within a specific date range
    public double getTotalSalesAmountBySeller(int sellerId, String startDate, String endDate) {
        String query = "SELECT SUM(sa.sale_price) AS total_sales " +
                "FROM sales sa WHERE sa.salesperson_id = ? " +
                "AND sa.sale_date BETWEEN ? AND ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, sellerId);
            stmt.setDate(2, Date.valueOf(startDate)); // Convert String to SQL Date
            stmt.setDate(3, Date.valueOf(endDate));   // Convert String to SQL Date
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                return resultSet.getDouble("total_sales");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    // Retrieve the most successful seller based on the total sales amount
    public Seller getMostSuccessfulSeller() {
        String query = "SELECT s.id, s.name, s.phone, s.email, SUM(sa.sale_price) AS total_sales " +
                "FROM sellers s JOIN sales sa ON s.id = sa.salesperson_id " +
                "GROUP BY s.id ORDER BY total_sales DESC LIMIT 1";

        try (Statement stmt = connection.createStatement();
             ResultSet resultSet = stmt.executeQuery(query)) {

            if (resultSet.next()) {
                return new Seller(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("phone"),
                        resultSet.getString("email")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Retrieve the seller with the highest number of sales
    public Seller getSellerWithMostSales() {
        String query = "SELECT s.id, s.name, s.phone, s.email, COUNT(sa.id) AS sales_count " +
                "FROM sellers s JOIN sales sa ON s.id = sa.salesperson_id " +
                "GROUP BY s.id ORDER BY sales_count DESC LIMIT 1";

        try (Statement stmt = connection.createStatement();
             ResultSet resultSet = stmt.executeQuery(query)) {

            if (resultSet.next()) {
                return new Seller(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("phone"),
                        resultSet.getString("email")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Retrieve all sales made by a specific seller
    public List<Seller> getSalesBySeller(int sellerId) {
        List<Seller> sellers = new ArrayList<>();
        String query = "SELECT s.id, s.name, s.phone, s.email " +
                "FROM sellers s JOIN sales sa ON s.id = sa.salesperson_id " +
                "WHERE s.id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, sellerId);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Seller seller = new Seller(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("phone"),
                        resultSet.getString("email")
                );
                sellers.add(seller);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sellers;
    }
}