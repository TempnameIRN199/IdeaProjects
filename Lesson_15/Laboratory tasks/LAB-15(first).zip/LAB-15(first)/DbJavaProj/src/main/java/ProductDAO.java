import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    private Connection connection;

    // Constructor that accepts a database connection
    public ProductDAO(Connection connection) {
        this.connection = connection;
    }

    // Create a new product
    public boolean addProduct(Product product) {
        String query = "INSERT INTO products (name, price) VALUES (?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, product.getName());
            stmt.setDouble(2, product.getPrice());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Update an existing product
    public boolean updateProduct(Product product) {
        String query = "UPDATE products SET name = ?, price = ? WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, product.getName());
            stmt.setDouble(2, product.getPrice());
            stmt.setInt(3, product.getId());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Delete a product by ID
    public boolean deleteProduct(int productId) {
        String query = "DELETE FROM products WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, productId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Retrieve a product by ID
    public Product getProductById(int productId) {
        String query = "SELECT * FROM products WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, productId);
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                return new Product(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("price")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Retrieve all products
    public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        String query = "SELECT * FROM products";

        try (Statement stmt = connection.createStatement();
             ResultSet resultSet = stmt.executeQuery(query)) {

            while (resultSet.next()) {
                Product product = new Product(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("price")
                );
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    // Retrieve products by price range
    public List<Product> getProductsByPriceRange(double minPrice, double maxPrice) {
        List<Product> products = new ArrayList<>();
        String query = "SELECT * FROM products WHERE price BETWEEN ? AND ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDouble(1, minPrice);
            stmt.setDouble(2, maxPrice);
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Product product = new Product(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("price")
                );
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    // Retrieve products that have been sold in a given date range
    public List<Product> getProductsSoldInDateRange(String startDate, String endDate) {
        List<Product> products = new ArrayList<>();
        String query = "SELECT DISTINCT p.id, p.name, p.price " +
                "FROM products p JOIN sales sa ON p.id = sa.product_id " +
                "WHERE sa.sale_date BETWEEN ? AND ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDate(1, Date.valueOf(startDate)); // Convert String to SQL Date
            stmt.setDate(2, Date.valueOf(endDate));   // Convert String to SQL Date
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Product product = new Product(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("price")
                );
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    // Retrieve the best-selling product based on the total number of sales
    public Product getBestSellingProduct() {
        String query = "SELECT p.id, p.name, p.price, COUNT(sa.id) AS total_sales " +
                "FROM products p JOIN sales sa ON p.id = sa.product_id " +
                "GROUP BY p.id ORDER BY total_sales DESC LIMIT 1";

        try (Statement stmt = connection.createStatement();
             ResultSet resultSet = stmt.executeQuery(query)) {

            if (resultSet.next()) {
                return new Product(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("price")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Retrieve the total sales amount for a specific product in a given date range
    public double getTotalSalesAmountForProduct(int productId, String startDate, String endDate) {
        String query = "SELECT SUM(sa.sale_price) AS total_sales " +
                "FROM sales sa WHERE sa.product_id = ? " +
                "AND sa.sale_date BETWEEN ? AND ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, productId);
            stmt.setDate(2, Date.valueOf(startDate)); // Convert String to SQL Date
            stmt.setDate(3, Date.valueOf(endDate));   // Convert String to SQL Date
            ResultSet resultSet = stmt.executeQuery();

            if (resultSet.next()) {
                return resultSet.getDouble("total_sales");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    // Retrieve the products with the highest total sales amount in a given date range
    public List<Product> getTopSellingProductsInDateRange(String startDate, String endDate) {
        List<Product> products = new ArrayList<>();
        String query = "SELECT p.id, p.name, p.price, SUM(sa.sale_price) AS total_sales " +
                "FROM products p JOIN sales sa ON p.id = sa.product_id " +
                "WHERE sa.sale_date BETWEEN ? AND ? " +
                "GROUP BY p.id ORDER BY total_sales DESC";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDate(1, Date.valueOf(startDate)); // Convert String to SQL Date
            stmt.setDate(2, Date.valueOf(endDate));   // Convert String to SQL Date
            ResultSet resultSet = stmt.executeQuery();

            while (resultSet.next()) {
                Product product = new Product(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("price")
                );
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }
}