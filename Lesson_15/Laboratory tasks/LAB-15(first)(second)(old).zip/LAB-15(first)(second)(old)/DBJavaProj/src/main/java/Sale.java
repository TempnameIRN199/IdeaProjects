import java.time.LocalDate;

public class Sale {
    private int id;
    private int sellerId;
    private int buyerId;
    private String productName;
    private double price;
    private LocalDate saleDate;

    public Sale(int id, int sellerId, int buyerId, String productName, double price, LocalDate saleDate) {
        this.id = id;
        this.sellerId = sellerId;
        this.buyerId = buyerId;
        this.productName = productName;
        this.price = price;
        this.saleDate = saleDate;
    }

    public Sale(int sellerId, int buyerId, String productName, double price, LocalDate saleDate) {
        this.sellerId = sellerId;
        this.buyerId = buyerId;
        this.productName = productName;
        this.price = price;
        this.saleDate = saleDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSellerId() {
        return sellerId;
    }

    public void setSellerId(int sellerId) {
        this.sellerId = sellerId;
    }

    public int getBuyerId() {
        return buyerId;
    }

    public void setBuyerId(int buyerId) {
        this.buyerId = buyerId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public LocalDate getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(LocalDate saleDate) {
        this.saleDate = saleDate;
    }

    @Override
    public String toString() {
        return "Sale{" +
                "id=" + id +
                ", sellerId=" + sellerId +
                ", buyerId=" + buyerId +
                ", productName='" + productName + '\'' +
                ", price=" + price +
                ", saleDate=" + saleDate +
                '}';
    }
}