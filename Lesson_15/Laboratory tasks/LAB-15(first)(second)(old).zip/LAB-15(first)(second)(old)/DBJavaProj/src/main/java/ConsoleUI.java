import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class ConsoleUI {
    private final SellerService sellerService;
    private final BuyerService buyerService;
    private final SaleService saleService;
    private final Scanner scanner;

    public ConsoleUI(Connection conn) {
        this.sellerService = new SellerService(conn);
        this.buyerService = new BuyerService(conn);
        this.saleService = new SaleService(conn);
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        while (true) {
            System.out.println("\n=== Sales Management System ===");
            System.out.println("1. Add Seller");
            System.out.println("2. Add Buyer");
            System.out.println("3. Add Sale");
            System.out.println("4. Show All Sellers");
            System.out.println("5. Show All Buyers");
            System.out.println("6. Show All Sales");
            System.out.println("7. Show Top Seller");
            System.out.println("8. Show Top Buyer");
            System.out.println("9. Show Most Popular Product");
            System.out.println("10. Show Average Sale Price");
            System.out.println("11. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            try {
                switch (choice) {
                    case 1 -> addSeller();
                    case 2 -> addBuyer();
                    case 3 -> addSale();
                    case 4 -> showAllSellers();
                    case 5 -> showAllBuyers();
                    case 6 -> showAllSales();
                    case 7 -> showTopSeller();
                    case 8 -> showTopBuyer();
                    case 9 -> showMostPopularProduct();
                    case 10 -> showAverageSalePrice();
                    case 11 -> {
                        System.out.println("Exiting application...");
                        return;
                    }
                    default -> System.out.println("Invalid choice. Try again.");
                }
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
            }
        }
    }

    private void addSeller() throws SQLException {
        System.out.print("Enter Seller Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Phone: ");
        String phone = scanner.nextLine();
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        sellerService.addSeller(new Seller(0, name, phone, email));
        System.out.println("Seller added successfully!");
    }

    private void addBuyer() throws SQLException {
        System.out.print("Enter Buyer Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Phone: ");
        String phone = scanner.nextLine();
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        buyerService.addBuyer(new Buyer(0, name, phone, email));
        System.out.println("Buyer added successfully!");
    }

    private void addSale() throws SQLException {
        System.out.print("Enter Seller ID: ");
        int sellerId = scanner.nextInt();
        System.out.print("Enter Buyer ID: ");
        int buyerId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Product Name: ");
        String productName = scanner.nextLine();
        System.out.print("Enter Price: ");
        double price = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Enter Sale Date (YYYY-MM-DD): ");
        String saleDate = scanner.nextLine();
        saleService.addSale(new Sale(0, sellerId, buyerId, productName, price, LocalDate.parse(saleDate)));
        System.out.println("Sale added successfully!");
    }

    private void showAllSellers() throws SQLException {
        List<Seller> sellers = sellerService.getAllSellers();
        sellers.forEach(System.out::println);
    }

    private void showAllBuyers() throws SQLException {
        List<Buyer> buyers = buyerService.getAllBuyers();
        buyers.forEach(System.out::println);
    }

    private void showAllSales() throws SQLException {
        List<Sale> sales = saleService.getAllSales();
        sales.forEach(System.out::println);
    }

    private void showTopSeller() throws SQLException {
        Seller seller = saleService.getTopSeller();
        System.out.println(seller != null ? seller : "No sales data.");
    }

    private void showTopBuyer() throws SQLException {
        Buyer buyer = saleService.getTopBuyer();
        System.out.println(buyer != null ? buyer : "No sales data.");
    }

    private void showMostPopularProduct() throws SQLException {
        String product = saleService.getMostPopularProduct();
        System.out.println(product != null ? "Most Popular Product: " + product : "No sales data.");
    }

    private void showAverageSalePrice() throws SQLException {
        double avgPrice = saleService.getAverageSalePrice();
        System.out.println("Average Sale Price: $" + avgPrice);
    }
}