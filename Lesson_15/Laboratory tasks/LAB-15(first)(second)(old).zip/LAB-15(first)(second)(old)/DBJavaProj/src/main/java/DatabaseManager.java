import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseManager {
    private static final String URL = "jdbc:mysql://localhost:3306/sales_db";  // <-- Specify database name!
    private static final String USER = "root";   // Change if needed
    private static final String PASSWORD = "";  // Change if needed

    public static Connection connect() throws SQLException {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        System.out.println("✅ Database Connected Successfully!");
        createTables(conn);  // Ensure tables exist
        return conn;
    }

    public static void disconnect(Connection conn) throws SQLException {
        if (conn != null) {
            conn.close();
            System.out.println("✅ Database Disconnected!");
        }
    }

    private static void createTables(Connection conn) throws SQLException {
        String createSellersTable = "CREATE TABLE IF NOT EXISTS sellers (" +
                "id INT PRIMARY KEY AUTO_INCREMENT, " +
                "name VARCHAR(255), " +
                "phone VARCHAR(20), " +
                "email VARCHAR(255))";

        String createBuyersTable = "CREATE TABLE IF NOT EXISTS buyers (" +
                "id INT PRIMARY KEY AUTO_INCREMENT, " +
                "name VARCHAR(255), " +
                "phone VARCHAR(20), " +
                "email VARCHAR(255))";

        String createSalesTable = "CREATE TABLE IF NOT EXISTS sales (" +
                "id INT PRIMARY KEY AUTO_INCREMENT, " +
                "seller_id INT, " +
                "buyer_id INT, " +
                "product_name VARCHAR(255), " +
                "price DOUBLE, " +
                "sale_date DATE, " +
                "FOREIGN KEY (seller_id) REFERENCES sellers(id), " +
                "FOREIGN KEY (buyer_id) REFERENCES buyers(id))";

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(createSellersTable);
            stmt.execute(createBuyersTable);
            stmt.execute(createSalesTable);
            System.out.println("Tables Created or Exist Already.");
        }
    }
}