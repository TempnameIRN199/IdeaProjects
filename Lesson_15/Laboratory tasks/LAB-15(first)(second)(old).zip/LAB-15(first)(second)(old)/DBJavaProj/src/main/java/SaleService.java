import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SaleService {
    private final Connection conn;

    public SaleService(Connection conn) {
        this.conn = conn;
    }

    public void addSale(Sale sale) throws SQLException {
        String query = "INSERT INTO sales (seller_id, buyer_id, product_name, price, sale_date) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, sale.getSellerId());
            stmt.setInt(2, sale.getBuyerId());
            stmt.setString(3, sale.getProductName());
            stmt.setDouble(4, sale.getPrice());
            stmt.setDate(5, Date.valueOf(sale.getSaleDate()));
            stmt.executeUpdate();
        }
    }

    public List<Sale> getAllSales() throws SQLException {
        List<Sale> sales = new ArrayList<>();
        String query = "SELECT * FROM sales";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                sales.add(new Sale(
                        rs.getInt("id"),
                        rs.getInt("seller_id"),
                        rs.getInt("buyer_id"),
                        rs.getString("product_name"),
                        rs.getDouble("price"),
                        rs.getDate("sale_date").toLocalDate()
                ));
            }
        }
        return sales;
    }

    public void deleteSale(int id) throws SQLException {
        String query = "DELETE FROM sales WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public Seller getTopSeller() throws SQLException {
        String query = "SELECT sellers.id, sellers.name, sellers.phone, sellers.email, SUM(sales.price) AS total_sales " +
                "FROM sellers JOIN sales ON sellers.id = sales.seller_id " +
                "GROUP BY sellers.id ORDER BY total_sales DESC LIMIT 1";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            if (rs.next()) {
                return new Seller(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("email")
                );
            }
        }
        return null;
    }

    public Buyer getTopBuyer() throws SQLException {
        String query = "SELECT buyers.id, buyers.name, buyers.phone, buyers.email, SUM(sales.price) AS total_spent " +
                "FROM buyers JOIN sales ON buyers.id = sales.buyer_id " +
                "GROUP BY buyers.id ORDER BY total_spent DESC LIMIT 1";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            if (rs.next()) {
                return new Buyer(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("email")
                );
            }
        }
        return null;
    }

    public String getMostPopularProduct() throws SQLException {
        String query = "SELECT product_name, COUNT(*) AS total_sales FROM sales " +
                "GROUP BY product_name ORDER BY total_sales DESC LIMIT 1";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            if (rs.next()) {
                return rs.getString("product_name");
            }
        }
        return null;
    }

    public double getAverageSalePrice() throws SQLException {
        String query = "SELECT AVG(price) AS avg_price FROM sales";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            if (rs.next()) {
                return rs.getDouble("avg_price");
            }
        }
        return 0;
    }
}