import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BuyerService {
    private final Connection conn;

    public BuyerService(Connection conn) {
        this.conn = conn;
    }

    public void addBuyer(Buyer buyer) throws SQLException {
        String query = "INSERT INTO buyers (name, phone, email) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, buyer.getName());
            stmt.setString(2, buyer.getPhone());
            stmt.setString(3, buyer.getEmail());
            stmt.executeUpdate();
        }
    }

    public List<Buyer> getAllBuyers() throws SQLException {
        List<Buyer> buyers = new ArrayList<>();
        String query = "SELECT * FROM buyers";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                buyers.add(new Buyer(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("email")
                ));
            }
        }
        return buyers;
    }

    public void deleteBuyer(int id) throws SQLException {
        String query = "DELETE FROM buyers WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}