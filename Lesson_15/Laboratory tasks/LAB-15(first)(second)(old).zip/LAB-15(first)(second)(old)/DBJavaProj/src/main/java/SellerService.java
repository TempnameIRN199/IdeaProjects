import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SellerService {
    private final Connection conn;

    public SellerService(Connection conn) {
        this.conn = conn;
    }

    public void addSeller(Seller seller) throws SQLException {
        String query = "INSERT INTO sellers (name, phone, email) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, seller.getName());
            stmt.setString(2, seller.getPhone());
            stmt.setString(3, seller.getEmail());
            stmt.executeUpdate();
        }
    }

    public List<Seller> getAllSellers() throws SQLException {
        List<Seller> sellers = new ArrayList<>();
        String query = "SELECT * FROM sellers";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                sellers.add(new Seller(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("email")
                ));
            }
        }
        return sellers;
    }

    public void deleteSeller(int id) throws SQLException {
        String query = "DELETE FROM sellers WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}