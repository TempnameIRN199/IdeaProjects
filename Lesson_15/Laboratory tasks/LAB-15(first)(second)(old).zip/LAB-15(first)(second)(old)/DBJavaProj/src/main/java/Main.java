import java.sql.Connection;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        try {
            Connection conn = DatabaseManager.connect();
            ConsoleUI ui = new ConsoleUI(conn);
            ui.start();
            DatabaseManager.disconnect(conn);
        } catch (SQLException e) {
            System.out.println("Database connection failed: " + e.getMessage());
        }
    }
}