import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/countries_db?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";  // Change this to your MySQL username
    private static final String PASSWORD = "";  // Change this to your MySQL password

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void createTablesIfNotExist() throws SQLException {
        // Create Connection
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement()) {

            // SQL for creating 'continents' table
            String createContinentsTable = "CREATE TABLE IF NOT EXISTS continents (" +
                    "continent_id INT PRIMARY KEY, " +
                    "name VARCHAR(100) NOT NULL" +
                    ") ENGINE=InnoDB;";  // Ensure InnoDB engine

            // SQL for creating 'countries' table with foreign key to 'continents'
            String createCountriesTable = "CREATE TABLE IF NOT EXISTS countries (" +
                    "country_id INT PRIMARY KEY, " +
                    "country_name VARCHAR(100) NOT NULL, " +
                    "continent_id INT, " +
                    "FOREIGN KEY (continent_id) REFERENCES continents(continent_id) ON DELETE CASCADE" +
                    ") ENGINE=InnoDB;";  // Ensure InnoDB engine

            // Execute the statements
            statement.executeUpdate(createContinentsTable);
            statement.executeUpdate(createCountriesTable);
            System.out.println("Tables 'continents' and 'countries' created successfully.");
        }
    }
}