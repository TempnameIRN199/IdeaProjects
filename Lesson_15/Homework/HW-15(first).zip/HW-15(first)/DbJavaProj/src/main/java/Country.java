import java.util.List;

public class Country {
    private int id;
    private String name;
    private Capital capital;
    private List<City> cities;
    private int population;

    // Constructor
    public Country(int id, String name, Capital capital, List<City> cities, int population) {
        this.id = id;
        this.name = name;
        this.capital = capital;
        this.cities = cities;
        this.population = population;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Capital getCapital() {
        return capital;
    }

    public void setCapital(Capital capital) {
        this.capital = capital;
    }

    public List<City> getCities() {
        return cities;
    }

    public void setCities(List<City> cities) {
        this.cities = cities;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    // ToString method for easy debugging
    @Override
    public String toString() {
        return "Country{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", capital=" + capital +
                ", cities=" + cities +
                ", population=" + population +
                '}';
    }
}