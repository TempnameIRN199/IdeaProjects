import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CapitalDAO {
    private final Connection connection;

    public CapitalDAO(Connection connection) {
        this.connection = connection;
    }

    // Retrieve all capitals
    public List<String> getAllCapitals() {
        List<String> capitals = new ArrayList<>();
        String sql = "SELECT ci.name AS capital FROM countries c JOIN cities ci ON c.capital_id = ci.id";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                capitals.add(rs.getString("capital"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return capitals;
    }

    // Get the capital of a specific country
    public String getCapitalByCountry(String countryName) {
        String sql = "SELECT ci.name FROM countries c JOIN cities ci ON c.capital_id = ci.id WHERE c.name = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, countryName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("name");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "Capital not found for " + countryName;
    }

    // Show top 3 countries with the most cities
    public void showTop3CountriesByCityCount() {
        String sql = "SELECT c.name, COUNT(ci.id) AS city_count " +
                "FROM countries c JOIN cities ci ON c.id = ci.country_id " +
                "GROUP BY c.id ORDER BY city_count DESC LIMIT 3";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("Top 3 countries with the most cities:");
            while (rs.next()) {
                System.out.println(rs.getString("name") + " -> " + rs.getInt("city_count") + " cities");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Show top 3 countries with the largest population
    public void showTop3CountriesByPopulation() {
        String sql = "SELECT name, population FROM countries ORDER BY population DESC LIMIT 3";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("Top 3 countries by population:");
            while (rs.next()) {
                System.out.println(rs.getString("name") + " -> " + rs.getInt("population") + " people");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Show top 3 countries with the smallest population
    public void showBottom3CountriesByPopulation() {
        String sql = "SELECT name, population FROM countries ORDER BY population ASC LIMIT 3";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("Bottom 3 countries by population:");
            while (rs.next()) {
                System.out.println(rs.getString("name") + " -> " + rs.getInt("population") + " people");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Show average population per city for a specific country
    public void showAverageCityPopulation(String countryName) {
        String sql = "SELECT AVG(ci.population) AS avg_population " +
                "FROM cities ci JOIN countries c ON ci.country_id = c.id WHERE c.name = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, countryName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Average city population in " + countryName + ": " + rs.getInt("avg_population"));
            } else {
                System.out.println("No data found for " + countryName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Add a capital to a country
    public void addCapital(String capitalName, int countryId, int population) {
        String sql = "INSERT INTO cities (name, country_id, is_capital, population) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, capitalName);
            stmt.setInt(2, countryId);
            stmt.setBoolean(3, true);
            stmt.setInt(4, population);
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int capitalId = generatedKeys.getInt(1);
                    updateCountryCapital(countryId, capitalId);
                    System.out.println("Capital added: " + capitalName);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update the capital of a country
    private void updateCountryCapital(int countryId, int capitalId) {
        String sql = "UPDATE countries SET capital_id = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, capitalId);
            stmt.setInt(2, countryId);
            stmt.executeUpdate();
            System.out.println("Updated capital for country ID " + countryId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete a capital (also updates country)
    public void deleteCapital(int capitalId, int countryId) {
        String sql = "DELETE FROM cities WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, capitalId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                clearCountryCapital(countryId);
                System.out.println("Deleted capital with ID " + capitalId);
            } else {
                System.out.println("Capital not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Clear the capital reference from the country after deletion
    private void clearCountryCapital(int countryId) {
        String sql = "UPDATE countries SET capital_id = NULL WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, countryId);
            stmt.executeUpdate();
            System.out.println("Cleared capital reference for country ID " + countryId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}