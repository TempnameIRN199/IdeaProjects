import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CountryDAO {
    private final Connection connection;

    public CountryDAO(Connection connection) {
        this.connection = connection;
    }

    // CREATE
    public void addCountry(Country country) throws SQLException {
        String sql = "INSERT INTO countries (name, capital_id, population) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, country.getName());
            stmt.setInt(2, country.getCapital().getId());
            stmt.setInt(3, country.getPopulation());
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                country.setId(rs.getInt(1));
            }
        }
    }

    // READ
    public List<Country> getAllCountries() throws SQLException {
        List<Country> countries = new ArrayList<>();
        String sql = "SELECT * FROM countries";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                countries.add(new Country(
                        rs.getInt("id"),
                        rs.getString("name"),
                        null, null,
                        rs.getInt("population")
                ));
            }
        }
        return countries;
    }

    // UPDATE
    public void updateCountry(Country country) throws SQLException {
        String sql = "UPDATE countries SET name = ?, capital_id = ?, population = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, country.getName());
            stmt.setInt(2, country.getCapital().getId());
            stmt.setInt(3, country.getPopulation());
            stmt.setInt(4, country.getId());
            stmt.executeUpdate();
        }
    }

    // DELETE
    public void deleteCountry(int id) throws SQLException {
        String sql = "DELETE FROM countries WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public List<String> getTop3CountriesWithMostCities() throws SQLException {
        List<String> countries = new ArrayList<>();
        String sql = "SELECT c.name, COUNT(ci.id) AS city_count " +
                "FROM countries c " +
                "JOIN cities ci ON c.id = ci.country_id " +
                "GROUP BY c.id " +
                "ORDER BY city_count DESC " +
                "LIMIT 3";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                countries.add(rs.getString("name") + " (Cities: " + rs.getInt("city_count") + ")");
            }
        }
        return countries;
    }

    public List<String> getTop3CountriesByPopulation() throws SQLException {
        List<String> countries = new ArrayList<>();
        String sql = "SELECT name, population FROM countries ORDER BY population DESC LIMIT 3";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                countries.add(rs.getString("name") + " (Population: " + rs.getInt("population") + ")");
            }
        }
        return countries;
    }

    public List<String> getTop3CountriesWithSmallestPopulation() throws SQLException {
        List<String> countries = new ArrayList<>();
        String sql = "SELECT name, population FROM countries ORDER BY population ASC LIMIT 3";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                countries.add(rs.getString("name") + " (Population: " + rs.getInt("population") + ")");
            }
        }
        return countries;
    }

    public double getAverageCityPopulation(int countryId) throws SQLException {
        String sql = "SELECT AVG(population) AS avg_population FROM cities WHERE country_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, countryId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble("avg_population");
            }
        }
        return 0;
    }

    public List<String> getCitiesWithSameName() throws SQLException {
        List<String> cities = new ArrayList<>();
        String sql = "SELECT name, COUNT(*) AS occurrences " +
                "FROM cities " +
                "GROUP BY name " +
                "HAVING COUNT(*) > 1";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                cities.add(rs.getString("name") + " appears in " + rs.getInt("occurrences") + " countries");
            }
        }
        return cities;
    }

    public List<String> getUniqueCityNames() throws SQLException {
        List<String> uniqueCities = new ArrayList<>();
        String sql = "SELECT DISTINCT name FROM cities";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                uniqueCities.add(rs.getString("name"));
            }
        }
        return uniqueCities;
    }

    public List<String> getCountriesByCityCountRange(int min, int max) throws SQLException {
        List<String> countries = new ArrayList<>();
        String sql = "SELECT c.name, COUNT(ci.id) AS city_count " +
                "FROM countries c " +
                "JOIN cities ci ON c.id = ci.country_id " +
                "GROUP BY c.id " +
                "HAVING city_count BETWEEN ? AND ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, min);
            stmt.setInt(2, max);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                countries.add(rs.getString("name") + " (Cities: " + rs.getInt("city_count") + ")");
            }
        }
        return countries;
    }
}