import java.sql.*;
import java.util.HashSet;
import java.util.Set;

public class CityDAO {
    private final Connection connection;

    public CityDAO(Connection connection) {
        this.connection = connection;
    }

    // Show all cities of a specific country
    public void showCitiesByCountry(int countryId) {
        String sql = "SELECT name FROM cities WHERE country_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, countryId);
            ResultSet rs = stmt.executeQuery();
            System.out.println("Cities in country ID " + countryId + ":");
            while (rs.next()) {
                System.out.println("- " + rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Show all capitals
    public void showAllCapitals() {
        String sql = "SELECT c.name AS country, ci.name AS capital FROM countries c JOIN cities ci ON c.capital_id = ci.id";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("List of all capitals:");
            while (rs.next()) {
                System.out.println(rs.getString("country") + " -> " + rs.getString("capital"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Show capital of a specific country
    public void showCapitalByCountry(String countryName) {
        String sql = "SELECT ci.name FROM countries c JOIN cities ci ON c.capital_id = ci.id WHERE c.name = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, countryName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Capital of " + countryName + " is " + rs.getString("name"));
            } else {
                System.out.println("No capital found for country: " + countryName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Show duplicate city names across different countries
    public void showDuplicateCityNames() {
        String sql = "SELECT name, COUNT(*) as count FROM cities GROUP BY name HAVING count > 1";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            System.out.println("Duplicate city names:");
            while (rs.next()) {
                System.out.println(rs.getString("name") + " appears in " + rs.getInt("count") + " countries.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Show unique city names across all countries
    public void showUniqueCityNames() {
        String sql = "SELECT DISTINCT name FROM cities";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            Set<String> uniqueCities = new HashSet<>();
            while (rs.next()) {
                uniqueCities.add(rs.getString("name"));
            }
            System.out.println("Unique city names: " + uniqueCities);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Insert a new city
    public void addCity(String name, int countryId, boolean isCapital, int population) {
        String sql = "INSERT INTO cities (name, country_id, is_capital, population) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setInt(2, countryId);
            stmt.setBoolean(3, isCapital);
            stmt.setInt(4, population);
            stmt.executeUpdate();
            System.out.println("City added: " + name);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update city population
    public void updateCityPopulation(int cityId, int newPopulation) {
        String sql = "UPDATE cities SET population = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, newPopulation);
            stmt.setInt(2, cityId);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Updated city ID " + cityId + " with new population: " + newPopulation);
            } else {
                System.out.println("City not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete a city
    public void deleteCity(int cityId) {
        String sql = "DELETE FROM cities WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, cityId);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Deleted city ID " + cityId);
            } else {
                System.out.println("City not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}