public class City {
    private int id;
    private String name;
    private int population;
    private int countryId; // Foreign key to Country

    // Constructor
    public City(int id, String name, int population, int countryId) {
        this.id = id;
        this.name = name;
        this.population = population;
        this.countryId = countryId;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public int getCountryId() {
        return countryId;
    }

    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }

    // ToString method for easy debugging
    @Override
    public String toString() {
        return "City{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", population=" + population +
                ", countryId=" + countryId +
                '}';
    }
}