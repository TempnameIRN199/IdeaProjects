import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    private static Connection connection;
    private static CapitalDAO capitalDAO;
    private static CityDAO cityDAO;
    private static CountryDAO countryDAO;

    public static void main(String[] args) {

        try {
            // Create the tables if they don't exist
            DatabaseConnection.createTablesIfNotExist();
        } catch (SQLException e) {
            System.out.println("Error establishing connection to database");
            e.printStackTrace();
        }

        // Establish database connection
        try {
            connection = DatabaseConnection.getConnection();
            capitalDAO = new CapitalDAO(connection);
            cityDAO = new CityDAO(connection);
            countryDAO = new CountryDAO(connection);
        } catch (Exception e) {
            System.err.println("Error establishing connection to database");
            e.printStackTrace();
            return;
        }

        // Show the main menu
        Scanner scanner = new Scanner(System.in);
        while (true) {
            showMenu();
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline left-over

            switch (choice) {
                case 1:
                    displayAllCapitals();
                    break;
                case 2:
                    displayCapitalOfCountry(scanner);
                    break;
                case 3:
                    showTop3CountriesByCityCount();
                    break;
                case 4:
                    showTop3CountriesByPopulation();
                    break;
                case 5:
                    showBottom3CountriesByPopulation();
                    break;
                case 6:
                    showAverageCityPopulation(scanner);
                    break;
                case 7:
                    addCapital(scanner);
                    break;
                case 8:
                    deleteCapital(scanner);
                    break;
                case 9:
                    updateCapital(scanner);
                    break;
                case 0:
                    // Exit the program
                    closeConnection();
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    // Display the main menu
    private static void showMenu() {
        System.out.println("\n=== Main Menu ===");
        System.out.println("1. Display all capitals");
        System.out.println("2. Display the capital of a specific country");
        System.out.println("3. Show top 3 countries with the most cities");
        System.out.println("4. Show top 3 countries with the largest population");
        System.out.println("5. Show bottom 3 countries with the smallest population");
        System.out.println("6. Show average city population for a country");
        System.out.println("7. Add a new capital");
        System.out.println("8. Delete a capital");
        System.out.println("9. Update the capital of a country");
        System.out.println("0. Exit");
    }

    // Display all capitals
    private static void displayAllCapitals() {
        System.out.println("\nAll Capitals:");
        for (String capital : capitalDAO.getAllCapitals()) {
            System.out.println(capital);
        }
    }

    // Display the capital of a specific country
    private static void displayCapitalOfCountry(Scanner scanner) {
        System.out.print("Enter the name of the country: ");
        String countryName = scanner.nextLine();
        String capital = capitalDAO.getCapitalByCountry(countryName);
        System.out.println("The capital of " + countryName + " is: " + capital);
    }

    // Show top 3 countries with the most cities
    private static void showTop3CountriesByCityCount() {
        capitalDAO.showTop3CountriesByCityCount();
    }

    // Show top 3 countries with the largest population
    private static void showTop3CountriesByPopulation() {
        capitalDAO.showTop3CountriesByPopulation();
    }

    // Show bottom 3 countries with the smallest population
    private static void showBottom3CountriesByPopulation() {
        capitalDAO.showBottom3CountriesByPopulation();
    }

    // Show average city population for a specific country
    private static void showAverageCityPopulation(Scanner scanner) {
        System.out.print("Enter the country name to get average city population: ");
        String countryName = scanner.nextLine();
        capitalDAO.showAverageCityPopulation(countryName);
    }

    // Add a new capital
    private static void addCapital(Scanner scanner) {
        System.out.print("Enter the name of the new capital: ");
        String capitalName = scanner.nextLine();
        System.out.print("Enter the country ID for the new capital: ");
        int countryId = scanner.nextInt();
        System.out.print("Enter the population of the new capital: ");
        int population = scanner.nextInt();
        scanner.nextLine();  // Consume newline left-over

        capitalDAO.addCapital(capitalName, countryId, population);
    }

    // Delete a capital
    private static void deleteCapital(Scanner scanner) {
        System.out.print("Enter the capital ID to delete: ");
        int capitalId = scanner.nextInt();
        System.out.print("Enter the country ID to update after deleting the capital: ");
        int countryId = scanner.nextInt();
        scanner.nextLine();  // Consume newline left-over

        capitalDAO.deleteCapital(capitalId, countryId);
    }

    // Update the capital of a country
    private static void updateCapital(Scanner scanner) {
        System.out.print("Enter the country ID to update capital: ");
        int countryId = scanner.nextInt();
        System.out.print("Enter the new capital ID: ");
        int capitalId = scanner.nextInt();
        scanner.nextLine();  // Consume newline left-over

    }

    // Close the connection
    private static void closeConnection() {
        if (connection != null) {

            System.out.println("Database connection closed.");
        }
    }
}