CREATE TABLE populated_areas
(
	id INTEGER AUTO_INCREMENT,
	name VARCHAR(64) NOT NULL,
	population INTEGER NOT NULL,
	is_capital BOOL NOT NULL,
	description TEXT NOT NULL,
	
	country_id SMALLINT NOT NULL,
	
	PRIMARY KEY (id),
	
	FOREIGN KEY (country_id) REFERENCES countries(id),
	
	CHECK (name <> ""),
	CHECK (population > 0),
	CHECK (description <> "")
)