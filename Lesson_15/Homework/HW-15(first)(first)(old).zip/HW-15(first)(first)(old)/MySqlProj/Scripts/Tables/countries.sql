CREATE TABLE countries
(
	id SMALLINT AUTO_INCREMENT,
	name VARCHAR(64) NOT NULL,
	
	PRIMARY KEY (id),
	
	CHECK (name <> "")
)