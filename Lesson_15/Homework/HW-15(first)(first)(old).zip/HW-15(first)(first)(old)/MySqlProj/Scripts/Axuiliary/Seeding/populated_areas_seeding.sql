INSERT INTO populated_areas (name, population, is_capital, description, country_id)
VALUES
    -- United States
    ('New York City', 8419600, FALSE, 'Largest city in the United States, known for its skyline and cultural diversity.', 1),
    ('Los Angeles', 3980400, FALSE, 'Major city in California, known for Hollywood and entertainment industry.', 1),
    ('Washington D.C.', 705749, TRUE, 'Capital city of the United States, home to the federal government.', 1),
    
    -- Canada
    ('Toronto', 2930000, FALSE, 'Largest city in Canada, known for its multicultural population and CN Tower.', 2),
    ('Vancouver', 675218, FALSE, 'City on the west coast of Canada, known for its natural beauty.', 2),
    ('Ottawa', 1011000, TRUE, 'Capital city of Canada, located in Ontario.', 2),
    
    -- Mexico
    ('Mexico City', 9209944, TRUE, 'Capital city of Mexico, one of the largest cities in the world.', 3),
    ('Guadalajara', 1505000, FALSE, 'Major city in Mexico, known for mariachi music and tequila.', 3),
    ('Monterrey', 1136000, FALSE, 'Industrial hub in northern Mexico.', 3),
    
    -- Brazil
    ('São Paulo', 12300000, FALSE, 'Largest city in Brazil and South America, known for its economic significance.', 4),
    ('Rio de Janeiro', 6748000, FALSE, 'Famous for its beaches, carnival, and Christ the Redeemer statue.', 4),
    ('Brasília', 3094320, TRUE, 'Capital city of Brazil, known for its modernist architecture.', 4),
    
    -- Germany
    ('Berlin', 3769000, TRUE, 'Capital city of Germany, known for its history and vibrant cultural scene.', 5),
    ('Munich', 1472000, FALSE, 'Known for Oktoberfest and its cultural heritage.', 5),
    ('Hamburg', 1841000, FALSE, 'Major port city in northern Germany.', 5),
    
    -- India
    ('Mumbai', 20410000, FALSE, 'Largest city in India, known as the financial capital.', 6),
    ('Delhi', 16787941, TRUE, 'Capital city of India, known for its historical landmarks.', 6),
    ('Bangalore', 8436675, FALSE, 'Known as the IT capital of India.', 6),
    
    -- Japan
    ('Tokyo', 13929286, TRUE, 'Capital city of Japan, known for its mix of traditional and modern culture.', 7),
    ('Osaka', 2715000, FALSE, 'Major city in Japan, known for its food and commerce.', 7),
    ('Kyoto', 1475000, FALSE, 'Famous for its classical Buddhist temples and gardens.', 7),
    
    -- Additional Cities
    ('Chicago', 2716000, FALSE, 'Major city in the United States, known for its architecture.', 1),
    ('Quebec City', 531902, FALSE, 'Known for its French heritage and historic old town.', 2),
    ('Puebla', 1434062, FALSE, 'Known for its colonial architecture and culinary history.', 3),
    ('Salvador', 2881000, FALSE, 'City in Brazil, known for its Afro-Brazilian culture.', 4),
    ('Frankfurt', 753056, FALSE, 'Financial hub of Germany.', 5),
    ('Kolkata', 4496694, FALSE, 'City in India, known for its literary and cultural heritage.', 6),
    ('Nagoya', 2305000, FALSE, 'Industrial city in Japan.', 7);