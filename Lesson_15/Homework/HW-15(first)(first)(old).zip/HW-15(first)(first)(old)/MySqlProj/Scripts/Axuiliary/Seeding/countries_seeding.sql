INSERT INTO countries (name)
VALUES 
    ('United States'),
    ('Canada'),
    ('Mexico'),
    ('Brazil'),
    ('Germany'),
    ('India'),
    ('Japan');