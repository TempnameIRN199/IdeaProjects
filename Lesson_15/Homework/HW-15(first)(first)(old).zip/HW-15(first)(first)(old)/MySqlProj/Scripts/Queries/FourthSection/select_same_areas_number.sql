SELECT 
    populated_areas.name AS city_name,
    COUNT(DISTINCT populated_areas.country_id) AS country_count
FROM populated_areas
GROUP BY populated_areas.name
HAVING COUNT(DISTINCT populated_areas.country_id) > 1;