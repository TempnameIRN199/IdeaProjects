SELECT 
	countries.name AS country_name,
	COUNT(populated_areas.id) AS areas_number
FROM countries
INNER JOIN populated_areas ON countries.id = populated_areas.country_id
GROUP BY countries.name
HAVING areas_number BETWEEN 2 AND 4