SELECT DISTINCT populated_areas.name
FROM populated_areas
