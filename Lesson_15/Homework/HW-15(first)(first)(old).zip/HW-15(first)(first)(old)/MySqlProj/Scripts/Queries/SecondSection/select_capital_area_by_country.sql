SELECT *
FROM populated_areas
INNER JOIN countries ON populated_areas.country_id = countries.id