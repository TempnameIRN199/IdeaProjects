SELECT *
FROM countries