SELECT *
FROM populated_areas
WHERE is_capital = TRUE