SELECT 
	countries.name AS country_name,
	SUM(populated_areas.population) AS total_population
FROM countries
INNER JOIN populated_areas ON countries.id = populated_areas.country_id
GROUP BY countries.name
ORDER BY total_population DESC  
LIMIT 3
