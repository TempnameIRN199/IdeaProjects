SELECT 
	countries.name AS country_name,
	AVG(populated_areas.population) AS avg_population
FROM countries
INNER JOIN populated_areas ON countries.id = populated_areas.country_id
WHERE countries.name = "United States"
