INSERT INTO populated_areas (name, population, is_capital, description, country_id)
VALUES
    ('New York City', 8419600, FALSE, 'Largest city in the United States, known for its skyline and cultural diversity.', 1)