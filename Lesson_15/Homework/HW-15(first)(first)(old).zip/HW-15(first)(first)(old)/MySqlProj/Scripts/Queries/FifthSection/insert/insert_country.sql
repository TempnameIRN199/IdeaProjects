INSERT INTO countries (name)
VALUES 
    ('SomeName')