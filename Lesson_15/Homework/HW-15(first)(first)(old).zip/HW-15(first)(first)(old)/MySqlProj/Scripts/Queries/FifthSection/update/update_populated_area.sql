UPDATE populated_areas
SET name = "SomeName"
WHERE id = 2