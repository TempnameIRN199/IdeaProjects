DELETE FROM populated_areas
WHERE id = 60