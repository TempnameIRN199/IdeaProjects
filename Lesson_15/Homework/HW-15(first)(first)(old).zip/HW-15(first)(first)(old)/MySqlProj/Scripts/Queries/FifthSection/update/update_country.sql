UPDATE countries
SET name = "SomeName"
WHERE id = 9