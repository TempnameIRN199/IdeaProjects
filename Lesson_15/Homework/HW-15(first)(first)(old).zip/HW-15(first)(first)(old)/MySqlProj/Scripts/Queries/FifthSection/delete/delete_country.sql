DELETE FROM countries
WHERE id = 40