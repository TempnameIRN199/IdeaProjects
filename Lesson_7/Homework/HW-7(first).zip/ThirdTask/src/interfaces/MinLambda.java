package interfaces;

public interface MinLambda<TgtType extends Number>
{
	TgtType get(TgtType firstNum, TgtType secondNum, TgtType thirdNum, TgtType fourthNum);
}
