package interfaces;

public interface MaxLambda<TgtType extends Number>
{
	TgtType get(TgtType firstNum, TgtType secondNum, TgtType thridNum, TgtType fourthNum);
}
