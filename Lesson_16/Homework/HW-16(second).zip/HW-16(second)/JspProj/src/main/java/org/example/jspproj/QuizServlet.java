package org.example.jspproj;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;

@WebServlet("/QuizServlet")
public class QuizServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Logic for handling quiz questions and answers
        String answer = request.getParameter("answer");

        // Validate the answer and redirect to result
        response.sendRedirect("result.jsp");
    }
}