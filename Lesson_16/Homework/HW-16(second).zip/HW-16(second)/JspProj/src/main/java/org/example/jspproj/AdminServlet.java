package org.example.jspproj;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;

@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Logic for handling category/question addition and management
        String action = request.getParameter("action");

        if ("addCategory".equals(action)) {
            // Add category logic
        } else if ("addQuestion".equals(action)) {
            // Add question logic
        }

        response.sendRedirect("admin.jsp");
    }
}