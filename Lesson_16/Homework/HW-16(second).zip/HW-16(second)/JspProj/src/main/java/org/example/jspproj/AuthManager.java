package org.example.jspproj;

public class AuthManager {
    public static boolean authenticate(String username, String password) {
        // For simplicity, hardcoding credentials
        return "admin".equals(username) && "admin123".equals(password);
    }
}