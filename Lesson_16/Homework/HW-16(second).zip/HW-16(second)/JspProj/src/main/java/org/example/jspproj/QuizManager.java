package org.example.jspproj;

import java.util.ArrayList;
import java.util.List;

public class QuizManager {
    public static List<Question> getQuestions(String category) {
        // Hardcoded questions for simplicity
        List<Question> questions = new ArrayList<>();
        questions.add(new Question("What is the capital of France?", "Paris"));
        return questions;
    }
}