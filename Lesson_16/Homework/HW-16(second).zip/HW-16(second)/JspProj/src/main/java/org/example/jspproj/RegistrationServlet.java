package org.example.jspproj;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Store user in session for simplicity
        HttpSession session = request.getSession();
        session.setAttribute("user", new User(username, password));

        response.sendRedirect("login.jsp");
    }
}