package com.myapp;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;

@WebServlet("/checkAddress")
public class AddressCheckServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String address = request.getParameter("address");

        // Example logic: check if address contains a specific city name
        if (address.contains("SomeCity")) {
            // Delivery available
            response.sendRedirect("orderPizza");
        } else {
            // Delivery not available
            request.setAttribute("errorMessage", "Sorry, we do not deliver to your address.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("addressCheck.jsp");
            dispatcher.forward(request, response);
        }
    }
}