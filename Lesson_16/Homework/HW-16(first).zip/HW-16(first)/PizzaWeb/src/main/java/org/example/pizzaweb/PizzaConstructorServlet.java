package com.myapp;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;

@WebServlet("/createCustomPizza")
public class PizzaConstructorServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("pizzaConstructor.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");
        String address = request.getParameter("address");
        String pizzaType = request.getParameter("pizzaType");
        String toppings = request.getParameter("toppings");

        PizzaOrder order = new PizzaOrder(name, phone, email, address, pizzaType, toppings);

        request.setAttribute("order", order);
        RequestDispatcher dispatcher = request.getRequestDispatcher("orderConfirmation.jsp");
        dispatcher.forward(request, response);
    }
}