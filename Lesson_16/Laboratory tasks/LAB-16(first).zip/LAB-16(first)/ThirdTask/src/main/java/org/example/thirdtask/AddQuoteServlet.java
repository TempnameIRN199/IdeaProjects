package org.example.thirdtask;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.util.*;

@WebServlet("/addQuote")
public class AddQuoteServlet extends HttpServlet {
    private List<Quote> quotes;

    @Override
    public void init() {
        quotes = new ArrayList<>();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String text = request.getParameter("text");
        String author = request.getParameter("author");
        String category = request.getParameter("category");

        quotes.add(new Quote(text, author, category));

        response.sendRedirect("quote");
    }
}