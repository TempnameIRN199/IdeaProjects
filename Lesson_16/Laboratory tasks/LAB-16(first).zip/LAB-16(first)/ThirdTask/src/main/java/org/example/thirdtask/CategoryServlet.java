package org.example.thirdtask;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

@WebServlet("/category")
public class CategoryServlet extends HttpServlet {
    private List<Quote> quotes;

    @Override
    public void init() {
        quotes = new ArrayList<>();
        quotes.add(new Quote("The only way to do great work is to love what you do.", "Steve Jobs", "Personal Development"));
        quotes.add(new Quote("Education is the most powerful weapon which you can use to change the world.", "Nelson Mandela", "Education"));
        quotes.add(new Quote("In three words I can sum up everything I've learned about life: it goes on.", "Robert Frost", "Life"));
        quotes.add(new Quote("History is written by the victors.", "Winston Churchill", "History"));
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String category = request.getParameter("category");
        List<Quote> filteredQuotes = quotes.stream()
                .filter(q -> q.getCategory().equals(category))
                .collect(Collectors.toList());

        request.setAttribute("quotes", filteredQuotes);
        RequestDispatcher dispatcher = request.getRequestDispatcher("category.jsp");
        dispatcher.forward(request, response);
    }
}