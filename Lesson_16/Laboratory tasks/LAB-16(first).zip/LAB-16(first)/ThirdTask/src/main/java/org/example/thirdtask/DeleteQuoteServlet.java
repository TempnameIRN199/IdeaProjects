package org.example.thirdtask;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.util.*;

@WebServlet("/deleteQuote")
public class DeleteQuoteServlet extends HttpServlet {
    private List<Quote> quotes;

    @Override
    public void init() {
        quotes = new ArrayList<>();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int index = Integer.parseInt(request.getParameter("index"));
        quotes.remove(index);

        response.sendRedirect("quote");
    }
}