package org.example.thirdtask;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.util.*;

@WebServlet("/quote")
public class QuoteServlet extends HttpServlet {
    private List<Quote> quotes;

    @Override
    public void init() {
        quotes = new ArrayList<>();
        quotes.add(new Quote("The only way to do great work is to love what you do.", "Steve Jobs", "Personal Development"));
        quotes.add(new Quote("Education is the most powerful weapon which you can use to change the world.", "Nelson Mandela", "Education"));
        quotes.add(new Quote("In three words I can sum up everything I've learned about life: it goes on.", "Robert Frost", "Life"));
        quotes.add(new Quote("History is written by the victors.", "Winston Churchill", "History"));
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Random random = new Random();
        Quote randomQuote = quotes.get(random.nextInt(quotes.size()));

        request.setAttribute("quote", randomQuote);
        RequestDispatcher dispatcher = request.getRequestDispatcher("quote.jsp");
        dispatcher.forward(request, response);
    }
}