package org.example.thirdtask;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.util.*;

@WebServlet("/editQuote")
public class EditQuoteServlet extends HttpServlet {
    private List<Quote> quotes;

    @Override
    public void init() {
        quotes = new ArrayList<>();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int index = Integer.parseInt(request.getParameter("index"));
        String text = request.getParameter("text");
        String author = request.getParameter("author");
        String category = request.getParameter("category");

        Quote updatedQuote = quotes.get(index);
        updatedQuote.setText(text);
        updatedQuote.setAuthor(author);
        updatedQuote.setCategory(category);

        response.sendRedirect("quote");
    }
}