package org.example.thirdtask;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

@WebServlet("/search")
public class SearchServlet extends HttpServlet {
    private List<Quote> quotes;

    @Override
    public void init() {
        quotes = new ArrayList<>();
        quotes.add(new Quote("The only way to do great work is to love what you do.", "Steve Jobs", "Personal Development"));
        quotes.add(new Quote("Education is the most powerful weapon which you can use to change the world.", "Nelson Mandela", "Education"));
        quotes.add(new Quote("In three words I can sum up everything I've learned about life: it goes on.", "Robert Frost", "Life"));
        quotes.add(new Quote("History is written by the victors.", "Winston Churchill", "History"));
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String word = request.getParameter("word");
        List<Quote> searchResults = quotes.stream()
                .filter(q -> q.getText().contains(word))
                .collect(Collectors.toList());

        request.setAttribute("searchResults", searchResults);
        RequestDispatcher dispatcher = request.getRequestDispatcher("search.jsp");
        dispatcher.forward(request, response);
    }
}