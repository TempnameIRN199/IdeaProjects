package org.example.jspproj;

import java.util.*;

public class QuizManager {
    private static final Map<String, List<Question>> questionsMap = new HashMap<>();

    static {
        // Initialize questions
        questionsMap.put("History", Arrays.asList(
                new Question("Who was the first president of the USA?", new String[]{"George Washington", "Abraham Lincoln", "Thomas Jefferson", "John Adams"}, "A", false, ""),
                new Question("Year of the fall of the Roman Empire?", null, null, true, "476")
        ));

        questionsMap.put("Sports", Arrays.asList(
                new Question("How many players are on a soccer team?", new String[]{"9", "10", "11", "12"}, "C", false, ""),
                new Question("Olympics year when Usain Bolt won first gold?", null, null, true, "2008")
        ));

        questionsMap.put("Pop-culture", Arrays.asList(
                new Question("Who directed 'Inception'?", new String[]{"Steven Spielberg", "Christopher Nolan", "James Cameron", "Quentin Tarantino"}, "B", false, ""),
                new Question("Name of Harry Potter’s owl?", null, null, true, "Hedwig")
        ));

        questionsMap.put("Space", Arrays.asList(
                new Question("First man on the moon?", new String[]{"Buzz Aldrin", "Yuri Gagarin", "Neil Armstrong", "Michael Collins"}, "C", false, ""),
                new Question("What planet is known as the Red Planet?", null, null, true, "Mars")
        ));
    }

    public static List<Question> getQuestions(String category) {
        return new ArrayList<>(questionsMap.getOrDefault(category, new ArrayList<>()));
    }
}