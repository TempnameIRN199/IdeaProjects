package org.example.jspproj;

public class Question
{
    private String text;
    private String[] options;
    private String correctOption;
    private boolean isOpenQuestion;
    private String correctAnswer;

    public Question(String text, String[] options, String correctOption, boolean isOpenQuestion, String correctAnswer) {
        this.text = text;
        this.options = options;
        this.correctOption = correctOption;
        this.isOpenQuestion = isOpenQuestion;
        this.correctAnswer = correctAnswer;
    }

    public String getText() { return text; }
    public String[] getOptions() { return options; }
    public String getCorrectOption() { return correctOption; }
    public boolean isOpenQuestion() { return isOpenQuestion; }
    public String getCorrectAnswer() { return correctAnswer; }
}