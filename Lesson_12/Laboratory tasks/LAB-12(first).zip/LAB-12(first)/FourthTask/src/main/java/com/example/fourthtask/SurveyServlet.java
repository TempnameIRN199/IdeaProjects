package com.example.fourthtask;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/survey") // Servlet accessible via /FourthTask_war_exploded/survey
public class SurveyServlet extends HttpServlet {

    // Task 4: Survey Form (GET)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Survey</title></head><body>");
        out.println("<h2>Please fill out the survey:</h2>");
        out.println("<form action='/FourthTask_war_exploded/survey' method='POST'>"); // Updated action path
        out.println("Full Name: <input type='text' name='name' required><br>");
        out.println("Phone: <input type='text' name='phone' required><br>");
        out.println("Email: <input type='email' name='email' required><br>");
        out.println("Age: <input type='number' name='age' required><br>");
        out.println("Subscribe to newsletter: <input type='checkbox' name='newsletter'><br>");
        out.println("Gender: ");
        out.println("<input type='radio' name='gender' value='Male' required> Male ");
        out.println("<input type='radio' name='gender' value='Female' required> Female ");
        out.println("<input type='radio' name='gender' value='Other' required> Other <br>");
        out.println("<input type='submit' value='Submit'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    // Task 4-7: Process the survey form (POST)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");
        String age = request.getParameter("age");
        String newsletter = request.getParameter("newsletter") != null ? "Yes" : "No";
        String gender = request.getParameter("gender");

        // Validate data
        boolean valid = true;
        if (name == null || name.isEmpty()) {
            valid = false;
            out.println("Name is required.<br>");
        }
        if (phone == null || phone.isEmpty() || !phone.matches("\\d+")) {
            valid = false;
            out.println("Phone is required and should contain only numbers.<br>");
        }
        if (email == null || email.isEmpty() || !email.contains("@")) {
            valid = false;
            out.println("Email is required and must be valid.<br>");
        }
        if (age == null || age.isEmpty() || Integer.parseInt(age) < 18) {
            valid = false;
            out.println("Age must be at least 18.<br>");
        }

        if (valid) {
            out.println("<html><head><title>Survey Results</title></head><body>");
            out.println("<h2>Your Survey Information:</h2>");
            out.println("Full Name: " + name + "<br>");
            out.println("Phone: " + phone + "<br>");
            out.println("Email: " + email + "<br>");
            out.println("Age: " + age + "<br>");
            out.println("Subscribed to Newsletter: " + newsletter + "<br>");
            out.println("Gender: " + gender + "<br>");
            out.println("</body></html>");
        }
    }
}