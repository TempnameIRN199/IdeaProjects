package com.example.secondtask;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/multiplication") // Servlet accessible via /multiplication
public class MultiplicationTableServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // HTML Form for user input
        out.println("<html><head><title>Multiplication Table</title></head><body>");
        out.println("<h2>Enter a number to see its multiplication table</h2>");
        out.println("<form action='/SecondTask_war_exploded/multiplication' method='POST'>");
        out.println("<input type='number' name='number' required>");
        out.println("<input type='submit' value='Generate Table'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Get the input number
        String numberStr = request.getParameter("number");

        out.println("<html><head><title>Multiplication Table</title></head><body>");
        try {
            int number = Integer.parseInt(numberStr);
            out.println("<h2>Multiplication Table for " + number + "</h2>");
            out.println("<table border='1' cellpadding='5' cellspacing='0'>");
            for (int i = 1; i <= 10; i++) {
                out.println("<tr><td>" + number + " x " + i + "</td><td>=</td><td>" + (number * i) + "</td></tr>");
            }
            out.println("</table>");
        } catch (NumberFormatException e) {
            out.println("<p style='color:red;'>Invalid input. Please enter a valid number.</p>");
        }
        out.println("<br><a href='/multiplication'>Try Again</a>");
        out.println("</body></html>");
    }
}