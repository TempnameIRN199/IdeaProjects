package com.example.thirdtask;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/startGame") // Servlet accessible via /startGame
public class GameServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set response content type
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Initialize the game session
        HttpSession session = request.getSession();
        session.setAttribute("lowerBound", 0);
        session.setAttribute("upperBound", 100);
        session.setAttribute("currentGuess", (0 + 100) / 2); // Initial guess: 50

        // Ask the user to provide feedback on the guess
        out.println("<html><head><title>Guess the Number Game</title></head><body>");
        out.println("<h2>Welcome to the Guess the Number Game!</h2>");
        out.println("<p>Is your number greater than, less than, or equal to: " + session.getAttribute("currentGuess") + "?</p>");
        out.println("<form action='/ThirdTask_war_exploded/guessFeedback' method='POST'>");
        out.println("<input type='radio' name='feedback' value='greater'> Greater than<br>");
        out.println("<input type='radio' name='feedback' value='less'> Less than<br>");
        out.println("<input type='radio' name='feedback' value='equal'> Equal<br>");
        out.println("<input type='submit' value='Submit Feedback'>");
        out.println("</form>");
        out.println("</body></html>");
    }
}