package com.example.thirdtask;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/guessFeedback") // Servlet accessible via /guessFeedback
public class GuessFeedbackServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the user feedback
        String feedback = request.getParameter("feedback");

        // Retrieve game state from session
        HttpSession session = request.getSession();
        int lowerBound = (int) session.getAttribute("lowerBound");
        int upperBound = (int) session.getAttribute("upperBound");
        int currentGuess = (int) session.getAttribute("currentGuess");

        // Adjust bounds based on feedback
        if ("greater".equals(feedback)) {
            lowerBound = currentGuess + 1;
        } else if ("less".equals(feedback)) {
            upperBound = currentGuess - 1;
        } else if ("equal".equals(feedback)) {
            // If the guess is correct, congratulate the user
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<html><head><title>Guess the Number Game</title></head><body>");
            out.println("<h2>Yay! I guessed your number: " + currentGuess + "!</h2>");
            out.println("<p><a href='/ThirdTask_war_exploded/startGame'>Play again</a></p>");
            out.println("</body></html>");
            return;
        }

        // Update the session with the new bounds and guess
        currentGuess = (lowerBound + upperBound) / 2;
        session.setAttribute("lowerBound", lowerBound);
        session.setAttribute("upperBound", upperBound);
        session.setAttribute("currentGuess", currentGuess);

        // Show the new guess and ask for feedback again
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Guess the Number Game</title></head><body>");
        out.println("<h2>Guess the Number Game</h2>");
        out.println("<p>Is your number greater than, less than, or equal to: " + currentGuess + "?</p>");
        out.println("<form action='/ThirdTask_war_exploded/guessFeedback' method='POST'>");
        out.println("<input type='radio' name='feedback' value='greater'> Greater than<br>");
        out.println("<input type='radio' name='feedback' value='less'> Less than<br>");
        out.println("<input type='radio' name='feedback' value='equal'> Equal<br>");
        out.println("<input type='submit' value='Submit Feedback'>");
        out.println("</form>");
        out.println("</body></html>");
    }
}