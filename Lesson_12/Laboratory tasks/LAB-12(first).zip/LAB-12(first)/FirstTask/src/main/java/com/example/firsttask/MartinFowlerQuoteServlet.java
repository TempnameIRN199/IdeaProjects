package com.example.firsttask;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/quote") // Defines the URL mapping for this servlet
public class MartinFowlerQuoteServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Martin Fowler Quote</title></head><body>");
        out.println("<h2>Martin Fowler on Code Quality</h2>");
        out.println("<p>\"Any fool can write code that a computer can understand.<br>");
        out.println("Good programmers write code that humans can understand.\"</p>");
        out.println("</body></html>");
    }
}
