import jakarta.servlet.ServletContext;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/validation")
public class ValidationServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    public ValidationServlet()
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		if (isValid(request))
		{
			ServletContext servletContext = getServletContext();
			RequestDispatcher requestDispatcher = servletContext.getRequestDispatcher("/params");
			
			try
			{
				requestDispatcher.forward(request, response);
			}
			catch (ServletException exc)
			{
				exc.printStackTrace();
			}
		}
		else
		{
			response.setContentType("text/html");
			
			response.getWriter().append("Values are incorrect! <a href=\"index.html\">Try again</a>");
		}
	}
	
	private boolean isValid(HttpServletRequest request)
	{
		String surname = request.getParameter("surname"),
			name = request.getParameter("name"),
			gender = request.getParameter("gender");
		
		if (surname != null && surname.length() >= 1 && 
			name != null &&	name.length() >= 1 &&
			gender != null && gender.length() >= 1 &&
			gender.equals("female") || gender.equals("male") || gender.equals("other"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
