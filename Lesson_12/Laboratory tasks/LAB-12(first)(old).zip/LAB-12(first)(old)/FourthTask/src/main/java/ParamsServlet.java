import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/params")
public class ParamsServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;

    public ParamsServlet()
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.getWriter().println("Surname: " + request.getParameter("surname"));
		response.getWriter().println("Name: " + request.getParameter("name"));
		response.getWriter().println("Patronymic: " + request.getParameter("patronymic"));
		response.getWriter().println("Subscription: " + request.getParameter("subscription"));
		response.getWriter().println("Gender: " + request.getParameter("gender"));
	}
}
