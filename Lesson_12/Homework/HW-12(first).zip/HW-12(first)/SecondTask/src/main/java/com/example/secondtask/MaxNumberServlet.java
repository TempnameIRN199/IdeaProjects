package com.example.secondtask;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/maxnumber")  // Accessible at /SecondTask_war_exploded/maxnumber
public class MaxNumberServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Form to input three numbers
        out.println("<html><head><title>Max of Three Numbers</title></head><body>");
        out.println("<h2>Enter three numbers to find the maximum:</h2>");
        out.println("<form action='/SecondTask_war_exploded/maxnumber' method='POST'>");  // Updated action path
        out.println("Number 1: <input type='number' name='num1' required><br>");
        out.println("Number 2: <input type='number' name='num2' required><br>");
        out.println("Number 3: <input type='number' name='num3' required><br>");
        out.println("<input type='submit' value='Find Maximum'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Get the three numbers from the form input
        String num1Str = request.getParameter("num1");
        String num2Str = request.getParameter("num2");
        String num3Str = request.getParameter("num3");

        try {
            // Parse the input numbers
            int num1 = Integer.parseInt(num1Str);
            int num2 = Integer.parseInt(num2Str);
            int num3 = Integer.parseInt(num3Str);

            // Calculate the maximum number
            int maxNumber = Math.max(num1, Math.max(num2, num3));

            // Display the result
            out.println("<html><head><title>Max of Three Numbers</title></head><body>");
            out.println("<h2>Numbers entered:</h2>");
            out.println("Number 1: " + num1 + "<br>");
            out.println("Number 2: " + num2 + "<br>");
            out.println("Number 3: " + num3 + "<br>");
            out.println("<h3>Maximum Value: " + maxNumber + "</h3>");
            out.println("</body></html>");
        } catch (NumberFormatException e) {
            // If the user enters invalid input, show an error message
            out.println("<html><head><title>Max of Three Numbers</title></head><body>");
            out.println("<h2>Error: Invalid input. Please enter valid numbers.</h2>");
            out.println("</body></html>");
        }
    }
}