package com.example.firsttask;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/quote")  // Accessible at /FirstTask_war_exploded/quote
public class QuoteServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Output the quote from Linus Torvalds
        out.println("<html><head><title>Linus Torvalds Quote</title></head><body>");
        out.println("<h2>Quote from Linus Torvalds:</h2>");
        out.println("<p><i>Bad programmers worry about the code. Good programmers worry about data structures and their relationships.</i></p>");
        out.println("</body></html>");
    }
}