package com.example.fourthtask;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/textanalysis")  // Accessible at /FourthTask_war_exploded/textanalysis
public class TextAnalysisServlet extends HttpServlet {

    // Method to check if a character is a vowel
    private boolean isVowel(char c) {
        c = Character.toLowerCase(c);
        return "aeiou".indexOf(c) != -1;  // English vowels
    }

    // Method to check if a character is a consonant
    private boolean isConsonant(char c) {
        c = Character.toLowerCase(c);
        return (Character.isLetter(c) && !isVowel(c));  // Consonant if it's a letter but not a vowel
    }

    // Method to check if a character is a punctuation mark
    private boolean isPunctuation(char c) {
        return ",.!?;:()[]{}\"'".indexOf(c) != -1;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Form to input text
        out.println("<html><head><title>Text Analysis</title></head><body>");
        out.println("<h2>Enter text for analysis:</h2>");
        out.println("<form action='/FourthTask_war_exploded/textanalysis' method='POST'>");  // Updated action path for Task 4
        out.println("<textarea name='text' rows='5' cols='50' required></textarea><br>");
        out.println("<input type='submit' value='Analyze Text'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Get the text entered by the user
        String text = request.getParameter("text");

        // Variables to hold counts and sets of characters
        int vowelCount = 0;
        int consonantCount = 0;
        int punctuationCount = 0;
        Set<Character> vowels = new HashSet<>();
        Set<Character> consonants = new HashSet<>();
        Set<Character> punctuations = new HashSet<>();

        // Analyze the text
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (isVowel(c)) {
                vowelCount++;
                vowels.add(c);
            } else if (isConsonant(c)) {
                consonantCount++;
                consonants.add(c);
            } else if (isPunctuation(c)) {
                punctuationCount++;
                punctuations.add(c);
            }
        }

        // Display the analysis results
        out.println("<html><head><title>Text Analysis Result</title></head><body>");
        out.println("<h2>Analysis of your text:</h2>");
        out.println("<p><strong>Total number of vowels:</strong> " + vowelCount + "</p>");
        out.println("<p><strong>Vowels used: </strong>" + vowels + "</p>");
        out.println("<p><strong>Total number of consonants:</strong> " + consonantCount + "</p>");
        out.println("<p><strong>Consonants used: </strong>" + consonants + "</p>");
        out.println("<p><strong>Total number of punctuation marks:</strong> " + punctuationCount + "</p>");
        out.println("<p><strong>Punctuation marks used: </strong>" + punctuations + "</p>");
        out.println("<br><a href='/FourthTask_war_exploded/textanalysis'>Analyze Another Text</a>");
        out.println("</body></html>");
    }
}