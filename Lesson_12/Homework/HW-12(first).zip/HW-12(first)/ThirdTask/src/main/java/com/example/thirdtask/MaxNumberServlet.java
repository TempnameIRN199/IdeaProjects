package com.example.thirdtask;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/maxnumber")  // Accessible at /ThirdTask_war_exploded/maxnumber
public class MaxNumberServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Form to input three numbers and choose the operation (max, min, average)
        out.println("<html><head><title>Max, Min, and Average of Three Numbers</title></head><body>");
        out.println("<h2>Enter three numbers and choose the operation:</h2>");
        out.println("<form action='/ThirdTask_war_exploded/maxnumber' method='POST'>");  // Updated action path
        out.println("Number 1: <input type='number' name='num1' required><br>");
        out.println("Number 2: <input type='number' name='num2' required><br>");
        out.println("Number 3: <input type='number' name='num3' required><br>");

        out.println("Select the operation: <br>");
        out.println("<input type='radio' name='operation' value='max' required> Maximum<br>");
        out.println("<input type='radio' name='operation' value='min'> Minimum<br>");
        out.println("<input type='radio' name='operation' value='avg'> Average<br>");

        out.println("<input type='submit' value='Calculate'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Get the three numbers from the form input
        String num1Str = request.getParameter("num1");
        String num2Str = request.getParameter("num2");
        String num3Str = request.getParameter("num3");
        String operation = request.getParameter("operation");

        try {
            // Parse the input numbers
            int num1 = Integer.parseInt(num1Str);
            int num2 = Integer.parseInt(num2Str);
            int num3 = Integer.parseInt(num3Str);

            int result = 0;
            String resultMessage = "";

            // Perform the selected operation
            if ("max".equals(operation)) {
                result = Math.max(num1, Math.max(num2, num3));
                resultMessage = "Maximum Value: " + result;
            } else if ("min".equals(operation)) {
                result = Math.min(num1, Math.min(num2, num3));
                resultMessage = "Minimum Value: " + result;
            } else if ("avg".equals(operation)) {
                double average = (num1 + num2 + num3) / 3.0;
                resultMessage = "Average Value: " + average;
            }

            // Display the result
            out.println("<html><head><title>Calculation Result</title></head><body>");
            out.println("<h2>Numbers entered:</h2>");
            out.println("Number 1: " + num1 + "<br>");
            out.println("Number 2: " + num2 + "<br>");
            out.println("Number 3: " + num3 + "<br>");
            out.println("<h3>" + resultMessage + "</h3>");
            out.println("</body></html>");
        } catch (NumberFormatException e) {
            // If the user enters invalid input, show an error message
            out.println("<html><head><title>Error</title></head><body>");
            out.println("<h2>Error: Invalid input. Please enter valid numbers.</h2>");
            out.println("</body></html>");
        }
    }
}