package com.example.fifthtask;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/calculator")  // Accessible at /FifthTask_war_exploded/calculator
public class CalculatorServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Display the calculator form
        out.println("<html><head><title>Calculator</title></head><body>");
        out.println("<h2>Calculator</h2>");
        out.println("<form action='/FifthTask_war_exploded/calculator' method='POST'>");  // Updated action path for Task 5
        out.println("<input type='number' name='num1' required placeholder='First number'><br>");
        out.println("<input type='number' name='num2' required placeholder='Second number'><br>");
        out.println("<select name='operation'>");
        out.println("<option value='add'>Addition (+)</option>");
        out.println("<option value='subtract'>Subtraction (-)</option>");
        out.println("<option value='multiply'>Multiplication (*)</option>");
        out.println("<option value='divide'>Division (/)</option>");
        out.println("<option value='power'>Exponentiation (^)</option>");
        out.println("<option value='percentage'>Percentage (%)</option>");
        out.println("</select><br>");
        out.println("<input type='submit' value='Calculate'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Retrieve the numbers and selected operation from the form
        double num1 = Double.parseDouble(request.getParameter("num1"));
        double num2 = Double.parseDouble(request.getParameter("num2"));
        String operation = request.getParameter("operation");
        double result = 0;

        out.println("<html><head><title>Calculator Result</title></head><body>");
        out.println("<h2>Result:</h2>");
        out.println("<p>First number: " + num1 + "</p>");
        out.println("<p>Second number: " + num2 + "</p>");

        switch (operation) {
            case "add":
                result = num1 + num2;
                out.println("<p>Operation: Addition</p>");
                out.println("<p>Result: " + result + "</p>");
                break;
            case "subtract":
                result = num1 - num2;
                out.println("<p>Operation: Subtraction</p>");
                out.println("<p>Result: " + result + "</p>");
                break;
            case "multiply":
                result = num1 * num2;
                out.println("<p>Operation: Multiplication</p>");
                out.println("<p>Result: " + result + "</p>");
                break;
            case "divide":
                if (num2 != 0) {
                    result = num1 / num2;
                    out.println("<p>Operation: Division</p>");
                    out.println("<p>Result: " + result + "</p>");
                } else {
                    out.println("<p style='color:red;'>Error: Cannot divide by zero!</p>");
                }
                break;
            case "power":
                result = Math.pow(num1, num2);
                out.println("<p>Operation: Exponentiation</p>");
                out.println("<p>Result: " + result + "</p>");
                break;
            case "percentage":
                result = (num1 * num2) / 100;
                out.println("<p>Operation: Percentage</p>");
                out.println("<p>Result: " + result + "</p>");
                break;
            default:
                out.println("<p style='color:red;'>Error: Invalid operation.</p>");
                break;
        }

        out.println("<br><a href='/FifthTask_war_exploded/calculator'>Perform Another Calculation</a>");
        out.println("</body></html>");
    }
}