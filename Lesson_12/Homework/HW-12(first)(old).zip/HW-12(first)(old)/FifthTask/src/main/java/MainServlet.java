import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/main")
public class MainServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
    
    public MainServlet()
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter writer = response.getWriter();
		
		response.setContentType("text/html");
		
		writeForm(writer);
		
		if (request.getParameter("") != null)
		{
			double firstNumber = Double.parseDouble(request.getParameter("first-action")),
				   secondNumber = Double.parseDouble(request.getParameter("second-action")),
				   thirdNumber = 0.0D;
			
			switch (request.getParameter("math-action"))
			{
				case "*":
				{
					thirdNumber = firstNumber * secondNumber;
					break;
				}
				
				case "/":
				{
					thirdNumber = firstNumber / secondNumber;
					break;
				}
				
				case "+":
				{
					thirdNumber = firstNumber + secondNumber;
					break;
				}
				
				case "-":
				{
					thirdNumber = firstNumber - secondNumber;
					break;
				}
			}
			
			writer.append("<p>" + "result: " + thirdNumber + "</p>");
		}
	}
	
	private void writeForm(PrintWriter writer)
	{
		writer.append("<form method=\"GET\" action=\"\">");
			writer.append("<input name=\"action\" type=\"hidden\">");
		
			writer.append("<input name=\"first-number\" type=\"number\">");
			
			writer.append("<br>");
			
			writer.append("<input name=\"second-number\" type=\"number\">");
			
			writer.append("<br>");
			
			writer.append("<input name=\"math-action\" type=\"radio\" value=\"*\">");
			
			writer.append("<br>");
			
			writer.append("<input name=\"math-action\" type=\"radio\" value=\"/\">");
			
			writer.append("<br>");
			
			writer.append("<input name=\"math-action\" type=\"radio\" value=\"+\">");
			
			writer.append("<br>");
			
			writer.append("<input name=\"math-action\" type=\"radio\" value=\"-\">");
			
			writer.append("<br>");)
			
			writer.append("<button type=\"submit\">GET</button>");
			
		writer.append("</form>");
	}
}
