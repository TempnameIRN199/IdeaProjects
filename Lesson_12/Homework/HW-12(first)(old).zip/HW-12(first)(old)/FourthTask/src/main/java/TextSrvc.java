import java.util.List;
import java.util.ArrayList;

public final class TextSrvc
{
	public static List<Character> getVowels(String text) {
        List<Character> vowels = new ArrayList<>();
        String vowelSet = "AEIOUaeiou";
        
        for (char c : text.toCharArray()) {
            if (vowelSet.indexOf(c) != -1) {
                vowels.add(c);
            }
        }
        return vowels;
    }

    // Method to get a list of consonants from the input text
    public static List<Character> getConsonants(String text) {
        List<Character> consonants = new ArrayList<>();
        
        for (char c : text.toCharArray()) {
            if (Character.isLetter(c) && "AEIOUaeiou".indexOf(c) == -1) {
                consonants.add(c);
            }
        }
        return consonants;
    }

    // Method to get a list of punctuation marks from the input text
    public static List<Character> getPunctuationMarks(String text) {
        List<Character> punctuationMarks = new ArrayList<>();
        String punctuationSet = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~";
        
        for (char c : text.toCharArray()) {
            if (punctuationSet.indexOf(c) != -1) {
                punctuationMarks.add(c);
            }
        }
        return punctuationMarks;
    }
}
