import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Arrays;

@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    public MainServlet()
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter writer = response.getWriter();
		String text = request.getParameter("text");
		
		response.setContentType("text/html");
		
		{
			List<Character> tmpList = TextSrvc.getVowels(text);
			
			writer.append("<div>");
			writer.append("Vowels: " + tmpList.length);
			writer.append(Arrays.toString(tmpList));
			writer.append("</div>");
		})
		
		{
			List<Character> tmpList = TextSrvc.getConsonants(text);
			
			writer.append("<div>");
			writer.append("Consonants: " + tmpList.length);
			writer.append(Arrays.toString(tmpList));
			writer.append("</div>");
		}
		
		{
			List<Character> tmpList = TextSrvc.getPunctuationMarks(text);
			
			writer.append("<div>");
			writer.append("Punctation Marks: " + tmpList.length);
			writer.append(Arrays.toString(tmpList));
			writer.append("</div>");
		}
	}
}
