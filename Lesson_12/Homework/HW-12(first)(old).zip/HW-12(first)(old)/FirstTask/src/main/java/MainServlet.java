import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/main")
public class MainServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    public MainServlet()
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		response.getWriter().append
		(
			"<p>Linus Torvalds: " +
			"Bad programmers worry about the code. " +
			"Good programmers worry about data structures and their relationships</p>"
		);
	}
}
