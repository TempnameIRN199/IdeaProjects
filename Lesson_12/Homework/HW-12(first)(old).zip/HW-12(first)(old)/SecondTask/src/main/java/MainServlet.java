import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
     
    public MainServlet()
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter currWriter = response.getWriter();
		
		response.setContentType("text/html");
		
		writeForm(currWriter);
		
		if (request.getParameter("action") != null)
		{
			int firstNumber = Integer.parseInt(request.getParameter("first-number")),
				secondNumber = Integer.parseInt(request.getParameter("second-number")),
				thirdNumber = Integer.parseInt(request.getParameter("third-number"));
			
			switch (request.getParameter("math-action"))
			{
				case "min":
				{
					currWriter.println("<p>" + "MIN: " + Math.min(firstNumber, Math.max(secondNumber, thirdNumber)) + "</p>");
					
					break;
				}
				
				case "max":
				{
					currWriter.println("<p>" + "MAX: " + Math.max(firstNumber, Math.max(secondNumber, thirdNumber)) + "</p>");
					
					break;
				}
				
				case "avg":
				{
					currWriter.println("<p>" + "AVG: " + (firstNumber + secondNumber + thirdNumber) / 3);
					
					break;
				}
			}
		}
	}
	
	private void writeForm(PrintWriter writer)
	{
		writer.println("<form method=\"GET\">");
		
			writer.append("<input name=\"action\" type=\"hidden\" value=\"get\">");
			writer.append("<input name=\"first-number\" type=\"number\" placeholder=\"first-number\">");
			writer.append("<input name=\"second-number\" type=\"number\" placeholder=\"second-number\">");
			writer.append("<input name=\"third-number\" type=\"number\" placeholder=\"third-number\">");
			
			writer.append("<br>");)
			
			writer.append("<label>");
				writer.append("MIN");
				writer.append("<input name=\"math-action\" type=\"radio\" value=\"min\">");
			writer.append("</label>");
			
			writer.append("<br>");
			
			writer.append("<label>");
				writer.append("MAX");
				writer.append("<input name=\"math-action\" type=\"radio\" value=\"max\">");
			writer.append("</label>");
			
			writer.append("<br>");
			
			writer.append("<label>");
				writer.append("AVG");
				writer.append("<input name=\"math-action\" type=\"radio\" value=\"avg\">");
			writer.append("</label>");
			
			writer.append("<br>");
			
			writer.append("<button type=\"submit\">GET</button>");
		
		writer.append("</form>");
	}
}
