package interfaces;

public interface IMath
{
	int min();
	int max();
	
	double avg();
}
