package interfaces;

public interface ISort
{
	void sortAsc();
	void sortDsc();
}
