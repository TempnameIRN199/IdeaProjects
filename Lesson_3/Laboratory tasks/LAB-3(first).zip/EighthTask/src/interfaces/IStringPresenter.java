package interfaces;

public interface IStringPresenter
{
	String createStringPresentation();
	String createStringPresentation(Object addtlInfo);
}
