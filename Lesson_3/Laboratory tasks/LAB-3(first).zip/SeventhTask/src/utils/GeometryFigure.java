package utils;

public abstract class GeometryFigure
{	
	public abstract double calcArea();
}
