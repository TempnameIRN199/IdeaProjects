import java.util.Map;
import java.util.TreeMap;

public class Main {
    public static void main(String[] args) {
        // Creating a TreeMap to store product names and their prices
        TreeMap<String, Double> productPrices = new TreeMap<>();

        // Adding products and their prices to the TreeMap
        productPrices.put("Laptop", 999.99);
        productPrices.put("Smartphone", 799.49);
        productPrices.put("Headphones", 149.99);
        productPrices.put("Keyboard", 89.99);
        productPrices.put("Monitor", 349.99);

        // Finding the product with the highest price
        Map.Entry<String, Double> maxPriceProduct = findMaxPriceProduct(productPrices);
        if (maxPriceProduct != null) {
            System.out.println("Product with the highest price: " +
                    maxPriceProduct.getKey() + " - $" + maxPriceProduct.getValue());
        }

        // Displaying all products in sorted order (TreeMap sorts by key)
        System.out.println("\nAll products in sorted order by name:");
        for (Map.Entry<String, Double> entry : productPrices.entrySet()) {
            System.out.println("Product: " + entry.getKey() + ", Price: $" + entry.getValue());
        }
    }

    // Method to find the product with the highest price
    private static Map.Entry<String, Double> findMaxPriceProduct(TreeMap<String, Double> productPrices) {
        Map.Entry<String, Double> maxPriceProduct = null;
        for (Map.Entry<String, Double> entry : productPrices.entrySet()) {
            if (maxPriceProduct == null || entry.getValue() > maxPriceProduct.getValue()) {
                maxPriceProduct = entry;
            }
        }
        return maxPriceProduct;
    }
}