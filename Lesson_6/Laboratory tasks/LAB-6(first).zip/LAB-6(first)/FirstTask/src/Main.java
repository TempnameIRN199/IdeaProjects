import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

public class Main {
    public static void main(String[] args) {
        // Creating a HashMap to store student names and their grades
        HashMap<String, Integer> studentGrades = new HashMap<>();

        // Adding students and their grades to the HashMap
        studentGrades.put("John", 85);
        studentGrades.put("Emily", 92);
        studentGrades.put("Michael", 76);
        studentGrades.put("Sophia", 89);
        studentGrades.put("James", 54);

        // Updating the grade of one student (e.g., changing John's grade)
        studentGrades.put("John", 90);

        // Finding and removing the student with the lowest grade
        String studentToRemove = findStudentWithLowestGrade(studentGrades);
        studentGrades.remove(studentToRemove);

        // Displaying all students and their grades
        System.out.println("Updated student grades:");
        for (Map.Entry<String, Integer> entry : studentGrades.entrySet()) {
            System.out.println("Student: " + entry.getKey() + ", Grade: " + entry.getValue());
        }
    }

    // Method to find the student with the lowest grade
    private static String findStudentWithLowestGrade(HashMap<String, Integer> studentGrades) {
        String studentWithLowestGrade = null;
        int lowestGrade = Integer.MAX_VALUE;

        Iterator<Map.Entry<String, Integer>> iterator = studentGrades.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, Integer> entry = iterator.next();
            if (entry.getValue() < lowestGrade) {
                lowestGrade = entry.getValue();
                studentWithLowestGrade = entry.getKey();
            }
        }

        return studentWithLowestGrade;
    }
}