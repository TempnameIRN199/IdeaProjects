import java.util.HashSet;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Creating a scanner object to read input from the user
        Scanner scanner = new Scanner(System.in);

        // Prompting the user to enter a list of numbers
        System.out.println("Enter a list of numbers separated by spaces:");
        String input = scanner.nextLine();

        // Splitting the input string into individual numbers and parsing them as integers
        String[] inputNumbers = input.split(" ");
        HashSet<Integer> numberSet = new HashSet<>();

        // Adding the numbers to the HashSet to remove duplicates
        for (String number : inputNumbers) {
            try {
                numberSet.add(Integer.parseInt(number));
            } catch (NumberFormatException e) {
                System.out.println("Invalid number input: " + number);
            }
        }

        // Converting the HashSet back into a list (ArrayList)
        ArrayList<Integer> uniqueNumbers = new ArrayList<>(numberSet);

        // Displaying the list of numbers without duplicates
        System.out.println("List of numbers without duplicates: " + uniqueNumbers);

        // Closing the scanner to avoid resource leaks
        scanner.close();
    }
}