import java.util.HashSet;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Creating a scanner object to read input from the user
        Scanner scanner = new Scanner(System.in);

        // Prompting the user to enter a text
        System.out.println("Enter a text:");
        String inputText = scanner.nextLine();

        // Converting the input text to lowercase and splitting it into words using non-word characters as delimiters
        String[] words = inputText.split("\\W+");

        // Creating a HashSet to store unique words
        HashSet<String> uniqueWords = new HashSet<>();

        // Adding each word to the HashSet
        for (String word : words) {
            if (!word.isEmpty()) {
                uniqueWords.add(word.toLowerCase()); // Convert to lowercase to ensure case-insensitive comparison
            }
        }

        // Displaying the unique words
        System.out.println("Unique words in the text:");
        for (String word : uniqueWords) {
            System.out.println(word);
        }

        // Closing the scanner to avoid resource leaks
        scanner.close();
    }
}