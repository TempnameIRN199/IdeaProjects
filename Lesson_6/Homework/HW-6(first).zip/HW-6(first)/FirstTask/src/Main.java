import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Creating a scanner object to read input from the user
        Scanner scanner = new Scanner(System.in);

        // Prompting the user to enter a string
        System.out.println("Enter a string:");
        String inputString = scanner.nextLine();

        // Creating a HashMap to store the frequency of each character
        HashMap<Character, Integer> charCountMap = new HashMap<>();

        // Iterating through the string and counting the frequency of each character
        for (char c : inputString.toCharArray()) {
            // If the character is already in the map, increment its count
            charCountMap.put(c, charCountMap.getOrDefault(c, 0) + 1);
        }

        // Displaying the frequency of each character
        System.out.println("Character frequencies:");
        for (Map.Entry<Character, Integer> entry : charCountMap.entrySet()) {
            System.out.println("Character: '" + entry.getKey() + "' - Frequency: " + entry.getValue());
        }

        // Closing the scanner to avoid resource leaks
        scanner.close();
    }
}