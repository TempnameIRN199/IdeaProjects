import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Main {
    public static void main(String[] args) {
        // Creating a TreeMap to store the phonebook, with the name as the key and the phone number as the value
        TreeMap<String, String> phoneBook = new TreeMap<>();

        // Adding several records to the phonebook
        phoneBook.put("John Doe", "123-456-7890");
        phoneBook.put("Jane Smith", "987-654-3210");
        phoneBook.put("Emily Johnson", "555-123-4567");
        phoneBook.put("Michael Brown", "222-333-4444");
        phoneBook.put("Chris Davis", "777-888-9999");

        // Creating a scanner object to read input from the user
        Scanner scanner = new Scanner(System.in);

        // Prompting the user to enter the name of the person they want to search for
        System.out.println("Enter a name to search for their phone number:");
        String searchName = scanner.nextLine();

        // Searching for the phone number by name
        String phoneNumber = phoneBook.get(searchName);
        if (phoneNumber != null) {
            System.out.println("Phone number for " + searchName + ": " + phoneNumber);
        } else {
            System.out.println("No phone number found for " + searchName);
        }

        // Displaying all the entries in the phonebook in sorted order by name
        System.out.println("\nPhonebook entries (sorted by name):");
        for (Map.Entry<String, String> entry : phoneBook.entrySet()) {
            System.out.println("Name: " + entry.getKey() + ", Phone Number: " + entry.getValue());
        }

        // Closing the scanner to avoid resource leaks
        scanner.close();
    }
}