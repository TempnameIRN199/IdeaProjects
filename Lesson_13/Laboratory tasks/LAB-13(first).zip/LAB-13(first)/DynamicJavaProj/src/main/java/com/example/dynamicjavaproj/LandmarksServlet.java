package com.example.dynamicjavaproj;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/cityinfo/landmarks")  // Accessible at /cityinfo/landmarks
public class LandmarksServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Display landmarks of the city with images and external links
        out.println("<html><head><title>Landmarks</title></head><body>");
        out.println("<h2>Landmarks of Example City</h2>");
        out.println("<p>Example City is home to many beautiful landmarks...</p>");
        out.println("<img src='/DynamicJavaProj_war_exploded/landmark_image_1.jpg' alt='Landmark 1'><br>");
        out.println("<img src='/DynamicJavaProj_war_exploded/landmark_image_2.jpg' alt='Landmark 2'><br>");
        out.println("<p>For more details, visit <a href='https://example-landmark-link.com'>Example Landmark Resource</a></p>");
        out.println("<br><a href='/DynamicJavaProj_war_exploded/cityinfo'>Back to City Info</a>");
        out.println("</body></html>");
    }
}