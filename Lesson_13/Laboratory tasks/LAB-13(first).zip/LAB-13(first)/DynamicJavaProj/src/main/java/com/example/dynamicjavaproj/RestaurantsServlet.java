package com.example.dynamicjavaproj;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/cityinfo/restaurants")  // Accessible at /cityinfo/restaurants
public class RestaurantsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Display short descriptions of restaurants
        out.println("<html><head><title>Restaurants</title></head><body>");
        out.println("<h2>Restaurants in Example City</h2>");
        out.println("<p><strong>Restaurant 1</strong>: A cozy place with local dishes...</p>");
        out.println("<img src='/DynamicJavaProj_war_exploded/restaurant_1.jpg' alt='Restaurant 1'><br>");
        out.println("<p><a href='/DynamicJavaProj_war_exploded/cityinfo/restaurants/detail/1'>View Full Details</a></p>");
        out.println("<p><strong>Restaurant 2</strong>: Fine dining experience with international cuisine...</p>");
        out.println("<img src='/DynamicJavaProj_war_exploded/restaurant_2.jpg' alt='Restaurant 2'><br>");
        out.println("<p><a href='/DynamicJavaProj_war_exploded/cityinfo/restaurants/detail/2'>View Full Details</a></p>");
        out.println("<br><a href='/DynamicJavaProj_war_exploded/cityinfo'>Back to City Info</a>");
        out.println("</body></html>");
    }
}