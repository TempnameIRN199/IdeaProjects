package com.example.dynamicjavaproj;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/cityinfo") // Accessible at /cityinfo
public class CityInfoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Display city information
        out.println("<html><head><title>City Information</title></head><body>");
        out.println("<h2>City Information</h2>");
        out.println("<p><strong>City Name:</strong> Example City</p>");
        out.println("<p><strong>Country Name:</strong> Example Country</p>");
        out.println("<img src='/DynamicJavaProj_war_exploded/city_coat_of_arms.jpg' alt='Coat of Arms'><br>");
        out.println("<p><strong>Population:</strong> 1,000,000</p>");
        out.println("<p><strong>Description:</strong> Example City is known for its rich history and beautiful landscapes.</p>");
        out.println("<br><a href='/DynamicJavaProj_war_exploded/cityinfo/history'>History of the City</a>");
        out.println("<br><a href='/DynamicJavaProj_war_exploded/cityinfo/landmarks'>Landmarks</a>");
        out.println("<br><a href='/DynamicJavaProj_war_exploded/cityinfo/restaurants'>Restaurants</a>");
        out.println("<br><a href='/DynamicJavaProj_war_exploded/cityinfo/hotels'>Hotels</a>");
        out.println("</body></html>");
    }
}