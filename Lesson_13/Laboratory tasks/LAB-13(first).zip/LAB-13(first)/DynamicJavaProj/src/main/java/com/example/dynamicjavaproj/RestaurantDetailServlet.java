package com.example.dynamicjavaproj;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/cityinfo/restaurants/detail/*")  // Accessible at /cityinfo/restaurants/detail/{id}
public class RestaurantDetailServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Get restaurant ID from the URL
        String pathInfo = request.getPathInfo();
        String restaurantId = pathInfo != null ? pathInfo.split("/")[1] : "";

        // Display full restaurant details
        out.println("<html><head><title>Restaurant Details</title></head><body>");
        out.println("<h2>Restaurant Details for Restaurant " + restaurantId + "</h2>");
        out.println("<p>Full description of the restaurant...</p>");
        out.println("<img src='/DynamicJavaProj_war_exploded/restaurant_" + restaurantId + "_1.jpg' alt='Restaurant Image 1'><br>");
        out.println("<img src='/DynamicJavaProj_war_exploded/restaurant_" + restaurantId + "_2.jpg' alt='Restaurant Image 2'><br>");
        out.println("<p>Address: Example Street 456</p>");
        out.println("<p>Phone: 987-654-3210</p>");
        out.println("<p>Official Website: <a href='http://example-restaurant" + restaurantId + ".com'>Restaurant Website</a></p>");
        out.println("<br><a href='/DynamicJavaProj_war_exploded/cityinfo/restaurants'>Back to Restaurant List</a>");
        out.println("</body></html>");
    }
}