package com.example.dynamicjavaproj;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/cityinfo/history")  // Accessible at /cityinfo/history
public class HistoryServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Display history of the city with images and external links
        out.println("<html><head><title>City History</title></head><body>");
        out.println("<h2>History of Example City</h2>");
        out.println("<p>Example City has a long and fascinating history...</p>");
        out.println("<img src='/DynamicJavaProj_war_exploded/history_image_1.jpg' alt='History Image 1'><br>");
        out.println("<img src='/DynamicJavaProj_war_exploded/history_image_2.jpg' alt='History Image 2'><br>");
        out.println("<p>For more details, visit <a href='https://example-history-link.com'>Example History Resource</a></p>");
        out.println("<br><a href='/DynamicJavaProj_war_exploded/cityinfo'>Back to City Info</a>");
        out.println("</body></html>");
    }
}