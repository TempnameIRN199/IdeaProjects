package com.example.dynamicjavaproj;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/navigation")  // Accessible at /navigation
public class NavigationMenuServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Display navigation menu
        out.println("<html><head><title>Navigation Menu</title></head><body>");
        out.println("<h2>Navigation Menu</h2>");
        out.println("<nav>");
        out.println("<ul style='list-style-type: none; display: flex;'>");
        out.println("<li><a href='/DynamicJavaProj_war_exploded/cityinfo'>General Information</a></li>");
        out.println("<li><a href='/DynamicJavaProj_war_exploded/cityinfo/history'>History</a></li>");
        out.println("<li><a href='/DynamicJavaProj_war_exploded/cityinfo/landmarks'>Landmarks</a></li>");
        out.println("<li><a href='/DynamicJavaProj_war_exploded/cityinfo/restaurants'>Restaurants</a></li>");
        out.println("<li><a href='/DynamicJavaProj_war_exploded/cityinfo/hotels'>Hotels</a></li>");
        out.println("</ul>");
        out.println("</nav>");
        out.println("</body></html>");
    }
}