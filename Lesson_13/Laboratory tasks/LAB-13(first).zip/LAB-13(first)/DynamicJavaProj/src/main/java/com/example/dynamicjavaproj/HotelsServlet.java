package com.example.dynamicjavaproj;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/cityinfo/hotels")  // Accessible at /cityinfo/hotels
public class HotelsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Display short descriptions of hotels
        out.println("<html><head><title>Hotels</title></head><body>");
        out.println("<h2>Hotels in Example City</h2>");
        out.println("<p><strong>Hotel 1</strong>: A beautiful hotel located downtown...</p>");
        out.println("<img src='/DynamicJavaProj_war_exploded/hotel_1.jpg' alt='Hotel 1'><br>");
        out.println("<p><a href='/DynamicJavaProj_war_exploded/cityinfo/hotels/detail/1'>View Full Details</a></p>");
        out.println("<p><strong>Hotel 2</strong>: A luxury hotel by the river...</p>");
        out.println("<img src='/DynamicJavaProj_war_exploded/hotel_2.jpg' alt='Hotel 2'><br>");
        out.println("<p><a href='/DynamicJavaProj_war_exploded/cityinfo/hotels/detail/2'>View Full Details</a></p>");
        out.println("<br><a href='/DynamicJavaProj_war_exploded/cityinfo'>Back to City Info</a>");
        out.println("</body></html>");
    }
}