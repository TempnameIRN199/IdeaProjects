package com.example.dynamicjavaproj;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/cityinfo/hotels/detail/*")  // Accessible at /cityinfo/hotels/detail/{id}
public class HotelDetailServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Get hotel ID from the URL
        String pathInfo = request.getPathInfo();
        String hotelId = pathInfo != null ? pathInfo.split("/")[1] : "";

        // Display full hotel details
        out.println("<html><head><title>Hotel Details</title></head><body>");
        out.println("<h2>Hotel Details for Hotel " + hotelId + "</h2>");
        out.println("<p>Full description of the hotel...</p>");
        out.println("<img src='/DynamicJavaProj_war_exploded/hotel_" + hotelId + "_1.jpg' alt='Hotel Image 1'><br>");
        out.println("<img src='/DynamicJavaProj_war_exploded/hotel_" + hotelId + "_2.jpg' alt='Hotel Image 2'><br>");
        out.println("<p>Address: Example Street 123</p>");
        out.println("<p>Phone: 123-456-7890</p>");
        out.println("<p>Official Website: <a href='http://example-hotel" + hotelId + ".com'>Hotel Website</a></p>");
        out.println("<br><a href='/DynamicJavaProj_war_exploded/cityinfo/hotels'>Back to Hotel List</a>");
        out.println("</body></html>");
    }
}