import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/overall")
public class OverallInfoServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	
    public OverallInfoServlet()
    {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		
		response.getWriter().append(MrkpSrvc.gnrtMenu());
		
		response.getWriter().append(gnrtInfoMrkp());
	}
	
	private String gnrtInfoMrkp()
	{
		return
			"<p>" + "CityName: " + "FirstCityName" + "</p>" +
			"<p>" + "CountryName: " + "FirstCountryName" + "</p>" +
			"<p>" + "EmblemDescription: " + "FirstEmblemDescription" + "</p>" +
			"<p>" + "Population: " + "FirstPopulation" + "</p>" +
			"<p>" + "CityShortDescription: " + "FirstCityShortDescription" + "</p>";
	}
}
