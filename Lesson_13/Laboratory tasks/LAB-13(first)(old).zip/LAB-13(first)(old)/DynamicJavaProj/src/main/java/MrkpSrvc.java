public final class MrkpSrvc
{
	public static String gnrtMenu()
	{
		StringBuilder currStrBldr = new StringBuilder();
		
		currStrBldr.append("<nav>");
			currStrBldr.append("<ul style=\"list-style-type: none; margin: 0; padding: 0; display: flex; gap: 10px;\">");
				currStrBldr.append(gnrtMenuItem("/DynamicJavaProj/overall", "Overall Info"));
				currStrBldr.append(gnrtMenuItem("/DynamicJavaProj/history", "History"));
				currStrBldr.append(gnrtMenuItem("/DynamicJavaProj/landmarks", "Landmarks"));
				currStrBldr.append(gnrtMenuItem("/DynamicJavaProj/hotels", "Hotels"));
				currStrBldr.append(gnrtMenuItem("/DynamicJavaProj/restaurants", "Restaurants"));
			currStrBldr.append("</ul>");
		currStrBldr.append("</nav>");
		
		return currStrBldr.toString();
	}
	
	private static String gnrtMenuItem(String href, String content)
	{
		StringBuilder currStrBldr = new StringBuilder();
		
		currStrBldr.append("<li style=\"display: inline;\">");
			currStrBldr.append("<a href=\"" + href + "\" style=\"text-decoration: none; padding: 10px 15px; background-color: #007BFF; color: white; border-radius: 5px;\">");
				currStrBldr.append(content);
			currStrBldr.append("</a>");
		currStrBldr.append("</li>");
		
		return currStrBldr.toString();
	}
}
