import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/restaraunt")
public class RestarauntServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    public RestarauntServlet()
    {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter currPrintWrtr = response.getWriter();
		
		response.setContentType("text/html");
		
		currPrintWrtr.append(MrkpSrvc.gnrtMenu());
		
		switch (Integer.parseInt(request.getParameter("id")))
		{
			case 1:
			{
				currPrintWrtr.append(gnrtFirstRestarauntMrkp());
				break;
			}
			default:
			{
				currPrintWrtr.append("<p>Error!</p>");
				break;
			}
		}
	}
	
	private String gnrtFirstRestarauntMrkp()
	{
		StringBuilder currStrBldr = new StringBuilder();
		
		currStrBldr.append("<div>");
			currStrBldr.append("<h3>FirstRestarauntDescription</h3>");
			
			currStrBldr.append("<p>FirstDescriptionParagraph</p>");
			currStrBldr.append("<p>SecondDescriptionParagraph</p>");
			currStrBldr.append("<p>ThirdDescriptionParagraph</p>");
			
			currStrBldr.append("<p>Adress: FirstAddress</p>");
			currStrBldr.append("<p>Tel: FirstTelephone</p>");
			currStrBldr.append("<p>InfoField: FirstInfoFieldData</p>");
			
		currStrBldr.append("</div>");
		
		return currStrBldr.toString();
	}
}
