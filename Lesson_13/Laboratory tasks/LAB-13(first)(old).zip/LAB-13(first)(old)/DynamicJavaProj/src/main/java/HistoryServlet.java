import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/history")
public class HistoryServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    public HistoryServlet()
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		
		response.getWriter().append(MrkpSrvc.gnrtMenu());
		
		response.getWriter().append(gnrtInfoMrkp());
	}

	public String gnrtInfoMrkp()
	{
		StringBuilder currStrBldr = new StringBuilder();
		
		currStrBldr.append("<p>" + "FirstCityParagraph" + "</p>");
		currStrBldr.append("<p>" + "SecondCityParagraph" + "</p>");
		currStrBldr.append("<p>" + "ThirdCityPargraph" + "</p>");
		
		currStrBldr.append("<a href=\"https://www.bing.com/search?pglt=129&q=FirstCityParagraph&cvid=0311c0bbf08a4e51b35cd5bd9eae273f&gs_lcrp=EgRlZGdlKgYIABBFGDkyBggAEEUYOdIBCDcxNDhqMGoxqAIAsAIA&FORM=ANSPA1&PC=U531\">" + "FirstCityParagraph" + "</a>");
		currStrBldr.append("<a href=\"https://www.bing.com/search?q=SecondCityParagraph&qs=n&form=QBRE&sp=-1&ghc=1&lq=0&pq=secondcityparagraph&sc=0-19&sk=&cvid=CED26318374C4C21BAA895AA7662F4FF&ghsh=0&ghacc=0&ghpl=\">" + "SecondCityPargraph" + "</a>");
		currStrBldr.append("<a href=\"https://www.bing.com/search?q=ThirdCityParagraph&cvid=145a41acddec4861b7ba1b39afe4b78f&gs_lcrp=EgRlZGdlKgYIABBFGDkyBggAEEUYOdIBCDc0ODBqMGo5qAIAsAIA&FORM=ANAB01&PC=U531\">" + "ThirdCityParagraph" + "</a>");
		
		return currStrBldr.toString();
	}
}
