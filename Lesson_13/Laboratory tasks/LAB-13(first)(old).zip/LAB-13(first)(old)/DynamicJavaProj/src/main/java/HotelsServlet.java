import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;;

@WebServlet("/hotels")
public class HotelsServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    public HotelsServlet()
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter currPrintWrtr = response.getWriter();
		
		response.setContentType("text/html");
		
		currPrintWrtr.append(MrkpSrvc.gnrtMenu());
		
		currPrintWrtr.append(gnrtFirstHotelMrkp());
	}
	
	private String gnrtFirstHotelMrkp()
	{
		StringBuilder currStrBldr = new StringBuilder();
		
		currStrBldr.append("<div>");
			currStrBldr.append("<h3>FirstHotel</h3>");
			
			currStrBldr.append("<p>FirstParagraph</p>");
			currStrBldr.append("<p>SecondParagraph</p>");
			currStrBldr.append("<p>ThirdParagraph</p>");
			
			currStrBldr.append("<a href=\"https://www.bing.com/search?pglt=129&q=FirstParagraph&cvid=a60496187c8d44a89c5b4f5ef9e659a3&gs_lcrp=EgRlZGdlKgYIABBFGDkyBggAEEUYOTIGCAEQABhAMgYIAhAAGEAyBggDEAAYQDIGCAQQABhAMgYIBRAAGEAyBggGEAAYQDIGCAcQABhAMgYICBAAGEDSAQg0MjMyajBqMagCALACAA&FORM=ANNTA1&PC=U531\">FirstParagraphReference</a>");
			currStrBldr.append("<br>");
			currStrBldr.append("<a href=\"hotel?id=1\">GET</a>");
			
		currStrBldr.append("</div>");
		
		return currStrBldr.toString();
	}
}
