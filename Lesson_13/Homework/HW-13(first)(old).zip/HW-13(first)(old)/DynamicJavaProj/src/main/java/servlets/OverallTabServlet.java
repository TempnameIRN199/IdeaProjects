package servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import services.MrkpSrvc;

@WebServlet("/overall")
public class OverallTabServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    public OverallTabServlet()
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter currPrintWrtr = response.getWriter();
		
		response.setContentType("text/html");
		
		currPrintWrtr.append(MrkpSrvc.gnrtMenuMrkp());
		
		currPrintWrtr.append(gnrtContentMrkp());
	}
	
	private String gnrtContentMrkp()
	{
		StringBuilder currStrBldr = new StringBuilder();
		
		currStrBldr.append("<p>Manufacturer: FirstManufacturerName</p>");
		currStrBldr.append("<p>Country: FirstCountryName</p>");
		currStrBldr.append("<p>Slogan: FirstManufacturerSlogan</p>");
		currStrBldr.append("<p>Number of Employees: FirstNumberOfEmployees</p>");
		currStrBldr.append("<p>Description: FirstDescription</p>");
		
		return currStrBldr.toString();
	}
}
