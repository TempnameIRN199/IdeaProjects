package servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import services.MrkpSrvc;

@WebServlet("/ModelServlet")
public class ModelServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    public ModelServlet()
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter currPrintWrtr = response.getWriter();
		
		response.setContentType("text/html");
		
		currPrintWrtr.append(MrkpSrvc.gnrtMenuMrkp());
		
		switch(Integer.parseInt(request.getParameter("id")))
		{
			case 1:
			{
				currPrintWrtr.append("");
				break;
			}
			default:
			{
				currPrintWrtr.append("<p>Error</p>");
				break;
			}
		}
		
		currPrintWrtr.append("");
	}
	
	private String gnrtFirstModelMrkp()
	{
		StringBuilder currStrBldr = new StringBuilder();
		
		currStrBldr.append("");
		currStrBldr.append("");
		
		return currStrBldr.toString();
	}
}
