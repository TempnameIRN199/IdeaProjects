package servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import services.MrkpSrvc;

@WebServlet("/ModelsTabServlet")
public class ModelsTabServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    public ModelsTabServlet()
    {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter currPrintWrtr = response.getWriter();
		
		response.setContentType("text/html");
		
		currPrintWrtr.append(MrkpSrvc.gnrtMenuMrkp());
		
		currPrintWrtr.append(gnrtContentMrkp());
	}
	
	private String gnrtContentMrkp()
	{
		StringBuilder currStrBldr = new StringBuilder();
		
		currStrBldr.append(gnrtModelMrkp(""));
		
		return currStrBldr.toString();
	}
	
	private String gnrtModelMrkp(String href)
	{
		StringBuilder currStrBldr = new StringBuilder();
		
		currStrBldr.append("<div>");
			currStrBldr.append("<h3>FirstModel</h3>");
			currStrBldr.append("<div>FirstText</div>");
			currStrBldr.append("<a href=\"" + href + "\">READ</a>");
		currStrBldr.append("</div>");
		
		return currStrBldr.toString();
	}
}
