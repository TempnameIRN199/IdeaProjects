package services;

public final class MrkpSrvc
{
	public static String gnrtMenuMrkp()
	{
		StringBuilder currStrBldr = new StringBuilder();
		
		currStrBldr.append("<nav>");
			currStrBldr.append("<ul style=\"list-style-type: none; margin: 0; padding: 0; display: flex; gap: 10px;\">");
				currStrBldr.append(gnrtMenuItemMrkp("/DynamicJavaProj/overall", "Overall Info"));
				currStrBldr.append(gnrtMenuItemMrkp("/DynamicJavaProj/history", "History"));
				currStrBldr.append(gnrtMenuItemMrkp("/DynamicJavaProj/news", "Landmarks"));
				currStrBldr.append(gnrtMenuItemMrkp("/DynamicJavaProj/models", "Hotels"));
			currStrBldr.append("</ul>");
		currStrBldr.append("</nav>");
		
		return currStrBldr.toString();
	}
	
	private static String gnrtMenuItemMrkp(String href, String content)
	{
		StringBuilder currStrBldr = new StringBuilder();
		
		currStrBldr.append("<li style=\"display: inline;\">");
			currStrBldr.append("<a href=\"" + href + "\" style=\"text-decoration: none; padding: 10px 15px; background-color: #007BFF; color: white; border-radius: 5px;\">");
				currStrBldr.append(content);
			currStrBldr.append("</a>");
		currStrBldr.append("</li>");
		
		return currStrBldr.toString();
	}
}
