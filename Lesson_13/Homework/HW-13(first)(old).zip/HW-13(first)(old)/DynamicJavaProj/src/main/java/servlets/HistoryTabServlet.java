package servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import services.MrkpSrvc;

@WebServlet("/HistoryTabServlet")
public class HistoryTabServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;

    public HistoryTabServlet()
    {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter currPrintWrtr = response.getWriter();
		
		response.setContentType("text/html");
		
		currPrintWrtr.append(MrkpSrvc.gnrtMenuMrkp());
		
		currPrintWrtr.append(gnrtContentMrkp());
	}
	
	private String gnrtContentMrkp()
	{
		StringBuilder currStrBldr = new StringBuilder();
		
		currStrBldr.append("<h2>History</h2>");
		currStrBldr.append("<p>FirstHistoryText</p>");)
		
		return currStrBldr.toString();
	}
}
