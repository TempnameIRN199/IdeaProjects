package com.example.dynamicjavaproj;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;

@WebServlet("/manufacturer/history")
public class HistoryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<head><title>History of XYZ Laptop Corp</title></head>");
        out.println("<body>");
        out.println("<h2>History of XYZ Laptop Corp</h2>");
        out.println("<p>XYZ Laptop Corp was founded in 1995. Since then, it has pioneered several advancements in the computing industry.</p>");

        // Navigation menu
        out.println("<nav>");
        out.println("<a href='/DynamicJavaProj_war_exploded/manufacturer'>Home</a> | ");
        out.println("<a href='/DynamicJavaProj_war_exploded/manufacturer/history'>History</a> | ");
        out.println("<a href='/DynamicJavaProj_war_exploded/manufacturer/news'>News</a> | ");
        out.println("<a href='/DynamicJavaProj_war_exploded/manufacturer/laptops'>Laptop Models</a>");
        out.println("</nav>");

        out.println("<h3>Photos:</h3>");
        out.println("<img src='/DynamicJavaProj_war_exploded/images/history_1.jpg' alt='History Photo 1'>");
        out.println("<img src='/DynamicJavaProj_war_exploded/images/history_2.jpg' alt='History Photo 2'>");
        out.println("<h3>External Resources:</h3>");
        out.println("<a href='https://example.com/history'>More about XYZ Laptop Corp's History</a>");
        out.println("<br><a href='/DynamicJavaProj_war_exploded/manufacturer'>Back to Main</a>");
        out.println("</body>");
        out.println("</html>");
    }
}