package com.example.dynamicjavaproj;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;

@WebServlet("/manufacturer/laptops/detail")
public class LaptopDetailServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<head><title>Full Laptop Details - XYZ Laptop Corp</title></head>");
        out.println("<body>");
        out.println("<h2>XYZ Pro 15 Full Details</h2>");
        out.println("<p>Specifications, features, and full information about the XYZ Pro 15 model.</p>");
        out.println("<img src='/DynamicJavaProj_war_exploded/images/full_laptop_1.jpg' alt='Full Laptop Image'>");
        out.println("<br><a href='/DynamicJavaProj_war_exploded/manufacturer/laptops'>Back to Laptops</a>");
        out.println("</body>");
        out.println("</html>");
    }
}