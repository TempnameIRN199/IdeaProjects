package com.example.dynamicjavaproj;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;

@WebServlet("/manufacturer")
public class ManufacturerServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<head><title>Manufacturer Info</title></head>");
        out.println("<body>");
        out.println("<h2>Manufacturer Information</h2>");
        out.println("<p>Name: XYZ Laptop Corp</p>");
        out.println("<p>Country: USA</p>");
        out.println("<p>Employees: 5000</p>");
        out.println("<p>About: XYZ Laptop Corp is a global leader in laptop manufacturing, providing innovative solutions and state-of-the-art technology.</p>");
        out.println("<img src='/DynamicJavaProj_war_exploded/images/logo.jpg' alt='Manufacturer Logo'>");

        // Navigation menu
        out.println("<nav>");
        out.println("<a href='/DynamicJavaProj_war_exploded/manufacturer'>Home</a> | ");
        out.println("<a href='/DynamicJavaProj_war_exploded/manufacturer/history'>History</a> | ");
        out.println("<a href='/DynamicJavaProj_war_exploded/manufacturer/news'>News</a> | ");
        out.println("<a href='/DynamicJavaProj_war_exploded/manufacturer/laptops'>Laptop Models</a>");
        out.println("</nav>");

        out.println("<br><a href='/DynamicJavaProj_war_exploded/manufacturer/history'>History</a> | ");
        out.println("<a href='/DynamicJavaProj_war_exploded/manufacturer/news'>News</a> | ");
        out.println("<a href='/DynamicJavaProj_war_exploded/manufacturer/laptops'>Laptop Models</a>");
        out.println("</body>");
        out.println("</html>");
    }
}