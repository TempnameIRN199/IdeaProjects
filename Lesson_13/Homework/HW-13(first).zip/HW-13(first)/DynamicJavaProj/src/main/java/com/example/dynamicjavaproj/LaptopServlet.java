package com.example.dynamicjavaproj;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;

@WebServlet("/manufacturer/laptops")
public class LaptopServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<head><title>Laptop Models - XYZ Laptop Corp</title></head>");
        out.println("<body>");
        out.println("<h2>Available Laptop Models</h2>");

        // Navigation menu
        out.println("<nav>");
        out.println("<a href='/DynamicJavaProj_war_exploded/manufacturer'>Home</a> | ");
        out.println("<a href='/DynamicJavaProj_war_exploded/manufacturer/history'>History</a> | ");
        out.println("<a href='/DynamicJavaProj_war_exploded/manufacturer/news'>News</a> | ");
        out.println("<a href='/DynamicJavaProj_war_exploded/manufacturer/laptops'>Laptop Models</a>");
        out.println("</nav>");

        out.println("<h3>Model 1: XYZ Pro 15</h3>");
        out.println("<p>A powerful laptop designed for professionals.</p>");
        out.println("<img src='/DynamicJavaProj_war_exploded/images/laptop_1.jpg' alt='Laptop Model 1'>");
        out.println("<h3>Model 2: XYZ Ultra 13</h3>");
        out.println("<p>A compact, lightweight laptop for everyday use.</p>");
        out.println("<img src='/DynamicJavaProj_war_exploded/images/laptop_2.jpg' alt='Laptop Model 2'>");
        out.println("<br><a href='/DynamicJavaProj_war_exploded/manufacturer'>Back to Main</a>");
        out.println("</body>");
        out.println("</html>");
    }
}