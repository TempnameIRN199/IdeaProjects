package com.example.dynamicjavaproj;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;

@WebServlet("/manufacturer/news/detail")
public class NewsDetailServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<head><title>Full News - XYZ Laptop Corp</title></head>");
        out.println("<body>");
        out.println("<h2>Full News</h2>");
        out.println("<h3>XYZ Launches New Laptop</h3>");
        out.println("<p>This new laptop model is designed to provide the best performance for professionals and students alike.</p>");
        out.println("<img src='/DynamicJavaProj_war_exploded/images/full_news_1.jpg' alt='Full News Image'>");
        out.println("<br><a href='/DynamicJavaProj_war_exploded/manufacturer/news'>Back to News</a>");
        out.println("</body>");
        out.println("</html>");
    }
}