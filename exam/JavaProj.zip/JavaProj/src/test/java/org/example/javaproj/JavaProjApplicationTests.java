package org.example.javaproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
