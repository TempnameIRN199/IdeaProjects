package org.example.javaproj;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Journal {
    private Long id;
    private String title;
    private String content;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public boolean isArchived() {
        return isArchived;
    }

    public void setArchived(boolean archived) {
        isArchived = archived;
    }

    public Date getArchiveDate() {
        return archiveDate;
    }

    public void setArchiveDate(Date archiveDate) {
        this.archiveDate = archiveDate;
    }

    public Set<Tag> getTags() {
        return tags;
    }

    public void setTags(Set<Tag> tags) {
        this.tags = tags;
    }

    public Set<User> getCoAuthors() {
        return coAuthors;
    }

    public void setCoAuthors(Set<User> coAuthors) {
        this.coAuthors = coAuthors;
    }

    private boolean isArchived;
    private Date archiveDate;

    private Set<Tag> tags = new HashSet<>();
    private Set<User> coAuthors = new HashSet<>();

    // Constructor, Getters, and Setters
}
