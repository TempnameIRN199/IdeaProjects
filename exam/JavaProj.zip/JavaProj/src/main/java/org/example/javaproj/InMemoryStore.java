package org.example.javaproj;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class InMemoryStore {
    private static Map<Long, User> users = new HashMap<>();
    private static Map<Long, Journal> journals = new HashMap<>();
    private static Map<Long, Tag> tags = new HashMap<>();

    private static long userIdCounter = 1;
    private static long journalIdCounter = 1;
    private static long tagIdCounter = 1;

    public static User createUser(String username, String email, String password) {
        User user = new User();
        user.setId(userIdCounter++);
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);
        users.put(user.getId(), user);
        return user;
    }

    public static Journal createJournal(User user, String title, String content) {
        Journal journal = new Journal();
        journal.setId(journalIdCounter++);
        journal.setTitle(title);
        journal.setContent(content);
        user.getJournals().add(journal);
        journals.put(journal.getId(), journal);
        return journal;
    }

    public static void deleteJournal(Long journalId) {
        journals.remove(journalId);
    }

    public static Journal updateJournal(Long journalId, String title, String content) {
        Journal journal = journals.get(journalId);
        if (journal != null) {
            journal.setTitle(title);
            journal.setContent(content);
        }
        return journal;
    }

    public static void archiveJournal(Long journalId, Date archiveDate) {
        Journal journal = journals.get(journalId);
        if (journal != null) {
            journal.setArchived(true);
            journal.setArchiveDate(archiveDate);
        }
    }

    public static void restoreJournal(Long journalId) {
        Journal journal = journals.get(journalId);
        if (journal != null) {
            journal.setArchived(false);
            journal.setArchiveDate(null);
        }
    }

    public static void addTagToJournal(Long journalId, String tagName) {
        Tag tag = tags.values().stream().filter(t -> t.getName().equals(tagName)).findFirst().orElseGet(() -> {
            Tag newTag = new Tag();
            newTag.setId(tagIdCounter++);
            newTag.setName(tagName);
            tags.put(newTag.getId(), newTag);
            return newTag;
        });

        Journal journal = journals.get(journalId);
        if (journal != null) {
            journal.getTags().add(tag);
        }
    }

    public static User findUserByUsername(String username) {
        return users.values().stream().filter(user -> user.getUsername().equals(username)).findFirst().orElse(null);
    }

    public static Journal findJournalById(Long journalId) {
        return journals.get(journalId);
    }
}
