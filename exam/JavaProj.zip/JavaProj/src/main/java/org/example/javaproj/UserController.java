package org.example.javaproj;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController {

    private User loggedInUser = null; // Store the logged-in user in memory

    @GetMapping("/register")
    public String registerForm() {
        return "register";
    }

    @PostMapping("/register")
    public String register(String username, String email, String password) {
        User user = InMemoryStore.createUser(username, email, password);
        return "redirect:/login";  // After registration, go to login page
    }

    @GetMapping("/login")
    public String loginForm() {
        return "login";  // Render login page
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, Model model) {
        User user = InMemoryStore.findUserByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            loggedInUser = user;  // Store the logged-in user in memory
            return "redirect:/journals?userId=" + loggedInUser.getId(); // Redirect to journals page
        }
        model.addAttribute("error", "Invalid username or password");
        return "login";  // If login fails, stay on login page with error message
    }

    @GetMapping("/userJournals")
    public String showJournals(Model model) {
        if (loggedInUser == null) {
            return "redirect:/login";  // If not logged in, redirect to login page
        }
        model.addAttribute("journals", loggedInUser.getJournals());
        return "journals";  // Render journals page
    }

    @PostMapping("/logout")
    public String logout() {
        loggedInUser = null;  // Clear logged-in user from memory
        return "redirect:/login";  // Redirect to login page
    }
}
