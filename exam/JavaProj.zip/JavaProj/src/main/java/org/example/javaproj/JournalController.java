package org.example.javaproj;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@Controller
public class JournalController {

    @GetMapping("/create-journal")
    public String createJournalForm() {
        return "create-journal";
    }

    @PostMapping("/create-journal")
    public String createJournal(String title, String content, @RequestParam Long userId) {
        User user = InMemoryStore.findUserByUsername("testuser"); // Retrieve user by ID or username
        Journal journal = InMemoryStore.createJournal(user, title, content);
        return "redirect:/journals";
    }

    @GetMapping("/journals/{id}")
    public String showJournals(Model model, @RequestParam Long userId) {
        User user = InMemoryStore.findUserByUsername("testuser"); // Retrieve user by ID or username
        model.addAttribute("journals", user.getJournals());
        return "journals";
    }

    @PostMapping("/archive-journal")
    public String archiveJournal(Long journalId) {
        InMemoryStore.archiveJournal(journalId, new Date());
        return "redirect:/journals";
    }

    @PostMapping("/restore-journal")
    public String restoreJournal(Long journalId) {
        InMemoryStore.restoreJournal(journalId);
        return "redirect:/journals";
    }

    @PostMapping("/delete-journal")
    public String deleteJournal(Long journalId) {
        InMemoryStore.deleteJournal(journalId);
        return "redirect:/journals";
    }
}
