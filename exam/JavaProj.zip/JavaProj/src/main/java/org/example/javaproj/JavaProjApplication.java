package org.example.javaproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaProjApplication.class, args);
	}

}
