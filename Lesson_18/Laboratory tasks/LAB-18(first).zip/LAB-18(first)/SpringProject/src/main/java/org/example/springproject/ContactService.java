package org.example.springproject;

import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ContactService {
    private final Map<Long, Contact> contacts = new HashMap<>();
    private Long nextId = 1L;

    public List<Contact> getAllContacts() {
        return new ArrayList<>(contacts.values());
    }

    public Contact getContactById(Long id) {
        return contacts.get(id);
    }

    public void saveContact(Contact contact) {
        if (contact.getId() == null) {
            contact.setId(nextId++);
        }
        contacts.put(contact.getId(), contact);
    }

    public void deleteContact(Long id) {
        contacts.remove(id);
    }

    public List<Contact> searchContacts(String query) {
        List<Contact> results = new ArrayList<>();
        for (Contact contact : contacts.values()) {
            if (contact.getFullName().toLowerCase().contains(query.toLowerCase())) {
                results.add(contact);
            }
        }
        return results;
    }
}