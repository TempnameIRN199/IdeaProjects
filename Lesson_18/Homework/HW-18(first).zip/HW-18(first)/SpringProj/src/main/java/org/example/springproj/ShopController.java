package org.example.springproj;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/shops")
public class ShopController {
    @Autowired
    private ShopService shopService;

    @GetMapping
    public String listShops(Model model) {
        model.addAttribute("shops", shopService.getAllShops());
        return "index";
    }

    @GetMapping("/new")
    public String showNewShopForm(Model model) {
        model.addAttribute("shop", new Shop());
        return "shop-form";
    }

    @PostMapping("/save")
    public String saveShop(@ModelAttribute Shop shop) {
        shopService.saveShop(shop);
        return "redirect:/shops";
    }

    @GetMapping("/edit/{id}")
    public String editShop(@PathVariable Long id, Model model) {
        Shop shop = shopService.getShopById(id);
        if (shop == null) return "redirect:/shops";
        model.addAttribute("shop", shop);
        return "shop-form";
    }

    @GetMapping("/delete/{id}")
    public String deleteShop(@PathVariable Long id) {
        shopService.deleteShop(id);
        return "redirect:/shops";
    }

    @GetMapping("/{id}")
    public String viewShop(@PathVariable Long id, Model model) {
        Shop shop = shopService.getShopById(id);
        if (shop == null) return "redirect:/shops";
        model.addAttribute("shop", shop);
        return "shop-details";
    }

    @GetMapping("/search")
    public String searchShops(@RequestParam String query, Model model) {
        List<Shop> results = shopService.searchShops(query);
        model.addAttribute("shops", results);
        return "index";
    }
}