package org.example.springproj;

import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ShopService {
    private final Map<Long, Shop> shops = new HashMap<>();
    private Long nextId = 1L;

    public List<Shop> getAllShops() {
        return new ArrayList<>(shops.values());
    }

    public Shop getShopById(Long id) {
        return shops.get(id);
    }

    public void saveShop(Shop shop) {
        if (shop.getId() == null) {
            shop.setId(nextId++);
        }
        shops.put(shop.getId(), shop);
    }

    public void deleteShop(Long id) {
        shops.remove(id);
    }

    public List<Shop> searchShops(String query) {
        List<Shop> results = new ArrayList<>();
        for (Shop shop : shops.values()) {
            if (shop.getName().toLowerCase().contains(query.toLowerCase()) ||
                    shop.getCategory().toLowerCase().contains(query.toLowerCase()) ||
                    shop.getAddress().toLowerCase().contains(query.toLowerCase())) {
                results.add(shop);
            }
        }
        return results;
    }
}