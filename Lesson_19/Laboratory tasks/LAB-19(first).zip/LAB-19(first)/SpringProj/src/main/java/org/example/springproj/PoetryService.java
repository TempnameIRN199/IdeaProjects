package org.example.springproj;

import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class PoetryService {
    private final List<Poet> poets = new ArrayList<>();
    private final List<Category> categories = new ArrayList<>();
    private final List<User> users = new ArrayList<>();

    public PoetryService() {
        // Sample Data
        List<Poem> shakespearePoems = List.of(
                new Poem("Sonnet 18", "Shall I compare thee to a summer’s day?", "Love", 95),
                new Poem("Sonnet 116", "Let me not to the marriage of true minds", "Romance", 80)
        );

        poets.add(new Poet("William Shakespeare", "UK", "Famous English poet and playwright.", shakespearePoems));
        categories.add(new Category("Love", 10));
        categories.add(new Category("Romance", 7));

        users.add(new User("admin", "password", true));
    }

    public String getPoetBio(String poetName) {
        return poets.stream()
                .filter(p -> p.getName().equalsIgnoreCase(poetName))
                .map(Poet::getBio
                )
                .findFirst()
                .orElse("Poet not found");
    }

    public String getPoem(String poetName, String poemTitle) {
        return poets.stream()
                .filter(p -> p.getName().equalsIgnoreCase(poetName))
                .flatMap(p -> p.getPoems().stream())
                .filter(poem -> poem.getTitle().equalsIgnoreCase(poemTitle))
                .map(Poem::getContent)
                .findFirst()
                .orElse("Poem not found");
    }

    public List<String> getPoemsWithWords(String poetName, String words) {
        return poets.stream()
                .filter(p -> p.getName().equalsIgnoreCase(poetName))
                .flatMap(p -> p.getPoems().stream())
                .filter(poem -> poem.getContent().toLowerCase().contains(words.toLowerCase()))
                .map(Poem::getTitle)
                .collect(Collectors.toList());
    }

    public List<String> getFamousPoems(String poetName) {
        return poets.stream()
                .filter(p -> p.getName().equalsIgnoreCase(poetName))
                .flatMap(p -> p.getPoems().stream())
                .sorted(Comparator.comparingInt(Poem::getPopularity).reversed())
                .limit(3)
                .map(Poem::getTitle)
                .collect(Collectors.toList());
    }

    public String getRandomPoem(String poetName) {
        return poets.stream()
                .filter(p -> p.getName().equalsIgnoreCase(poetName))
                .flatMap(p -> p.getPoems().stream())
                .findAny()
                .map(Poem::getTitle)
                .orElse("No poems found");
    }

    public List<String> getCategories() {
        return categories.stream().map(Category::getName).collect(Collectors.toList());
    }

    public List<String> getCategoriesContaining(String words) {
        return categories.stream()
                .filter(cat -> cat.getName().toLowerCase().contains(words.toLowerCase()))
                .map(Category::getName)
                .collect(Collectors.toList());
    }

    public List<String> getTopPoemsInCategory(String category) {
        return poets.stream()
                .flatMap(p -> p.getPoems().stream())
                .filter(poem -> poem.getCategory().equalsIgnoreCase(category))
                .sorted(Comparator.comparingInt(Poem::getPopularity).reversed())
                .limit(3)
                .map(Poem::getTitle)
                .collect(Collectors.toList());
    }

    public List<String> getTopPoetsByCountry(String country) {
        return poets.stream()
                .filter(poet -> poet.getCountry().equalsIgnoreCase(country))
                .map(Poet::getName)
                .limit(3)
                .collect(Collectors.toList());
    }

    public boolean authenticate(String username, String password) {
        return users.stream().anyMatch(u -> u.getUsername().equals(username) && u.getPassword().equals(password));
    }

    public boolean isAdmin(String username) {
        return users.stream().anyMatch(u -> u.getUsername().equals(username) && u.isAdmin());
    }
}