package org.example.springproj;

public class Category
{
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPoemCount() {
        return poemCount;
    }

    public void setPoemCount(int poemCount) {
        this.poemCount = poemCount;
    }

    public Category(String name, int poemCount) {
        this.name = name;
        this.poemCount = poemCount;
    }

    private String name;
    private int poemCount;
}