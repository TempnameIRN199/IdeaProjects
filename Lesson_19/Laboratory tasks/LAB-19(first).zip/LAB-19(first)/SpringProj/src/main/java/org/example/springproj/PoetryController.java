package org.example.springproj;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/poetry")
public class PoetryController {
    private final PoetryService service;

    public PoetryController(PoetryService service) {
        this.service = service;
    }

    @GetMapping("/poet/bio/{name}")
    public String getPoetBio(@PathVariable String name) {
        return service.getPoetBio(name);
    }

    @GetMapping("/poem")
    public String getPoem(@RequestParam String poet, @RequestParam String title) {
        return service.getPoem(poet, title);
    }

    @GetMapping("/poems/search")
    public List<String> getPoemsWithWords(@RequestParam String poet, @RequestParam String words) {
        return service.getPoemsWithWords(poet, words);
    }

    @GetMapping("/poems/famous")
    public List<String> getFamousPoems(@RequestParam String poet) {
        return service.getFamousPoems(poet);
    }

    @GetMapping("/poem/random")
    public String getRandomPoem(@RequestParam String poet) {
        return service.getRandomPoem(poet);
    }

    @GetMapping("/categories")
    public List<String> getCategories() {
        return service.getCategories();
    }

    @PostMapping("/category/add")
    public String addCategory(@RequestParam String username, @RequestParam String password, @RequestParam String category) {
        if (service.authenticate(username, password) && service.isAdmin(username)) {
            return "Category added: " + category;
        }
        return "Unauthorized";
    }
}