package org.example.springproj;

import java.util.List;

public class Poet
{
    public void setName(String name) {
        this.name = name;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public void setPoems(List<Poem> poems) {
        this.poems = poems;
    }

    public String getName() {
        return name;
    }

    public String getCountry() {
        return country;
    }

    public String getBio() {
        return bio;
    }

    public List<Poem> getPoems() {
        return poems;
    }

    public Poet(String name, String country, String bio, List<Poem> poems) {
        this.name = name;
        this.country = country;
        this.bio = bio;
        this.poems = poems;
    }

    private String name;
    private String country;
    private String bio;
    private List<Poem> poems;
}