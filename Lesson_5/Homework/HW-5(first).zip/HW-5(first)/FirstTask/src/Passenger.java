public class Passenger {
    private String name;
    private double arrivalTime;

    public Passenger(String name, double arrivalTime) {
        this.name = name;
        this.arrivalTime = arrivalTime;
    }

    public String getName() {
        return name;
    }

    public double getArrivalTime() {
        return arrivalTime;
    }

    @Override
    public String toString() {
        return "Passenger{name='" + name + "', arrivalTime=" + arrivalTime + '}';
    }
}