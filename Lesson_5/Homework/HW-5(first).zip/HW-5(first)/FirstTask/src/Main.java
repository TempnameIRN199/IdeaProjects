import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the average time between passenger arrivals (in minutes):");
        double meanPassengerArrivalTime = scanner.nextDouble();

        System.out.println("Enter the average time between boat arrivals (in minutes):");
        double meanBoatArrivalTime = scanner.nextDouble();

        System.out.println("Is the dock terminal (true/false)?");
        boolean isTerminal = scanner.nextBoolean();

        System.out.println("Enter the maximum number of passengers allowed on the dock:");
        int maxPassengersAtDock = scanner.nextInt();

        Dock dock = new Dock(meanPassengerArrivalTime, meanBoatArrivalTime, isTerminal, maxPassengersAtDock);

        System.out.println("Enter the total time to simulate (in minutes):");
        double totalTime = scanner.nextDouble();

        // Simulate the dock activity
        dock.simulate(totalTime);
        dock.processDocking();
        dock.displayStatistics();

        scanner.close();
    }
}