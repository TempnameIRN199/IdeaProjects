import java.util.Random;

public class Boat {
    private String name;
    private boolean isTerminal;  // true if the boat is stopping at the final dock
    private int capacity;

    public Boat(String name, boolean isTerminal, int capacity) {
        this.name = name;
        this.isTerminal = isTerminal;
        this.capacity = capacity;
    }

    public String getName() {
        return name;
    }

    public boolean isTerminal() {
        return isTerminal;
    }

    public int getCapacity() {
        return capacity;
    }

    public double generateArrivalTime(double meanTimeBetweenBoats) {
        Random rand = new Random();
        // Exponential distribution to simulate time between boats
        return -meanTimeBetweenBoats * Math.log(rand.nextDouble());
    }

    @Override
    public String toString() {
        return "Boat{name='" + name + "', isTerminal=" + isTerminal + ", capacity=" + capacity + '}';
    }
}