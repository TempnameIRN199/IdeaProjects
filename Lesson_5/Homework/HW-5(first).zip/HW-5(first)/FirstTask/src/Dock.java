import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class Dock {
    private Queue<Passenger> passengersQueue;
    private Queue<Boat> boatsQueue;
    private double meanPassengerArrivalTime;  // Mean time between passenger arrivals
    private double meanBoatArrivalTime;       // Mean time between boat arrivals
    private boolean isTerminal;
    private int maxPassengersAtDock;  // Maximum number of passengers allowed on the dock

    public Dock(double meanPassengerArrivalTime, double meanBoatArrivalTime, boolean isTerminal, int maxPassengersAtDock) {
        this.passengersQueue = new LinkedList<>();
        this.boatsQueue = new LinkedList<>();
        this.meanPassengerArrivalTime = meanPassengerArrivalTime;
        this.meanBoatArrivalTime = meanBoatArrivalTime;
        this.isTerminal = isTerminal;
        this.maxPassengersAtDock = maxPassengersAtDock;
    }

    public void simulate(double totalTime) {
        Random rand = new Random();
        double currentTime = 0;

        while (currentTime < totalTime) {
            // Add new passengers based on the average passenger arrival time
            double passengerArrivalTime = -meanPassengerArrivalTime * Math.log(rand.nextDouble());
            currentTime += passengerArrivalTime;
            passengersQueue.add(new Passenger("Passenger" + (passengersQueue.size() + 1), currentTime));

            // Add new boats based on the average boat arrival time
            double boatArrivalTime = -meanBoatArrivalTime * Math.log(rand.nextDouble());
            currentTime += boatArrivalTime;
            int capacity = rand.nextInt(50) + 10;  // Random capacity between 10 and 50
            boatsQueue.add(new Boat("Boat" + (boatsQueue.size() + 1), isTerminal, capacity));
        }
    }

    public void processDocking() {
        while (!passengersQueue.isEmpty() && !boatsQueue.isEmpty()) {
            Passenger passenger = passengersQueue.poll();
            Boat boat = boatsQueue.poll();

            System.out.println(passenger + " is boarding the " + boat);

            // Assign passengers to the boat based on the boat's capacity
            int passengersOnBoat = Math.min(boat.getCapacity(), passengersQueue.size());
            System.out.println("Boat " + boat.getName() + " is departing with " + passengersOnBoat + " passengers.");
        }
    }

    public double calculateAverageTimeOnDock() {
        // Calculate average time a passenger spends on the dock
        double totalTime = 0;
        for (Passenger passenger : passengersQueue) {
            totalTime += passenger.getArrivalTime();
        }
        return totalTime / passengersQueue.size();
    }

    public double calculateMinTimeBetweenBoats() {
        // Calculate the minimum interval between boat arrivals to avoid overcrowding
        return meanBoatArrivalTime * (maxPassengersAtDock / (double) boatsQueue.size());
    }

    public void displayStatistics() {
        System.out.println("\nDock Statistics:");
        System.out.println("Remaining passengers: " + passengersQueue.size());
        System.out.println("Remaining boats: " + boatsQueue.size());
        System.out.println("Average time a passenger spends on dock: " + calculateAverageTimeOnDock());
        System.out.println("Minimum time between boats to avoid overcrowding: " + calculateMinTimeBetweenBoats());
    }
}