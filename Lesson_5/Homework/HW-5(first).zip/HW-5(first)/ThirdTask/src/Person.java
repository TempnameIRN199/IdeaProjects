import java.util.ArrayList;
import java.util.List;

public class Person {
    private String idCode;
    private String name;
    private String city;
    private List<Fine> fines;

    public Person(String idCode, String name, String city) {
        this.idCode = idCode;
        this.name = name;
        this.city = city;
        this.fines = new ArrayList<>();
    }

    public String getIdCode() {
        return idCode;
    }

    public void setIdCode(String idCode) {
        this.idCode = idCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public List<Fine> getFines() {
        return fines;
    }

    public void addFine(Fine fine) {
        this.fines.add(fine);
    }

    public void removeFine(Fine fine) {
        this.fines.remove(fine);
    }

    @Override
    public String toString() {
        StringBuilder finesList = new StringBuilder();
        for (Fine fine : fines) {
            finesList.append(fine.toString()).append("\n");
        }
        return "ID: " + idCode + ", Name: " + name + ", City: " + city + "\nFines:\n" + finesList;
    }
}