public class Fine {
    private String fineType;
    private double fineAmount;
    private String city;

    public Fine(String fineType, double fineAmount, String city) {
        this.fineType = fineType;
        this.fineAmount = fineAmount;
        this.city = city;
    }

    public String getFineType() {
        return fineType;
    }

    public void setFineType(String fineType) {
        this.fineType = fineType;
    }

    public double getFineAmount() {
        return fineAmount;
    }

    public void setFineAmount(double fineAmount) {
        this.fineAmount = fineAmount;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public String toString() {
        return "FineType: " + fineType + ", Amount: " + fineAmount + ", City: " + city;
    }
}