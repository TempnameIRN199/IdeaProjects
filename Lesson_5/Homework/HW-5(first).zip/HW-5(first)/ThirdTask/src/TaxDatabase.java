import java.util.*;

public class TaxDatabase {
    private Map<String, Person> database;

    public TaxDatabase() {
        database = new HashMap<>();
    }

    // Повний друк бази даних
    public void printDatabase() {
        for (Person person : database.values()) {
            System.out.println(person);
        }
    }

    // Роздрукування даних по конкретному коду
    public void printPersonById(String idCode) {
        Person person = database.get(idCode);
        if (person != null) {
            System.out.println(person);
        } else {
            System.out.println("Person with ID " + idCode + " not found.");
        }
    }

    // Роздрукування даних по конкретному типу штрафу
    public void printFinesByType(String fineType) {
        for (Person person : database.values()) {
            for (Fine fine : person.getFines()) {
                if (fine.getFineType().equals(fineType)) {
                    System.out.println(person.getName() + ": " + fine);
                }
            }
        }
    }

    // Роздрукування даних по конкретному місту
    public void printFinesByCity(String city) {
        for (Person person : database.values()) {
            if (person.getCity().equals(city)) {
                System.out.println(person);
            }
        }
    }

    // Додавання нової людини
    public void addPerson(String idCode, String name, String city) {
        if (!database.containsKey(idCode)) {
            Person person = new Person(idCode, name, city);
            database.put(idCode, person);
        } else {
            System.out.println("Person with ID " + idCode + " already exists.");
        }
    }

    // Додавання нових штрафів для існуючого запису
    public void addFineToPerson(String idCode, String fineType, double fineAmount, String city) {
        Person person = database.get(idCode);
        if (person != null) {
            Fine fine = new Fine(fineType, fineAmount, city);
            person.addFine(fine);
        } else {
            System.out.println("Person with ID " + idCode + " not found.");
        }
    }

    // Видалення штрафу
    public void removeFineFromPerson(String idCode, Fine fine) {
        Person person = database.get(idCode);
        if (person != null) {
            person.removeFine(fine);
        } else {
            System.out.println("Person with ID " + idCode + " not found.");
        }
    }

    // Заміна інформації про людину і її штрафи
    public void updatePersonInfo(String idCode, String newName, String newCity) {
        Person person = database.get(idCode);
        if (person != null) {
            person.setName(newName);
            person.setCity(newCity);
        } else {
            System.out.println("Person with ID " + idCode + " not found.");
        }
    }
}