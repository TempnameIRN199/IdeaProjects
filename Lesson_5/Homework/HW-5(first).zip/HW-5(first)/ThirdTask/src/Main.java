import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TaxDatabase taxDatabase = new TaxDatabase();

        while (true) {
            System.out.println("\nTax Database Menu:");
            System.out.println("1. Print full database");
            System.out.println("2. Print person by ID");
            System.out.println("3. Print fines by type");
            System.out.println("4. Print fines by city");
            System.out.println("5. Add new person");
            System.out.println("6. Add fine for person");
            System.out.println("7. Remove fine from person");
            System.out.println("8. Update person information");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // consume the newline character

            switch (choice) {
                case 1:
                    taxDatabase.printDatabase();
                    break;

                case 2:
                    System.out.print("Enter person ID: ");
                    String idCode = scanner.nextLine();
                    taxDatabase.printPersonById(idCode);
                    break;

                case 3:
                    System.out.print("Enter fine type: ");
                    String fineType = scanner.nextLine();
                    taxDatabase.printFinesByType(fineType);
                    break;

                case 4:
                    System.out.print("Enter city: ");
                    String city = scanner.nextLine();
                    taxDatabase.printFinesByCity(city);
                    break;

                case 5:
                    System.out.print("Enter ID: ");
                    String newId = scanner.nextLine();
                    System.out.print("Enter name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter city: ");
                    String newCity = scanner.nextLine();
                    taxDatabase.addPerson(newId, newName, newCity);
                    break;

                case 6:
                    System.out.print("Enter person ID: ");
                    String personIdForFine = scanner.nextLine();
                    System.out.print("Enter fine type: ");
                    String fineTypeForPerson = scanner.nextLine();
                    System.out.print("Enter fine amount: ");
                    double fineAmount = scanner.nextDouble();
                    scanner.nextLine();  // consume the newline character
                    System.out.print("Enter city: ");
                    String fineCity = scanner.nextLine();
                    taxDatabase.addFineToPerson(personIdForFine, fineTypeForPerson, fineAmount, fineCity);
                    break;

                case 7:
                    System.out.print("Enter person ID: ");
                    String personIdForRemove = scanner.nextLine();
                    System.out.print("Enter fine type: ");
                    String fineTypeForRemove = scanner.nextLine();
                    System.out.print("Enter fine amount: ");
                    double fineAmountForRemove = scanner.nextDouble();
                    scanner.nextLine();  // consume the newline character
                    System.out.print("Enter city: ");
                    String fineCityForRemove = scanner.nextLine();
                    Fine fineToRemove = new Fine(fineTypeForRemove, fineAmountForRemove, fineCityForRemove);
                    taxDatabase.removeFineFromPerson(personIdForRemove, fineToRemove);
                    break;

                case 8:
                    System.out.print("Enter person ID to update: ");
                    String personIdToUpdate = scanner.nextLine();
                    System.out.print("Enter new name: ");
                    String updatedName = scanner.nextLine();
                    System.out.print("Enter new city: ");
                    String updatedCity = scanner.nextLine();
                    taxDatabase.updatePersonInfo(personIdToUpdate, updatedName, updatedCity);
                    break;

                case 9:
                    System.out.println("Exiting program.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }
}