import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Dictionary dictionary = new Dictionary();

        while (true) {
            System.out.println("\nDictionary Menu:");
            System.out.println("1. Add word");
            System.out.println("2. Remove word");
            System.out.println("3. Add/Update translation");
            System.out.println("4. Remove translation");
            System.out.println("5. Show word and its translations");
            System.out.println("6. Show top 10 popular words");
            System.out.println("7. Show top 10 least popular words");
            System.out.println("8. Show all words");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // consume the newline character

            switch (choice) {
                case 1:
                    // Add a new word
                    System.out.print("Enter the word: ");
                    String wordToAdd = scanner.nextLine();
                    dictionary.addWord(wordToAdd);
                    break;

                case 2:
                    // Remove a word
                    System.out.print("Enter the word to remove: ");
                    String wordToRemove = scanner.nextLine();
                    dictionary.removeWord(wordToRemove);
                    break;

                case 3:
                    // Add or update a translation
                    System.out.print("Enter the word: ");
                    String wordForTranslation = scanner.nextLine();
                    System.out.print("Enter the language: ");
                    String language = scanner.nextLine();
                    System.out.print("Enter the translation: ");
                    String translation = scanner.nextLine();
                    dictionary.addTranslation(wordForTranslation, language, translation);
                    break;

                case 4:
                    // Remove a translation
                    System.out.print("Enter the word: ");
                    String wordToRemoveTranslation = scanner.nextLine();
                    System.out.print("Enter the language to remove: ");
                    String languageToRemove = scanner.nextLine();
                    dictionary.removeTranslation(wordToRemoveTranslation, languageToRemove);
                    break;

                case 5:
                    // Show a word and its translations
                    System.out.print("Enter the word to show: ");
                    String wordToShow = scanner.nextLine();
                    dictionary.showWord(wordToShow);
                    break;

                case 6:
                    // Show top 10 popular words
                    dictionary.showTop10PopularWords();
                    break;

                case 7:
                    // Show top 10 least popular words
                    dictionary.showTop10LeastPopularWords();
                    break;

                case 8:
                    // Show all words
                    dictionary.showAllWords();
                    break;

                case 9:
                    // Exit the program
                    System.out.println("Exiting program.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }
}