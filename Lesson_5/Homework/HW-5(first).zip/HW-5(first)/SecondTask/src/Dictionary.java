import java.util.*;

public class Dictionary {
    private Map<String, Word> words;

    public Dictionary() {
        words = new HashMap<>();
    }

    public void addWord(String word) {
        if (!words.containsKey(word)) {
            words.put(word, new Word(word));
        } else {
            System.out.println("Word already exists.");
        }
    }

    public void removeWord(String word) {
        words.remove(word);
    }

    public void updateWord(String oldWord, String newWord) {
        Word word = words.remove(oldWord);
        if (word != null) {
            word = new Word(newWord);
            words.put(newWord, word);
        }
    }

    public void addTranslation(String word, String language, String translation) {
        Word w = words.get(word);
        if (w != null) {
            w.addTranslation(language, translation);
        }
    }

    public void removeTranslation(String word, String language) {
        Word w = words.get(word);
        if (w != null) {
            w.removeTranslation(language);
        }
    }

    public void updateTranslation(String word, String language, String newTranslation) {
        Word w = words.get(word);
        if (w != null) {
            w.updateTranslation(language, newTranslation);
        }
    }

    public void showWord(String word) {
        Word w = words.get(word);
        if (w != null) {
            w.incrementVisitCount();
            System.out.println(w);
        } else {
            System.out.println("Word not found.");
        }
    }

    public void showTop10PopularWords() {
        words.values().stream()
                .sorted((w1, w2) -> Integer.compare(w2.getVisitCount(), w1.getVisitCount()))
                .limit(10)
                .forEach(w -> System.out.println(w));
    }

    public void showTop10LeastPopularWords() {
        words.values().stream()
                .sorted(Comparator.comparingInt(Word::getVisitCount))
                .limit(10)
                .forEach(w -> System.out.println(w));
    }

    public void showAllWords() {
        words.values().forEach(System.out::println);
    }
}