import java.util.HashMap;
import java.util.Map;

public class Word {
    private String word;
    private Map<String, String> translations; // Зберігаємо переклади у вигляді "мова:переклад"
    private int visitCount;

    public Word(String word) {
        this.word = word;
        this.translations = new HashMap<>();
        this.visitCount = 0;
    }

    public String getWord() {
        return word;
    }

    public Map<String, String> getTranslations() {
        return translations;
    }

    public int getVisitCount() {
        return visitCount;
    }

    public void incrementVisitCount() {
        this.visitCount++;
    }

    public void addTranslation(String language, String translation) {
        translations.put(language, translation);
    }

    public void removeTranslation(String language) {
        translations.remove(language);
    }

    public void updateTranslation(String language, String newTranslation) {
        translations.put(language, newTranslation);
    }

    @Override
    public String toString() {
        return word + " " + translations.toString() + " (visited " + visitCount + " times)";
    }
}