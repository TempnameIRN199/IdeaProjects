import java.util.Scanner;

import java.util.Map;
import java.util.HashMap;

import services.MapSrvc;

public final class Main
{
	public static void main(String[] args)
	{
		MapSrvc currMapSrvc = new MapSrvc(new HashMap<Integer, Integer>());
		Scanner currScanner = new Scanner(System.in);
		
		while(true)
		{
			System.out.print(getMenuInterface());
			
			switch (currScanner.next())
			{
				// It will change the "password". If key changing is required, remove entry and add a new one.
				case "AddEntry":
					System.out.println("Key & Value: ");
					currMapSrvc.addEntry(currScanner.nextInt(), currScanner.nextInt());
					break;

				case "RemoveEntry":
					System.out.print("Key: ");
					currMapSrvc.removeEntry(currScanner.nextInt());
					break;

				case "ContainsEntry":
					System.out.print("Key: ");
					System.out.println(currMapSrvc.containsEntry(currScanner.nextInt()));
					break;

				case "ToString":
					System.out.println(currMapSrvc.toString());
					break;

				default:
					System.out.println("Error!");
			}
		}
	}
	
	private static String getMenuInterface()
	{
		StringBuilder tmpStringBuilder = new StringBuilder();
		
		tmpStringBuilder.append("\t- AddEntry");
		tmpStringBuilder.append('\n');
		tmpStringBuilder.append("\t- RemoveEntry");
		tmpStringBuilder.append('\n');
		tmpStringBuilder.append("\t- ContainsEntry");
		tmpStringBuilder.append('\n');
		tmpStringBuilder.append("\t- ToString");
		tmpStringBuilder.append('\n');
		tmpStringBuilder.append("> ");
		
		return tmpStringBuilder.toString();
	}
}