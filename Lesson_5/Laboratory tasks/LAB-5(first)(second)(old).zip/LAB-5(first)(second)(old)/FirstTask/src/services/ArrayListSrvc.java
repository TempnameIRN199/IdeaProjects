package services;

import java.util.ArrayList;

public final class ArrayListSrvc
{
	private ArrayList<Integer> arrayList;

	public ArrayList<Integer> getArrayList()
	{ return arrayList; }

	public void setArrayList(ArrayList<Integer> arrayList)
	{ this.arrayList = arrayList; }

	public ArrayListSrvc()
	{ this(new ArrayList<Integer>()); }

	public ArrayListSrvc(ArrayList<Integer> arrayList)
	{
		this.arrayList = arrayList;
	}
	
	public void addItem(Integer item)
	{ arrayList.add(item); }
	
	public void removeItem(Integer item)
	{ arrayList.remove(item); }
	
	public void removeItem(int index)
	{ arrayList.remove(index); }
	
	public void setItem(int index, Integer item)
	{ arrayList.set(index, item); }
	
	public boolean containsItem(Integer item)
	{ return arrayList.contains(item); }

	@Override
	public String toString()
	{
		return "ArrayListSrvc [arrayList=" + arrayList + "]";
	}
}
