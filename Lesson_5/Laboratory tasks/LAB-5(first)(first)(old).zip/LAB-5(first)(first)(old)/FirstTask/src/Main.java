import services.ArrayListSrvc;

import java.util.Scanner;

public final class Main
{
	public static void main(String[] args)
	{
		ArrayListSrvc currArrayListSrvc = new ArrayListSrvc();
		Scanner currScanner = new Scanner(System.in);
		
		while(true)
		{
			System.out.print(getMenuInterface());
			
			switch (currScanner.next())
			{
				case "AddItem":
					System.out.print("Item: ");
					currArrayListSrvc.addItem(currScanner.nextInt());
					break;
				case "RemoveItem":
					System.out.print("Item: ");
					currArrayListSrvc.removeItem(currScanner.nextInt());
					break;
				case "ContainsItem":
					System.out.print("Item: ");
					System.out.print(currArrayListSrvc.containsItem(currScanner.nextInt()));
					break;
				case "SetItem":
					System.out.println("Index & Item:");
					currArrayListSrvc.setItem(currScanner.nextInt(), currScanner.nextInt());
					break;
				case "ToString":
					System.out.print(currArrayListSrvc.toString());
					break;
				default:
					System.out.println("Error!");
			}
		}
	}
	
	private static String getMenuInterface()
	{
		StringBuilder tmpStringBuilder = new StringBuilder();
		
		tmpStringBuilder.append("\t- AddItem");
		tmpStringBuilder.append('\n');
		tmpStringBuilder.append("\t- RemoveItem");
		tmpStringBuilder.append('\n');
		tmpStringBuilder.append("\t- ContainsItem");
		tmpStringBuilder.append('\n');
		tmpStringBuilder.append("\t- SetItem");
		tmpStringBuilder.append('\n');
		tmpStringBuilder.append("\t- ToString");
		tmpStringBuilder.append('\n');
		tmpStringBuilder.append("> ");
		
		return tmpStringBuilder.toString();
	}
}
