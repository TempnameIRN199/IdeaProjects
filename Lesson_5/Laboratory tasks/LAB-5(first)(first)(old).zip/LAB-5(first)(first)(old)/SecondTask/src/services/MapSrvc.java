package services;

import java.util.Map;

public final class MapSrvc
{
	private Map<Integer, Integer> map;

	public Map<Integer, Integer> getMap()
	{ return map; }

	public void setMap(Map<Integer, Integer> map)
	{ this.map = map; }

	public MapSrvc()
	{ }

	public MapSrvc(Map<Integer, Integer> map)
	{ this.map = map; }
	
	public void addEntry(Integer key, Integer value)
	{ map.put(key, value); }
	
	public void removeEntry(Integer key)
	{ map.remove(key); }
	
	public boolean containsEntry(Integer key)
	{ return map.containsKey(key); }

	@Override
	public String toString()
	{ return "MapSrvc [map=" + map + "]"; }
}
