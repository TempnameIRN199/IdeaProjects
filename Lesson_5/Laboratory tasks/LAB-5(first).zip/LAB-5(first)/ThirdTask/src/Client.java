public class Client implements Comparable<Client> {
    private String name;
    private int priority;

    public Client(String name, int priority) {
        this.name = name;
        this.priority = priority;
    }

    public String getName() {
        return name;
    }

    public int getPriority() {
        return priority;
    }

    @Override
    public int compareTo(Client other) {
        return Integer.compare(this.priority, other.priority);  // Lower number means higher priority
    }

    @Override
    public String toString() {
        return "Client{name='" + name + "', priority=" + priority + '}';
    }
}