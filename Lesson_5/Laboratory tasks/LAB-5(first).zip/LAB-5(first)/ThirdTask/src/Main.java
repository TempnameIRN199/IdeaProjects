import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Server server = new Server();

        boolean exit = false;

        while (!exit) {
            // Display the menu
            System.out.println("\nMenu:");
            System.out.println("1. Add new client to the queue");
            System.out.println("2. Process a request");
            System.out.println("3. Show request statistics");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline

            switch (choice) {
                case 1:
                    // Add a new client
                    System.out.print("Enter client name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter client priority: ");
                    int priority = scanner.nextInt();
                    scanner.nextLine();  // Consume the newline
                    Client client = new Client(name, priority);
                    server.addClient(client);
                    break;
                case 2:
                    // Process a request
                    server.processRequest();
                    break;
                case 3:
                    // Show request statistics
                    server.showRequestStatistics();
                    break;
                case 4:
                    // Exit the program
                    exit = true;
                    System.out.println("Exiting program.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();  // Close the scanner
    }
}