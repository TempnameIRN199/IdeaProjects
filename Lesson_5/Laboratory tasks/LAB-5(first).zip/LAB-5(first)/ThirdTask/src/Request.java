import java.time.LocalDateTime;

public class Request {
    private String clientName;
    private LocalDateTime requestTime;

    public Request(String clientName) {
        this.clientName = clientName;
        this.requestTime = LocalDateTime.now();
    }

    public String getClientName() {
        return clientName;
    }

    public LocalDateTime getRequestTime() {
        return requestTime;
    }

    @Override
    public String toString() {
        return "Request{clientName='" + clientName + "', requestTime=" + requestTime + '}';
    }
}