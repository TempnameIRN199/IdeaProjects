import java.util.PriorityQueue;
import java.util.Queue;

public class Server {
    private PriorityQueue<Client> clientQueue;  // Queue to hold clients based on priority
    private Queue<Request> requestQueue;        // Queue to hold request statistics

    public Server() {
        clientQueue = new PriorityQueue<>();
        requestQueue = new PriorityQueue<>((r1, r2) -> r1.getRequestTime().compareTo(r2.getRequestTime())); // Queue to keep track of requests by time
    }

    // Method to add a client to the queue
    public void addClient(Client client) {
        clientQueue.add(client);
        System.out.println(client.getName() + " added to the queue with priority " + client.getPriority());
    }

    // Method to process a client's request
    public void processRequest() {
        if (!clientQueue.isEmpty()) {
            Client client = clientQueue.poll(); // Get and remove the client with the highest priority (lowest number)
            Request request = new Request(client.getName());
            requestQueue.add(request);
            System.out.println("Processing request from: " + client.getName() + " at " + request.getRequestTime());
        } else {
            System.out.println("No clients in the queue to process.");
        }
    }

    // Method to show the request statistics
    public void showRequestStatistics() {
        System.out.println("\nRequest Statistics:");
        for (Request request : requestQueue) {
            System.out.println(request);
        }
    }
}