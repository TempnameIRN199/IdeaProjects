import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ListManager listManager = new ListManager();

        // Prompt the user to enter a set of numbers, separated by space.
        System.out.println("Enter a set of numbers (separated by space):");
        String input = scanner.nextLine();
        String[] tokens = input.split("\\s+");

        // Convert and add the input numbers to the list
        for (String token : tokens) {
            try {
                int number = Integer.parseInt(token);  // Convert the input string to an integer
                listManager.addNumber(number);  // Add the number to the list
            } catch (NumberFormatException e) {
                System.out.println("Invalid number: " + token);  // Handle invalid input
            }
        }

        boolean exit = false;
        // Display the menu and handle user input in a loop
        while (!exit) {
            System.out.println("\nMenu:");
            System.out.println("1. Add element to the list");
            System.out.println("2. Remove element from the list");
            System.out.println("3. Show list content");
            System.out.println("4. Check if value exists in the list");
            System.out.println("5. Replace value in the list");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            // Using nextInt() inside try-catch to handle invalid menu choices
            int choice = -1;
            try {
                choice = scanner.nextInt();
            } catch (Exception e) {
                System.out.println("Invalid input! Please enter a valid menu option.");
                scanner.nextLine();  // Clear the buffer
                continue;
            }

            switch (choice) {
                case 1:
                    // Add a new number to the list
                    System.out.print("Enter the number to add: ");
                    int numToAdd = scanner.nextInt();
                    listManager.addNumber(numToAdd);
                    System.out.println(numToAdd + " added.");
                    break;
                case 2:
                    // Remove a number from the list
                    System.out.print("Enter the number to remove: ");
                    int numToRemove = scanner.nextInt();
                    if (listManager.removeNumber(numToRemove)) {
                        System.out.println(numToRemove + " removed.");
                    } else {
                        System.out.println(numToRemove + " not found in the list.");
                    }
                    break;
                case 3:
                    // Show the current list
                    listManager.showList();
                    break;
                case 4:
                    // Check if a number exists in the list
                    System.out.print("Enter the number to check: ");
                    int numToCheck = scanner.nextInt();
                    if (listManager.containsNumber(numToCheck)) {
                        System.out.println(numToCheck + " exists in the list.");
                    } else {
                        System.out.println(numToCheck + " does not exist in the list.");
                    }
                    break;
                case 5:
                    // Replace a number in the list
                    System.out.print("Enter the number to be replaced: ");
                    int oldNumber = scanner.nextInt();
                    System.out.print("Enter the new number: ");
                    int newNumber = scanner.nextInt();
                    if (listManager.replaceNumber(oldNumber, newNumber)) {
                        System.out.println(oldNumber + " replaced with " + newNumber + ".");
                    } else {
                        System.out.println(oldNumber + " not found in the list.");
                    }
                    break;
                case 6:
                    // Exit the program
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
                    break;
            }
        }

        // Exit message
        System.out.println("Exiting program.");
        scanner.close();  // Close the scanner to avoid memory leaks
    }
}