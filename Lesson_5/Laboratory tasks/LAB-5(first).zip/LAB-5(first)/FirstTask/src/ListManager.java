import java.util.ArrayList;
import java.util.List;

public class ListManager {
    private List<Integer> numbers;

    public ListManager() {
        numbers = new ArrayList<>();
    }

    // Add number to the list
    public void addNumber(int number) {
        numbers.add(number);
    }

    // Remove number from the list
    public boolean removeNumber(int number) {
        return numbers.remove(Integer.valueOf(number)); // Use Integer.valueOf to remove by value
    }

    // Show the list content
    public void showList() {
        System.out.println("List content: " + numbers);
    }

    // Check if number exists in the list
    public boolean containsNumber(int number) {
        return numbers.contains(number);
    }

    // Replace old number with new one
    public boolean replaceNumber(int oldNumber, int newNumber) {
        int index = numbers.indexOf(oldNumber);
        if (index != -1) {
            numbers.set(index, newNumber); // Replace the value at the given index
            return true;
        }
        return false;
    }
}