import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserManager userManager = new UserManager();
        boolean exit = false;

        while (!exit) {
            // Display the menu to the user
            System.out.println("\nMenu:");
            System.out.println("1. Add new user");
            System.out.println("2. Remove existing user");
            System.out.println("3. Check if user exists");
            System.out.println("4. Change user login");
            System.out.println("5. Change user password");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume the leftover newline character

            switch (choice) {
                case 1:
                    // Add a new user
                    System.out.print("Enter the login: ");
                    String login = scanner.nextLine();
                    System.out.print("Enter the password: ");
                    String password = scanner.nextLine();
                    userManager.addUser(login, password);
                    break;
                case 2:
                    // Remove an existing user
                    System.out.print("Enter the login of the user to remove: ");
                    login = scanner.nextLine();
                    userManager.removeUser(login);
                    break;
                case 3:
                    // Check if a user exists
                    System.out.print("Enter the login to check: ");
                    login = scanner.nextLine();
                    if (userManager.userExists(login)) {
                        System.out.println("User " + login + " exists.");
                    } else {
                        System.out.println("User " + login + " does not exist.");
                    }
                    break;
                case 4:
                    // Change the login of an existing user
                    System.out.print("Enter the current login: ");
                    String oldLogin = scanner.nextLine();
                    System.out.print("Enter the new login: ");
                    String newLogin = scanner.nextLine();
                    userManager.changeLogin(oldLogin, newLogin);
                    break;
                case 5:
                    // Change the password of an existing user
                    System.out.print("Enter the login: ");
                    login = scanner.nextLine();
                    System.out.print("Enter the new password: ");
                    password = scanner.nextLine();
                    userManager.changePassword(login, password);
                    break;
                case 6:
                    // Exit the program
                    exit = true;
                    System.out.println("Exiting program.");
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }

        scanner.close();  // Close the scanner to avoid memory leaks
    }
}