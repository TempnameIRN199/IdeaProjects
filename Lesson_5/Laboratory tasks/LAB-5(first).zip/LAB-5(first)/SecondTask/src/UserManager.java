import java.util.HashMap;
import java.util.Map;

public class UserManager {
    private Map<String, String> users;  // Map to store user login and password

    public UserManager() {
        users = new HashMap<>();
    }

    // Add a new user to the system
    public void addUser(String login, String password) {
        if (users.containsKey(login)) {
            System.out.println("User with this login already exists.");
        } else {
            users.put(login, password);
            System.out.println("User " + login + " added successfully.");
        }
    }

    // Remove an existing user
    public boolean removeUser(String login) {
        if (users.containsKey(login)) {
            users.remove(login);
            System.out.println("User " + login + " removed successfully.");
            return true;
        } else {
            System.out.println("User " + login + " not found.");
            return false;
        }
    }

    // Check if a user exists
    public boolean userExists(String login) {
        return users.containsKey(login);
    }

    // Change the login of an existing user
    public boolean changeLogin(String oldLogin, String newLogin) {
        if (users.containsKey(oldLogin)) {
            String password = users.remove(oldLogin);
            users.put(newLogin, password);
            System.out.println("Login changed from " + oldLogin + " to " + newLogin + ".");
            return true;
        } else {
            System.out.println("User " + oldLogin + " not found.");
            return false;
        }
    }

    // Change the password of an existing user
    public boolean changePassword(String login, String newPassword) {
        if (users.containsKey(login)) {
            users.put(login, newPassword);
            System.out.println("Password for user " + login + " changed successfully.");
            return true;
        } else {
            System.out.println("User " + login + " not found.");
            return false;
        }
    }
}