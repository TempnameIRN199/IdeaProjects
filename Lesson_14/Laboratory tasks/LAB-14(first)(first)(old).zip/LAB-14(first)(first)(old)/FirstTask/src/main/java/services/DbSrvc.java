package services;

public final class DbSrvc
{
	private final String tgtUrl = "jdbc:mysql://localhost:3306/NotebooksDB";
	private final String tgtUser = "root";
	private final String tgtPwd = "root";
	
	public void createNotebooksTable()
	{
		
	}
}
