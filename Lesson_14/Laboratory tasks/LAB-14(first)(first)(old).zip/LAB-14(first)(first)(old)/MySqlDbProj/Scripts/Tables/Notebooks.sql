CREATE TABLE notebooks_db.notebooks
(
	id INTEGER AUTO_INCREMENT,
	name VARCHAR(64) NOT NULL,
	pages_number SMALLINT NOT NULL,
	manf_name VARCHAR(64) NOT NULL,
	manf_country VARCHAR(64) NOT NULL,
	wrapper_softness TINYINT NOT NULL,
	wrapper_texture TINYINT NOT NULL,
	
	PRIMARY KEY (id),
	
	CHECK (name <> ''),
	CHECK (pages_number > 0),
	CHECK (manf_name <> ''),
	CHECK (manf_country <> ''),
	CHECK (wrapper_softness >= 0),
	CHECK (wrapper_texture >= 0)
)