SELECT *
FROM notebooks
WHERE wrapper_softness = 2