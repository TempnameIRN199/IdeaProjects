SELECT manf_country
FROM notebooks
GROUP BY manf_country
ORDER BY COUNT(*) ASC
LIMIT 1