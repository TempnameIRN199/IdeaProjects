SELECT manf_name
FROM notebooks
GROUP BY manf_name
ORDER BY COUNT(*) ASC
LIMIT 1