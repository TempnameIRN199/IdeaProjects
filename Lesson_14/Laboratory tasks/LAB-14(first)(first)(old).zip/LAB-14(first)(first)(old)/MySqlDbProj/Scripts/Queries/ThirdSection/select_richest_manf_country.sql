SELECT notebooks.manf_country
FROM notebooks_db.notebooks
GROUP BY notebooks.manf_country
ORDER BY COUNT(*) DESC
LIMIT 1