SELECT notebooks.manf_name, COUNT(*) AS "number"
FROM notebooks_db.notebooks
GROUP BY notebooks.manf_name
