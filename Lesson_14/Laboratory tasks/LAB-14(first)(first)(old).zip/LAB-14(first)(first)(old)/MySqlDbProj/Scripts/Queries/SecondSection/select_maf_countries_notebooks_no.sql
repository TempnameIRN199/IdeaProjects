SELECT notebooks.manf_country, COUNT(*) AS "number"
FROM notebooks_db.notebooks
GROUP BY notebooks.manf_country