SELECT *
FROM notebooks
WHERE wrapper_softness = 1
