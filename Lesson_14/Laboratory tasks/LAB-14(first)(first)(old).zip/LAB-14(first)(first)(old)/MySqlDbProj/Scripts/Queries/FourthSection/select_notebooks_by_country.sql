SELECT *
FROM notebooks
WHERE manf_country = ""