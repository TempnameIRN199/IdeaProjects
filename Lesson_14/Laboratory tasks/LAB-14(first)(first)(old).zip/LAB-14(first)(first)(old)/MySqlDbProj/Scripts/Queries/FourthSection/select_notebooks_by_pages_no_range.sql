SELECT *
FROM notebooks
WHERE pages_number BETWEEN 60 AND 200
