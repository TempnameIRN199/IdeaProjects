INSERT INTO notebooks 
(name, pages_number, manf_name, manf_country, wrapper_softness, wrapper_texture)
VALUES
("", 1, "", "", 1, 1)