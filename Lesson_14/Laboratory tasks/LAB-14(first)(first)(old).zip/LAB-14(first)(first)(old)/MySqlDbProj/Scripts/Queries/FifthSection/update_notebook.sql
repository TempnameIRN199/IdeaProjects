UPDATE notebooks
SET name = "SomeName", pages_number = 200
WHERE id = 1