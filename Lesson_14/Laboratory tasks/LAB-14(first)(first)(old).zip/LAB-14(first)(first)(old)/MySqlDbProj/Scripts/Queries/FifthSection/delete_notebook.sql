DELETE FROM notebooks
WHERE id = 1