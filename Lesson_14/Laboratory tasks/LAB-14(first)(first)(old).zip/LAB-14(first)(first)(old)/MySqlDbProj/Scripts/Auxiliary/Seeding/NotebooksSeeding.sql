INSERT INTO notebooks_db.notebooks (name, pages_number, manf_name, manf_country, wrapper_softness, wrapper_texture)
VALUES 
('Classic Notebook', 200, 'Notebook Co.', 'USA', 3, 5),
('Student Journal', 100, 'EduPrints Ltd.', 'UK', 2, 4),
('Leather Bound Notebook', 150, 'Crafted Notes', 'Italy', 4, 6),
('Hardcover Notebook', 120, 'Paper Masters', 'Germany', 3, 7),
('Eco Friendly Notebook', 80, 'GreenWrites', 'India', 1, 3),
('Art Sketchbook', 50, 'Canvas Pages', 'France', 2, 4),
('Spiral Notebook', 180, 'SpinWrites', 'USA', 2, 3),
('Executive Planner', 220, 'PlannerPro', 'Canada', 5, 8),
('Pocket Notebook', 60, 'TinyNotes', 'Japan', 1, 2),
('Grid Paper Notebook', 140, 'GraphLine', 'UK', 3, 5),
('Lined Notebook', 90, 'SimpleNotes', 'India', 2, 3),
('Premium Notebook', 250, 'ElitePages', 'Italy', 4, 7),
('Writable Journal', 180, 'ScriptEasy', 'Australia', 3, 5),
('Softcover Notebook', 100, 'LightNotes', 'Mexico', 2, 4),
('Minimalist Notebook', 75, 'BarePages', 'Sweden', 2, 3);