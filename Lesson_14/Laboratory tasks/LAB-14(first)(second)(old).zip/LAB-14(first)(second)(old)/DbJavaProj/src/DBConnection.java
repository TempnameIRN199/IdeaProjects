import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/";
    private static final String USER = "root";  // Your MySQL username
    private static final String PASSWORD = "";  // Your MySQL password
    private static final String DB_NAME = "notebooks_db";  // Name of the database

    // Method to connect to the database
    public static Connection connect() throws SQLException {
        // Create a connection to MySQL server (without a specific database)
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        createDatabaseAndTableIfNotExists(conn);
        return DriverManager.getConnection(URL + DB_NAME, USER, PASSWORD);
    }

    // Method to disconnect from the database
    public static void disconnect(Connection connection) throws SQLException {
        if (connection != null) {
            connection.close();
        }
    }

    // Creates the database and table if they do not exist
    private static void createDatabaseAndTableIfNotExists(Connection conn) throws SQLException {
        // Create the database if it doesn't exist
        try (Statement stmt = conn.createStatement()) {
            String createDatabaseQuery = "CREATE DATABASE IF NOT EXISTS " + DB_NAME;
            stmt.executeUpdate(createDatabaseQuery);

            // Switch to the target database
            conn.setCatalog(DB_NAME);

            // Create the table if it doesn't exist
            String createTableQuery = "CREATE TABLE IF NOT EXISTS notebooks (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "manufacturer VARCHAR(100), " +
                    "notebook_name VARCHAR(100), " +
                    "pages INT, " +
                    "cover_type VARCHAR(20), " +
                    "country VARCHAR(100), " +
                    "page_appearance VARCHAR(50)" +
                    ")";
            stmt.executeUpdate(createTableQuery);
        }
    }
}