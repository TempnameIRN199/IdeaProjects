import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NotebookDAO {

    // Fetch all notebooks from the database
    public List<Notebook> getAllNotebooks() throws SQLException {
        List<Notebook> notebooks = new ArrayList<>();
        String query = "SELECT * FROM notebooks";

        try (Connection conn = DBConnection.connect(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                notebooks.add(new Notebook(
                        rs.getInt("id"),
                        rs.getString("manufacturer"),
                        rs.getString("notebook_name"),
                        rs.getInt("pages"),
                        rs.getString("cover_type"),
                        rs.getString("country"),
                        rs.getString("page_appearance")
                ));
            }
        }
        return notebooks;
    }

    // Fetch unique countries from the database
    public List<String> getAllCountries() throws SQLException {
        List<String> countries = new ArrayList<>();
        String query = "SELECT DISTINCT country FROM notebooks";

        try (Connection conn = DBConnection.connect(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                countries.add(rs.getString("country"));
            }
        }
        return countries;
    }

    // Count notebooks by country
    public List<Object[]> getNotebookCountByCountry() throws SQLException {
        List<Object[]> counts = new ArrayList<>();
        String query = "SELECT country, COUNT(*) FROM notebooks GROUP BY country";

        try (Connection conn = DBConnection.connect(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                counts.add(new Object[] { rs.getString("country"), rs.getInt(2) });
            }
        }
        return counts;
    }

    // Count notebooks by manufacturer
    public List<Object[]> getNotebookCountByManufacturer() throws SQLException {
        List<Object[]> counts = new ArrayList<>();
        String query = "SELECT manufacturer, COUNT(*) FROM notebooks GROUP BY manufacturer";

        try (Connection conn = DBConnection.connect(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                counts.add(new Object[] { rs.getString("manufacturer"), rs.getInt(2) });
            }
        }
        return counts;
    }

    // Insert a notebook into the database
    public void insertNotebook(Notebook notebook) throws SQLException {
        String query = "INSERT INTO notebooks (manufacturer, notebook_name, pages, cover_type, country, page_appearance) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.connect(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, notebook.getManufacturer());
            pstmt.setString(2, notebook.getNotebookName());
            pstmt.setInt(3, notebook.getPages());
            pstmt.setString(4, notebook.getCoverType());
            pstmt.setString(5, notebook.getCountry());
            pstmt.setString(6, notebook.getPageAppearance());
            pstmt.executeUpdate();
        }
    }

    // Delete a notebook by ID
    public void deleteNotebook(int id) throws SQLException {
        String query = "DELETE FROM notebooks WHERE id = ?";

        try (Connection conn = DBConnection.connect(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }

    // Update a notebook by ID
    public void updateNotebook(Notebook notebook) throws SQLException {
        String query = "UPDATE notebooks SET manufacturer = ?, notebook_name = ?, pages = ?, cover_type = ?, country = ?, page_appearance = ? WHERE id = ?";

        try (Connection conn = DBConnection.connect(); PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, notebook.getManufacturer());
            pstmt.setString(2, notebook.getNotebookName());
            pstmt.setInt(3, notebook.getPages());
            pstmt.setString(4, notebook.getCoverType());
            pstmt.setString(5, notebook.getCountry());
            pstmt.setString(6, notebook.getPageAppearance());
            pstmt.setInt(7, notebook.getId());
            pstmt.executeUpdate();
        }
    }
}