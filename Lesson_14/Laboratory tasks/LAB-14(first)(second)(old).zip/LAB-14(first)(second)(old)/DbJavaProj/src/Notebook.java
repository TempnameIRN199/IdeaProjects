Nopublic class Notebook {

    private int id;
    private String manufacturer;
    private String notebookName;
    private int pages;
    private String coverType;
    private String country;
    private String pageAppearance;

    // Constructor
    public Notebook(int id, String manufacturer, String notebookName, int pages, String coverType, String country, String pageAppearance) {
        this.id = id;
        this.manufacturer = manufacturer;
        this.notebookName = notebookName;
        this.pages = pages;
        this.coverType = coverType;
        this.country = country;
        this.pageAppearance = pageAppearance;
    }

    // Getters and setters
    public int getId() { return id; }
    public String getManufacturer() { return manufacturer; }
    public String getNotebookName() { return notebookName; }
    public int getPages() { return pages; }
    public String getCoverType() { return coverType; }
    public String getCountry() { return country; }
    public String getPageAppearance() { return pageAppearance; }

    @Override
    public String toString() {
        return "ID: " + id + ", Manufacturer: " + manufacturer + ", Name: " + notebookName + ", Pages: " + pages +
                ", Cover Type: " + coverType + ", Country: " + country + ", Page Appearance: " + pageAppearance;
    }
}