import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        NotebookDAO notebookDAO = new NotebookDAO();

        try {
            // Ensure DB and table are created automatically
            System.out.println("Initializing database and tables...");
            DBConnection.connect();
            System.out.println("Database and tables are ready!");

            while (true) {
                System.out.println("\nPlease choose an option:");
                System.out.println("1. Show all notebooks");
                System.out.println("2. Show all countries");
                System.out.println("3. Show notebook count by country");
                System.out.println("4. Add a new notebook");
                System.out.println("5. Delete a notebook");
                System.out.println("6. Update a notebook");
                System.out.println("0. Exit");

                int choice = scanner.nextInt();
                scanner.nextLine();  // Consume the newline

                switch (choice) {
                    case 1:
                        showAllNotebooks(notebookDAO);
                        break;
                    case 2:
                        showAllCountries(notebookDAO);
                        break;
                    case 3:
                        showNotebookCountByCountry(notebookDAO);
                        break;
                    case 4:
                        addNotebook(scanner, notebookDAO);
                        break;
                    case 5:
                        deleteNotebook(scanner, notebookDAO);
                        break;
                    case 6:
                        updateNotebook(scanner, notebookDAO);
                        break;
                    case 0:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice, please try again.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }

    // Show all notebooks
    private static void showAllNotebooks(NotebookDAO notebookDAO) throws SQLException {
        List<Notebook> notebooks = notebookDAO.getAllNotebooks();
        for (Notebook notebook : notebooks) {
            System.out.println(notebook);
        }
    }

    // Show all countries
    private static void showAllCountries(NotebookDAO notebookDAO) throws SQLException {
        List<String> countries = notebookDAO.getAllCountries();
        for (String country : countries) {
            System.out.println(country);
        }
    }

    // Show notebook count by country
    private static void showNotebookCountByCountry(NotebookDAO notebookDAO) throws SQLException {
        List<Object[]> counts = notebookDAO.getNotebookCountByCountry();
        for (Object[] count : counts) {
            System.out.println("Country: " + count[0] + ", Count: " + count[1]);
        }
    }

    // Add a new notebook
    private static void addNotebook(Scanner scanner, NotebookDAO notebookDAO) {
        System.out.println("Enter manufacturer: ");
        String manufacturer = scanner.nextLine();

        System.out.println("Enter notebook name: ");
        String notebookName = scanner.nextLine();

        System.out.println("Enter pages: ");
        int pages = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.println("Enter cover type (hard/soft): ");
        String coverType = scanner.nextLine();

        System.out.println("Enter country: ");
        String country = scanner.nextLine();

        System.out.println("Enter page appearance (grid/ruled/plain): ");
        String pageAppearance = scanner.nextLine();

        Notebook notebook = new Notebook(0, manufacturer, notebookName, pages, coverType, country, pageAppearance);
        try {
            notebookDAO.insertNotebook(notebook);
            System.out.println("Notebook added successfully!");
        } catch (SQLException e) {
            System.out.println("Error adding notebook: " + e.getMessage());
        }
    }

    // Delete a notebook by ID
    private static void deleteNotebook(Scanner scanner, NotebookDAO notebookDAO) {
        System.out.println("Enter notebook ID to delete: ");
        int id = scanner.nextInt();

        try {
            notebookDAO.deleteNotebook(id);
            System.out.println("Notebook deleted successfully!");
        } catch (SQLException e) {
            System.out.println("Error deleting notebook: " + e.getMessage());
        }
    }

    // Update a notebook by ID
    private static void updateNotebook(Scanner scanner, NotebookDAO notebookDAO) {
        System.out.println("Enter notebook ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.println("Enter new manufacturer: ");
        String manufacturer = scanner.nextLine();

        System.out.println("Enter new notebook name: ");
        String notebookName = scanner.nextLine();

        System.out.println("Enter new pages: ");
        int pages = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.println("Enter new cover type (hard/soft): ");
        String coverType = scanner.nextLine();

        System.out.println("Enter new country: ");
        String country = scanner.nextLine();

        System.out.println("Enter new page appearance (grid/ruled/plain): ");
        String pageAppearance = scanner.nextLine();

        Notebook notebook = new Notebook(id, manufacturer, notebookName, pages, coverType, country, pageAppearance);
        try {
            notebookDAO.updateNotebook(notebook);
            System.out.println("Notebook updated successfully!");
        } catch (SQLException e) {
            System.out.println("Error updating notebook: " + e.getMessage());
        }
    }
}