import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NotebookDAO {

    // Insert notebook
    public static void insertNotebook(Connection conn, Notebook notebook) throws SQLException {
        String sql = "INSERT INTO notebooks (manufacturer, notebook_name, pages, cover_type, country, page_appearance) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, notebook.getManufacturer());
            pstmt.setString(2, notebook.getName());
            pstmt.setInt(3, notebook.getPages());
            pstmt.setString(4, notebook.getCoverType());
            pstmt.setString(5, notebook.getCountry());
            pstmt.setString(6, notebook.getPageAppearance());
            pstmt.executeUpdate();
        }
    }

    // Get all notebooks
    public static List<Notebook> getAllNotebooks(Connection conn) throws SQLException {
        List<Notebook> notebooks = new ArrayList<>();
        String sql = "SELECT * FROM notebooks";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                notebooks.add(new Notebook(
                        rs.getInt("id"),
                        rs.getString("manufacturer"),
                        rs.getString("notebook_name"),
                        rs.getInt("pages"),
                        rs.getString("cover_type"),
                        rs.getString("country"),
                        rs.getString("page_appearance")
                ));
            }
        }
        return notebooks;
    }

    // Delete notebook
    public static void deleteNotebook(Connection conn, int id) throws SQLException {
        String sql = "DELETE FROM notebooks WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }

    // Update notebook
    public static void updateNotebook(Connection conn, int id, Notebook notebook) throws SQLException {
        String sql = "UPDATE notebooks SET manufacturer = ?, notebook_name = ?, pages = ?, cover_type = ?, country = ?, page_appearance = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, notebook.getManufacturer());
            pstmt.setString(2, notebook.getName());
            pstmt.setInt(3, notebook.getPages());
            pstmt.setString(4, notebook.getCoverType());
            pstmt.setString(5, notebook.getCountry());
            pstmt.setString(6, notebook.getPageAppearance());
            pstmt.setInt(7, id);
            pstmt.executeUpdate();
        }
    }

    // Get all countries
    public static List<String> getAllCountries(Connection conn) throws SQLException {
        List<String> countries = new ArrayList<>();
        String sql = "SELECT DISTINCT country FROM notebooks";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                countries.add(rs.getString("country"));
            }
        }
        return countries;
    }

    // Get the number of notebooks per country
    public static void getNotebooksCountByCountry(Connection conn) throws SQLException {
        String sql = "SELECT country, COUNT(*) as count FROM notebooks GROUP BY country";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("Country: " + rs.getString("country") + " | Count: " + rs.getInt("count"));
            }
        }
    }

    // Country with the most notebooks
    public static void getCountryWithMostNotebooks(Connection conn) throws SQLException {
        String sql = "SELECT country, COUNT(*) as count FROM notebooks GROUP BY country ORDER BY count DESC LIMIT 1";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                System.out.println("Country with most notebooks: " + rs.getString("country"));
            }
        }
    }

    // Country with the least notebooks
    public static void getCountryWithLeastNotebooks(Connection conn) throws SQLException {
        String sql = "SELECT country, COUNT(*) as count FROM notebooks GROUP BY country ORDER BY count ASC LIMIT 1";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                System.out.println("Country with least notebooks: " + rs.getString("country"));
            }
        }
    }

    // Get notebooks with hard cover
    public static List<Notebook> getNotebooksWithHardCover(Connection conn) throws SQLException {
        List<Notebook> notebooks = new ArrayList<>();
        String sql = "SELECT * FROM notebooks WHERE cover_type = 'hard'";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                notebooks.add(new Notebook(
                        rs.getInt("id"),
                        rs.getString("manufacturer"),
                        rs.getString("notebook_name"),
                        rs.getInt("pages"),
                        rs.getString("cover_type"),
                        rs.getString("country"),
                        rs.getString("page_appearance")
                ));
            }
        }
        return notebooks;
    }

    // Get notebooks with soft cover
    public static List<Notebook> getNotebooksWithSoftCover(Connection conn) throws SQLException {
        List<Notebook> notebooks = new ArrayList<>();
        String sql = "SELECT * FROM notebooks WHERE cover_type = 'soft'";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                notebooks.add(new Notebook(
                        rs.getInt("id"),
                        rs.getString("manufacturer"),
                        rs.getString("notebook_name"),
                        rs.getInt("pages"),
                        rs.getString("cover_type"),
                        rs.getString("country"),
                        rs.getString("page_appearance")
                ));
            }
        }
        return notebooks;
    }

    // Filter by page appearance
    public static List<Notebook> filterNotebooksByAppearance(Connection conn, String appearance) throws SQLException {
        List<Notebook> notebooks = new ArrayList<>();
        String sql = "SELECT * FROM notebooks WHERE page_appearance = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, appearance);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    notebooks.add(new Notebook(
                            rs.getInt("id"),
                            rs.getString("manufacturer"),
                            rs.getString("notebook_name"),
                            rs.getInt("pages"),
                            rs.getString("cover_type"),
                            rs.getString("country"),
                            rs.getString("page_appearance")
                    ));
                }
            }
        }
        return notebooks;
    }

    // Filter by page count
    public static List<Notebook> filterNotebooksByPages(Connection conn, int minPages) throws SQLException {
        List<Notebook> notebooks = new ArrayList<>();
        String sql = "SELECT * FROM notebooks WHERE pages >= ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, minPages);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    notebooks.add(new Notebook(
                            rs.getInt("id"),
                            rs.getString("manufacturer"),
                            rs.getString("notebook_name"),
                            rs.getInt("pages"),
                            rs.getString("cover_type"),
                            rs.getString("country"),
                            rs.getString("page_appearance")
                    ));
                }
            }
        }
        return notebooks;
    }
}