import java.sql.Connection;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Connection conn = DBConnection.connect(); Scanner scanner = new Scanner(System.in)) {
            System.out.println("Notebook Database Initialized!");

            while (true) {
                System.out.println("\nSelect an option:");
                System.out.println("1. Add Notebook");
                System.out.println("2. View All Notebooks");
                System.out.println("3. Delete Notebook");
                System.out.println("4. Update Notebook");
                System.out.println("5. Get Notebooks by Cover Type");
                System.out.println("6. Filter Notebooks by Pages");
                System.out.println("7. Get Notebooks Count per Country");
                System.out.println("8. Get Country with Most Notebooks");
                System.out.println("9. Get Country with Least Notebooks");
                System.out.println("10. Exit");
                System.out.print("Your choice: ");

                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1 -> {
                        System.out.print("Enter Manufacturer: ");
                        String manufacturer = scanner.nextLine();
                        System.out.print("Enter Notebook Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter Page Count: ");
                        int pages = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Cover Type (hard/soft): ");
                        String coverType = scanner.nextLine();
                        System.out.print("Enter Country: ");
                        String country = scanner.nextLine();
                        System.out.print("Enter Page Appearance (grid/lined/plain): ");
                        String pageAppearance = scanner.nextLine();

                        Notebook notebook = new Notebook(0, manufacturer, name, pages, coverType, country, pageAppearance);
                        NotebookDAO.insertNotebook(conn, notebook);
                        System.out.println("Notebook added successfully!");
                    }
                    case 2 -> NotebookDAO.getAllNotebooks(conn).forEach(System.out::println);
                    case 3 -> {
                        System.out.print("Enter Notebook ID to delete: ");
                        int id = scanner.nextInt();
                        NotebookDAO.deleteNotebook(conn, id);
                        System.out.println("Notebook deleted.");
                    }
                    case 4 -> {
                        System.out.print("Enter Notebook ID to update: ");
                        int id = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter new Manufacturer: ");
                        String manufacturer = scanner.nextLine();
                        System.out.print("Enter new Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter new Page Count: ");
                        int pages = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter new Cover Type: ");
                        String coverType = scanner.nextLine();
                        System.out.print("Enter new Country: ");
                        String country = scanner.nextLine();
                        System.out.print("Enter new Page Appearance: ");
                        String pageAppearance = scanner.nextLine();
                        NotebookDAO.updateNotebook(conn, id, new Notebook(id, manufacturer, name, pages, coverType, country, pageAppearance));
                        System.out.println("Notebook updated.");
                    }
                    case 5 -> {
                        System.out.print("Enter Cover Type (hard/soft): ");
                        String coverType = scanner.nextLine();
                        NotebookDAO.getNotebooksWithHardCover(conn).forEach(System.out::println);
                    }
                    case 6 -> {
                        System.out.print("Enter Minimum Pages: ");
                        int minPages = scanner.nextInt();
                        NotebookDAO.filterNotebooksByPages(conn, minPages).forEach(System.out::println);
                    }
                    case 7 -> NotebookDAO.getNotebooksCountByCountry(conn);
                    case 8 -> NotebookDAO.getCountryWithMostNotebooks(conn);
                    case 9 -> NotebookDAO.getCountryWithLeastNotebooks(conn);
                    case 10 -> System.exit(0);
                    default -> System.out.println("Invalid option.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}