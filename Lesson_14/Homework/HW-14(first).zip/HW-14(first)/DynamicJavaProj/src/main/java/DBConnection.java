import java.sql.*;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/";
    private static final String DB_NAME = "avtomobili_db";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    // Connect to the database and ensure the database and table exist
    public static Connection connect() throws SQLException {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
        createDatabaseAndTable(conn);
        return DriverManager.getConnection(URL + DB_NAME, USER, PASSWORD);
    }

    // Disconnect from the database
    public static void disconnect(Connection conn) {
        try {
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Create the database and table if they don't exist
    private static void createDatabaseAndTable(Connection conn) throws SQLException {
        try (Statement stmt = conn.createStatement()) {
            // Create database if it doesn't exist
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS " + DB_NAME);
            stmt.executeUpdate("USE " + DB_NAME);

            // Create the 'cars' table if it doesn't exist
            String createTableSQL = "CREATE TABLE IF NOT EXISTS cars (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "manufacturer VARCHAR(100), " +
                    "car_name VARCHAR(100), " +
                    "engine_capacity DOUBLE, " +
                    "year INT, " +
                    "color VARCHAR(50), " +
                    "car_type ENUM('sedan', 'hatchback', 'wagon')" +
                    ")";
            stmt.executeUpdate(createTableSQL);
        }
    }
}