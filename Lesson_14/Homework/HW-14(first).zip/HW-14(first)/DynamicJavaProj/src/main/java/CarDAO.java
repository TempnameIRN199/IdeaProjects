import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CarDAO {

    // Insert a car into the database
    public static void insertCar(Connection conn, Car car) throws SQLException {
        String sql = "INSERT INTO cars (manufacturer, car_name, engine_capacity, year, color, car_type) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, car.getManufacturer());
            pstmt.setString(2, car.getCarName());
            pstmt.setDouble(3, car.getEngineCapacity());
            pstmt.setInt(4, car.getYear());
            pstmt.setString(5, car.getColor());
            pstmt.setString(6, car.getCarType());
            pstmt.executeUpdate();
        }
    }

    // Get all cars
    public static List<Car> getAllCars(Connection conn) throws SQLException {
        List<Car> cars = new ArrayList<>();
        String sql = "SELECT * FROM cars";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                cars.add(new Car(
                        rs.getInt("id"),
                        rs.getString("manufacturer"),
                        rs.getString("car_name"),
                        rs.getDouble("engine_capacity"),
                        rs.getInt("year"),
                        rs.getString("color"),
                        rs.getString("car_type")
                ));
            }
        }
        return cars;
    }

    // Get all car manufacturers
    public static List<String> getAllManufacturers(Connection conn) throws SQLException {
        List<String> manufacturers = new ArrayList<>();
        String sql = "SELECT DISTINCT manufacturer FROM cars";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                manufacturers.add(rs.getString("manufacturer"));
            }
        }
        return manufacturers;
    }

    // Get the number of cars per manufacturer
    public static void getCarCountByManufacturer(Connection conn) throws SQLException {
        String sql = "SELECT manufacturer, COUNT(*) AS count FROM cars GROUP BY manufacturer";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("Manufacturer: " + rs.getString("manufacturer") + " | Count: " + rs.getInt("count"));
            }
        }
    }

    // Get manufacturer with the most cars
    public static void getManufacturerWithMostCars(Connection conn) throws SQLException {
        String sql = "SELECT manufacturer, COUNT(*) AS count FROM cars GROUP BY manufacturer ORDER BY count DESC LIMIT 1";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                System.out.println("Manufacturer with most cars: " + rs.getString("manufacturer"));
            }
        }
    }

    // Get manufacturer with the least cars
    public static void getManufacturerWithLeastCars(Connection conn) throws SQLException {
        String sql = "SELECT manufacturer, COUNT(*) AS count FROM cars GROUP BY manufacturer ORDER BY count ASC LIMIT 1";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                System.out.println("Manufacturer with least cars: " + rs.getString("manufacturer"));
            }
        }
    }

    // Get all cars by a specific year
    public static List<Car> getCarsByYear(Connection conn, int year) throws SQLException {
        List<Car> cars = new ArrayList<>();
        String sql = "SELECT * FROM cars WHERE year = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, year);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    cars.add(new Car(
                            rs.getInt("id"),
                            rs.getString("manufacturer"),
                            rs.getString("car_name"),
                            rs.getDouble("engine_capacity"),
                            rs.getInt("year"),
                            rs.getString("color"),
                            rs.getString("car_type")
                    ));
                }
            }
        }
        return cars;
    }

    // Get cars within a year range
    public static List<Car> getCarsByYearRange(Connection conn, int startYear, int endYear) throws SQLException {
        List<Car> cars = new ArrayList<>();
        String sql = "SELECT * FROM cars WHERE year BETWEEN ? AND ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, startYear);
            pstmt.setInt(2, endYear);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    cars.add(new Car(
                            rs.getInt("id"),
                            rs.getString("manufacturer"),
                            rs.getString("car_name"),
                            rs.getDouble("engine_capacity"),
                            rs.getInt("year"),
                            rs.getString("color"),
                            rs.getString("car_type")
                    ));
                }
            }
        }
        return cars;
    }

    // Filter cars by color
    public static List<Car> filterCarsByColor(Connection conn, String color) throws SQLException {
        List<Car> cars = new ArrayList<>();
        String sql = "SELECT * FROM cars WHERE color = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, color);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    cars.add(new Car(
                            rs.getInt("id"),
                            rs.getString("manufacturer"),
                            rs.getString("car_name"),
                            rs.getDouble("engine_capacity"),
                            rs.getInt("year"),
                            rs.getString("color"),
                            rs.getString("car_type")
                    ));
                }
            }
        }
        return cars;
    }

    // Filter cars by engine capacity
    public static List<Car> filterCarsByEngineCapacity(Connection conn, double capacity) throws SQLException {
        List<Car> cars = new ArrayList<>();
        String sql = "SELECT * FROM cars WHERE engine_capacity >= ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDouble(1, capacity);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    cars.add(new Car(
                            rs.getInt("id"),
                            rs.getString("manufacturer"),
                            rs.getString("car_name"),
                            rs.getDouble("engine_capacity"),
                            rs.getInt("year"),
                            rs.getString("color"),
                            rs.getString("car_type")
                    ));
                }
            }
        }
        return cars;
    }

    // Filter cars by type
    public static List<Car> filterCarsByType(Connection conn, String type) throws SQLException {
        List<Car> cars = new ArrayList<>();
        String sql = "SELECT * FROM cars WHERE car_type = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, type);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    cars.add(new Car(
                            rs.getInt("id"),
                            rs.getString("manufacturer"),
                            rs.getString("car_name"),
                            rs.getDouble("engine_capacity"),
                            rs.getInt("year"),
                            rs.getString("color"),
                            rs.getString("car_type")
                    ));
                }
            }
        }
        return cars;
    }

    // Delete a car by ID
    public static void deleteCar(Connection conn, int id) throws SQLException {
        String sql = "DELETE FROM cars WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }

    // Update car details
    public static void updateCar(Connection conn, int id, Car car) throws SQLException {
        String sql = "UPDATE cars SET manufacturer = ?, car_name = ?, engine_capacity = ?, year = ?, color = ?, car_type = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, car.getManufacturer());
            pstmt.setString(2, car.getCarName());
            pstmt.setDouble(3, car.getEngineCapacity());
            pstmt.setInt(4, car.getYear());
            pstmt.setString(5, car.getColor());
            pstmt.setString(6, car.getCarType());
            pstmt.setInt(7, id);
            pstmt.executeUpdate();
        }
    }
}