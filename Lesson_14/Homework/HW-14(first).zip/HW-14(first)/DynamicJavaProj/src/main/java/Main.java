import java.sql.Connection;
import java.util.List;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args) {
        try (Connection conn = DBConnection.connect(); Scanner scanner = new Scanner(System.in)) {
            System.out.println("Car Database Initialized!");

            while (true) {
                System.out.println("\nSelect an option:");
                System.out.println("1. Add Car");
                System.out.println("2. View All Cars");
                System.out.println("3. View All Manufacturers");
                System.out.println("4. View Cars Count Per Manufacturer");
                System.out.println("5. View Manufacturer with Most Cars");
                System.out.println("6. View Manufacturer with Least Cars");
                System.out.println("7. View Cars by Year");
                System.out.println("8. View Cars by Year Range");
                System.out.println("9. View Cars by Color");
                System.out.println("10. View Cars by Engine Capacity");
                System.out.println("11. View Cars by Type");
                System.out.println("12. Delete Car");
                System.out.println("13. Update Car");
                System.out.println("14. Exit");

                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1 -> {
                        System.out.print("Enter Manufacturer: ");
                        String manufacturer = scanner.nextLine();
                        System.out.print("Enter Car Name: ");
                        String carName = scanner.nextLine();
                        System.out.print("Enter Engine Capacity: ");
                        double engineCapacity = scanner.nextDouble();
                        System.out.print("Enter Year: ");
                        int year = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        System.out.print("Enter Color: ");
                        String color = scanner.nextLine();
                        System.out.print("Enter Car Type (sedan/hatchback/wagon): ");
                        String carType = scanner.nextLine();

                        Car car = new Car(0, manufacturer, carName, engineCapacity, year, color, carType);
                        CarDAO.insertCar(conn, car);
                        System.out.println("Car added successfully!");
                    }
                    case 2 -> {
                        List<Car> cars = CarDAO.getAllCars(conn);
                        cars.forEach(System.out::println);
                    }
                    case 3 -> {
                        List<String> manufacturers = CarDAO.getAllManufacturers(conn);
                        manufacturers.forEach(System.out::println);
                    }
                    case 4 -> CarDAO.getCarCountByManufacturer(conn);
                    case 5 -> CarDAO.getManufacturerWithMostCars(conn);
                    case 6 -> CarDAO.getManufacturerWithLeastCars(conn);
                    case 7 -> {
                        System.out.print("Enter Year: ");
                        int year = scanner.nextInt();
                        List<Car> cars = CarDAO.getCarsByYear(conn, year);
                        cars.forEach(System.out::println);
                    }
                    case 8 -> {
                        System.out.print("Enter Start Year: ");
                        int startYear = scanner.nextInt();
                        System.out.print("Enter End Year: ");
                        int endYear = scanner.nextInt();
                        List<Car> cars = CarDAO.getCarsByYearRange(conn, startYear, endYear);
                        cars.forEach(System.out::println);
                    }
                    case 9 -> {
                        System.out.print("Enter Color: ");
                        String color = scanner.nextLine();
                        List<Car> cars = CarDAO.filterCarsByColor(conn, color);
                        cars.forEach(System.out::println);
                    }
                    case 10 -> {
                        System.out.print("Enter Minimum Engine Capacity: ");
                        double capacity = scanner.nextDouble();
                        List<Car> cars = CarDAO.filterCarsByEngineCapacity(conn, capacity);
                        cars.forEach(System.out::println);
                    }
                    case 11 -> {
                        System.out.print("Enter Car Type (sedan/hatchback/wagon): ");
                        String type = scanner.nextLine();
                        List<Car> cars = CarDAO.filterCarsByType(conn, type);
                        cars.forEach(System.out::println);
                    }
                    case 12 -> {
                        System.out.print("Enter Car ID to delete: ");
                        int id = scanner.nextInt();
                        CarDAO.deleteCar(conn, id);
                        System.out.println("Car deleted successfully!");
                    }
                    case 13 -> {
                        System.out.print("Enter Car ID to update: ");
                        int id = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        System.out.print("Enter Manufacturer: ");
                        String manufacturer = scanner.nextLine();
                        System.out.print("Enter Car Name: ");
                        String carName = scanner.nextLine();
                        System.out.print("Enter Engine Capacity: ");
                        double engineCapacity = scanner.nextDouble();
                        System.out.print("Enter Year: ");
                        int year = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        System.out.print("Enter Color: ");
                        String color = scanner.nextLine();
                        System.out.print("Enter Car Type (sedan/hatchback/wagon): ");
                        String carType = scanner.nextLine();

                        Car car = new Car(id, manufacturer, carName, engineCapacity, year, color, carType);
                        CarDAO.updateCar(conn, id, car);
                        System.out.println("Car updated successfully!");
                    }
                    case 14 -> System.exit(0);
                    default -> System.out.println("Invalid choice.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}