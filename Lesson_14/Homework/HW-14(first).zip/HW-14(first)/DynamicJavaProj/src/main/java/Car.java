public class Car {
    private int id;
    private String manufacturer;
    private String carName;
    private double engineCapacity;
    private int year;
    private String color;
    private String carType;

    public Car(int id, String manufacturer, String carName, double engineCapacity, int year, String color, String carType) {
        this.id = id;
        this.manufacturer = manufacturer;
        this.carName = carName;
        this.engineCapacity = engineCapacity;
        this.year = year;
        this.color = color;
        this.carType = carType;
    }

    public int getId() { return id; }
    public String getManufacturer() { return manufacturer; }
    public String getCarName() { return carName; }
    public double getEngineCapacity() { return engineCapacity; }
    public int getYear() { return year; }
    public String getColor() { return color; }
    public String getCarType() { return carType; }

    @Override
    public String toString() {
        return "Car{" +
                "id=" + id +
                ", manufacturer='" + manufacturer + '\'' +
                ", carName='" + carName + '\'' +
                ", engineCapacity=" + engineCapacity +
                ", year=" + year +
                ", color='" + color + '\'' +
                ", carType='" + carType + '\'' +
                '}';
    }
}