CREATE TABLE cars
(
	id INTEGER AUTO_INCREMENT,
	name VARCHAR(64) NOT NULL,
	color VARCHAR(64) NOT NULL,
	`type` TINYINT NOT NULL,
	engine_capacity FLOAT NOT NULL,
	manf_name VARCHAR(64) NOT NULL,
	issue_year SMALLINT NOT NULL,
	
	PRIMARY KEY (id),
	
	CHECK (name <> ""),
	CHECK (color <> ""),
	CHECK (`type` > 0),
	CHECK (engine_capacity > 0.0),
	CHECK (manf_name <> ""),
	CHECK (issue_year > 0)
)