SELECT *
FROM cars
WHERE color = "yellow"