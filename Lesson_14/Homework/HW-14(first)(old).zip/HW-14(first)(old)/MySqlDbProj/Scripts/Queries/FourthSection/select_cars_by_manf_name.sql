SELECT *
FROM cars
WHERE manf_name = "Ford"