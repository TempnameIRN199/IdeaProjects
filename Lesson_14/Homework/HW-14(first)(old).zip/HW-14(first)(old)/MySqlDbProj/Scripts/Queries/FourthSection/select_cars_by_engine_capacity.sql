SELECT *
FROM cars
WHERE engine_capacity BETWEEN 1.0 AND 1.8