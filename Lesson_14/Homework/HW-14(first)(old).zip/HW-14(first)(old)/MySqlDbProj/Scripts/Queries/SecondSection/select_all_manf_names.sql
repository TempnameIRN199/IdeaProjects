SELECT manf_name
FROM cars