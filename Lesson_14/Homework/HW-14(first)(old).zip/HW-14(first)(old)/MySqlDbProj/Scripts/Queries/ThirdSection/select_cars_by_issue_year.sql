SELECT *
FROM cars
WHERE issue_year = 2020
