SELECT manf_name, COUNT(*) AS number_of_cars
FROM cars
GROUP BY manf_name
ORDER BY COUNT(*) ASC
LIMIT 1