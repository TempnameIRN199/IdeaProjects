UPDATE cars
SET name = "MyName"
WHERE id = 59