INSERT INTO cars (name, color, `type`, engine_capacity, manf_name, issue_year)
VALUES
("", "", 1, 1.8, "", 2005)