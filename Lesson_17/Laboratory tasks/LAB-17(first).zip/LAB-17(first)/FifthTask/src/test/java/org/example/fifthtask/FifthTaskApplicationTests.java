package org.example.fifthtask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FifthTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
