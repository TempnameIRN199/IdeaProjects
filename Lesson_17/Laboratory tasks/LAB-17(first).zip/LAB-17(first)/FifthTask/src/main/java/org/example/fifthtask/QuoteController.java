package org.example.fifthtask;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RestController
public class QuoteController
{

    private final Random random = new Random();

    // A list of quotes with their categories and authors
    private final List<Quote> quotes = Arrays.asList(
            new Quote("Education is the most powerful weapon which you can use to change the world.", "Nelson Mandela", "Education"),
            new Quote("The only way to do great work is to love what you do.", "Steve Jobs", "Technology"),
            new Quote("Success is not the key to happiness. Happiness is the key to success.", "Albert Schweitzer", "Life"),
            new Quote("In the middle of every difficulty lies opportunity.", "Albert Einstein", "Motivation"),
            new Quote("The purpose of our lives is to be happy.", "Dalai Lama", "Life"),
            new Quote("Your work is going to fill a large part of your life, and the only way to be truly satisfied is to do what you believe is great work.", "Steve Jobs", "Technology")
    );

    // Task 5: Return a random quote with author information
    @GetMapping("/random-quote")
    public Quote getRandomQuote() {
        return quotes.get(random.nextInt(quotes.size()));  // Return a random quote from the list
    }

    // Task 6: Return a random quote from a specified category
    @GetMapping("/random-quote-category")
    public Quote getRandomQuoteByCategory(@RequestParam String category) {
        // Filter the quotes by the specified category
        List<Quote> filteredQuotes = new ArrayList<>();
        for (Quote quote : quotes) {
            if (quote.getCategory().equalsIgnoreCase(category)) {
                filteredQuotes.add(quote);
            }
        }

        // If there are no quotes for the given category, return a message
        if (filteredQuotes.isEmpty()) {
            throw new IllegalArgumentException("No quotes found for the category: " + category);
        }

        // Return a random quote from the filtered list
        return filteredQuotes.get(random.nextInt(filteredQuotes.size()));
    }

    // Static inner class for Quote representation
    public static class Quote {
        private String text;
        private String author;
        private String category;

        // Constructor
        public Quote(String text, String author, String category) {
            this.text = text;
            this.author = author;
            this.category = category;
        }

        // Getters and Setters
        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public String getAuthor() {
            return author;
        }

        public void setAuthor(String author) {
            this.author = author;
        }

        public String getCategory() {
            return category;
        }

        public void setCategory(String category) {
            this.category = category;
        }
    }
}