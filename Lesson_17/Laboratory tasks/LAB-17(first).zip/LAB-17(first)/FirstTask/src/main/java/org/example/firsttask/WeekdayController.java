package org.example.firsttask;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Locale;

@RestController
public class WeekdayController {

    @GetMapping("/day-of-week")
    public String getDayOfWeek(@RequestParam(defaultValue = "en") String lang) {
        // Get the current day of the week
        DayOfWeek dayOfWeek = LocalDate.now().getDayOfWeek();

        // Set the Locale based on the language parameter
        Locale locale = new Locale(lang);

        // Return the current day of the week in the requested language
        return dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, locale);
    }
}