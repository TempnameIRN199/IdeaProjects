package org.example.firsttask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstTaskApplicationTests {

    @Test
    void contextLoads() {
    }

}
