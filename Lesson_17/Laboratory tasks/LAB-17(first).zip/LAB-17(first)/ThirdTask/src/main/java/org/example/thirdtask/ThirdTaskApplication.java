package org.example.thirdtask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThirdTaskApplication {

    public static void main(String[] args) {
        SpringApplication.run(ThirdTaskApplication.class, args);
    }

}
