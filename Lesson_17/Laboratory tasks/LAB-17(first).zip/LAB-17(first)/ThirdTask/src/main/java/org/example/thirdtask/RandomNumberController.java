package org.example.thirdtask;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Random;

@RestController
public class RandomNumberController {

    private final Random random = new Random();

    // Task 3: Return a random number
    @GetMapping("/random")
    public int getRandomNumber() {
        return random.nextInt();  // This returns a random number between Integer.MIN_VALUE and Integer.MAX_VALUE
    }

    // Task 4: Return a random number within a specified range
    @GetMapping("/random-in-range")
    public int getRandomNumberInRange(
            @RequestParam(defaultValue = "0") int min,  // Default minimum is 0
            @RequestParam(defaultValue = "100") int max  // Default maximum is 100
    ) {
        if (min >= max) {
            throw new IllegalArgumentException("Min value must be less than Max value.");
        }
        return random.nextInt((max - min) + 1) + min;  // Generates a number between min and max (inclusive)
    }
}