package org.example.springproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/fractions")
public class FractionController
{
    @Autowired
    private FractionService fractionService;

    // Endpoint to check if a fraction is valid
    @GetMapping("/validate")
    public boolean isValid(@RequestParam int numerator, @RequestParam int denominator) {
        Fraction fraction = new Fraction(numerator, denominator);
        return fractionService.isValid(fraction);
    }

    // Endpoint to simplify a fraction
    @GetMapping("/simplify")
    public Fraction simplify(@RequestParam int numerator, @RequestParam int denominator) {
        Fraction fraction = new Fraction(numerator, denominator);
        return fractionService.simplify(fraction);
    }

    // Endpoint to add two fractions
    @GetMapping("/add")
    public Fraction add(@RequestParam int numerator1, @RequestParam int denominator1,
                        @RequestParam int numerator2, @RequestParam int denominator2) {
        Fraction fraction1 = new Fraction(numerator1, denominator1);
        Fraction fraction2 = new Fraction(numerator2, denominator2);
        return fractionService.add(fraction1, fraction2);
    }

    // Endpoint to subtract two fractions
    @GetMapping("/subtract")
    public Fraction subtract(@RequestParam int numerator1, @RequestParam int denominator1,
                             @RequestParam int numerator2, @RequestParam int denominator2) {
        Fraction fraction1 = new Fraction(numerator1, denominator1);
        Fraction fraction2 = new Fraction(numerator2, denominator2);
        return fractionService.subtract(fraction1, fraction2);
    }

    // Endpoint to multiply two fractions
    @GetMapping("/multiply")
    public Fraction multiply(@RequestParam int numerator1, @RequestParam int denominator1,
                             @RequestParam int numerator2, @RequestParam int denominator2) {
        Fraction fraction1 = new Fraction(numerator1, denominator1);
        Fraction fraction2 = new Fraction(numerator2, denominator2);
        return fractionService.multiply(fraction1, fraction2);
    }

    // Endpoint to divide two fractions
    @GetMapping("/divide")
    public Fraction divide(@RequestParam int numerator1, @RequestParam int denominator1,
                           @RequestParam int numerator2, @RequestParam int denominator2) {
        Fraction fraction1 = new Fraction(numerator1, denominator1);
        Fraction fraction2 = new Fraction(numerator2, denominator2);
        return fractionService.divide(fraction1, fraction2);
    }
}