package org.example.springproject;

import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class FractionService {

    // Check if the fraction is valid
    public boolean isValid(Fraction fraction) {
        return fraction != null && fraction.isValid();
    }

    // Simplify a fraction by dividing both numerator and denominator by GCD
    public Fraction simplify(Fraction fraction) {
        int gcd = findGCD(fraction.getNumerator(), fraction.getDenominator());
        return new Fraction(fraction.getNumerator() / gcd, fraction.getDenominator() / gcd);
    }

    // Add two fractions
    public Fraction add(Fraction fraction1, Fraction fraction2) {
        int numerator = (fraction1.getNumerator() * fraction2.getDenominator()) +
                (fraction2.getNumerator() * fraction1.getDenominator());
        int denominator = fraction1.getDenominator() * fraction2.getDenominator();
        return simplify(new Fraction(numerator, denominator));
    }

    // Subtract two fractions
    public Fraction subtract(Fraction fraction1, Fraction fraction2) {
        int numerator = (fraction1.getNumerator() * fraction2.getDenominator()) -
                (fraction2.getNumerator() * fraction1.getDenominator());
        int denominator = fraction1.getDenominator() * fraction2.getDenominator();
        return simplify(new Fraction(numerator, denominator));
    }

    // Multiply two fractions
    public Fraction multiply(Fraction fraction1, Fraction fraction2) {
        int numerator = fraction1.getNumerator() * fraction2.getNumerator();
        int denominator = fraction1.getDenominator() * fraction2.getDenominator();
        return simplify(new Fraction(numerator, denominator));
    }

    // Divide two fractions
    public Fraction divide(Fraction fraction1, Fraction fraction2) {
        int numerator = fraction1.getNumerator() * fraction2.getDenominator();
        int denominator = fraction1.getDenominator() * fraction2.getNumerator();
        return simplify(new Fraction(numerator, denominator));
    }

    // Helper method to find the greatest common divisor
    private int findGCD(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
}