import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get file path from the user
        System.out.print("Enter the file path: ");
        String filePath = scanner.nextLine();

        processFile(filePath);
        scanner.close();
    }

    private static void processFile(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            int lineNumber = 1;
            int totalSum = 0;

            while ((line = reader.readLine()) != null) {
                // Convert the line into an array of integers
                String[] tokens = line.split("\\s+"); // Split by whitespace
                List<Integer> numbers = new ArrayList<>();

                for (String token : tokens) {
                    try {
                        numbers.add(Integer.parseInt(token));
                    } catch (NumberFormatException e) {
                        System.out.println("Skipping invalid number: " + token);
                    }
                }

                if (!numbers.isEmpty()) {
                    int max = Collections.max(numbers);
                    int min = Collections.min(numbers);
                    int sum = numbers.stream().mapToInt(Integer::intValue).sum();
                    totalSum += sum;

                    System.out.println("Array " + lineNumber + ": " + numbers);
                    System.out.println("Max: " + max + ", Min: " + min + ", Sum: " + sum);
                }
                lineNumber++;
            }

            System.out.println("Total sum of all arrays: " + totalSum);
        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found.");
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
    }
}
