import java.util.Scanner;
import java.io.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Corporation corporation = new Corporation();

        // Load employees from file
        System.out.print("Enter the file name to load employees: ");
        String fileName = scanner.nextLine();
        try {
            corporation.loadEmployeesFromFile(fileName);
        } catch (IOException e) {
            System.out.println("Error loading file. Starting with an empty list.");
        }

        boolean running = true;
        while (running) {
            System.out.println("\n1. Add Employee");
            System.out.println("2. Edit Employee");
            System.out.println("3. Delete Employee");
            System.out.println("4. Search Employee by Last Name");
            System.out.println("5. Display All Employees");
            System.out.println("6. Save to File");
            System.out.println("7. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter first name: ");
                    String firstName = scanner.nextLine();
                    System.out.print("Enter last name: ");
                    String lastName = scanner.nextLine();
                    System.out.print("Enter age: ");
                    int age = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter position: ");
                    String position = scanner.nextLine();
                    corporation.addEmployee(new Employee(firstName, lastName, age, position));
                    break;
                case 2:
                    System.out.print("Enter last name of employee to edit: ");
                    String editLastName = scanner.nextLine();
                    System.out.print("Enter new first name: ");
                    String newFirstName = scanner.nextLine();
                    System.out.print("Enter new last name: ");
                    String newLastName = scanner.nextLine();
                    System.out.print("Enter new age: ");
                    int newAge = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter new position: ");
                    String newPosition = scanner.nextLine();
                    corporation.editEmployee(editLastName, new Employee(newFirstName, newLastName, newAge, newPosition));
                    break;
                case 3:
                    System.out.print("Enter last name of employee to delete: ");
                    String deleteLastName = scanner.nextLine();
                    corporation.deleteEmployee(deleteLastName);
                    break;
                case 4:
                    System.out.print("Enter last name to search: ");
                    String searchLastName = scanner.nextLine();
                    Employee e = corporation.searchEmployeeByLastName(searchLastName);
                    if (e != null) {
                        System.out.println("Found: " + e);
                    } else {
                        System.out.println("Employee not found.");
                    }
                    break;
                case 5:
                    System.out.print("Enter first letter of last name to filter by: ");
                    char letter = scanner.nextLine().charAt(0);
                    var result = corporation.searchEmployeesByFirstLetter(letter);
                    result.forEach(System.out::println);
                    break;
                case 6:
                    System.out.print("Enter the file name to save employees: ");
                    String saveFileName = scanner.nextLine();
                    try {
                        corporation.saveEmployeesToFile(saveFileName);
                        System.out.println("Employees saved.");
                    } catch (IOException e1) {
                        System.out.println("Error saving employees.");
                    }
                    break;
                case 7:
                    // Save before exit
                    System.out.print("Enter file name to save employees before exiting: ");
                    String exitFileName = scanner.nextLine();
                    try {
                        corporation.saveEmployeesToFile(exitFileName);
                    } catch (IOException e1) {
                        System.out.println("Error saving employees.");
                    }
                    running = false;
                    break;
            }
        }

        scanner.close();
    }
}