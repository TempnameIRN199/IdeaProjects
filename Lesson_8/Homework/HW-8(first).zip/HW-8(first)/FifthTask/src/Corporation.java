import java.util.*;
import java.io.*;

public class Corporation {
    private List<Employee> employees;

    public Corporation() {
        employees = new ArrayList<>();
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public void editEmployee(String lastName, Employee newInfo) {
        for (Employee e : employees) {
            if (e.getLastName().equals(lastName)) {
                e.setFirstName(newInfo.getFirstName());
                e.setLastName(newInfo.getLastName());
                e.setAge(newInfo.getAge());
                e.setPosition(newInfo.getPosition());
                break;
            }
        }
    }

    public void deleteEmployee(String lastName) {
        employees.removeIf(e -> e.getLastName().equals(lastName));
    }

    public Employee searchEmployeeByLastName(String lastName) {
        for (Employee e : employees) {
            if (e.getLastName().equals(lastName)) {
                return e;
            }
        }
        return null;
    }

    public List<Employee> searchEmployeesByFirstLetter(char letter) {
        List<Employee> result = new ArrayList<>();
        for (Employee e : employees) {
            if (e.getLastName().charAt(0) == letter) {
                result.add(e);
            }
        }
        return result;
    }

    public void displayAllEmployees() {
        for (Employee e : employees) {
            System.out.println(e);
        }
    }

    public void saveEmployeesToFile(String fileName) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Employee e : employees) {
                writer.write(e.getFirstName() + "," + e.getLastName() + "," + e.getAge() + "," + e.getPosition());
                writer.newLine();
            }
        }
    }

    public void loadEmployeesFromFile(String fileName) throws IOException {
        employees.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                employees.add(new Employee(data[0], data[1], Integer.parseInt(data[2]), data[3]));
            }
        }
    }
}