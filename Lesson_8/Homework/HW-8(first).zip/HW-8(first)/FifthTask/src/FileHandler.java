import java.io.*;
import java.util.*;

public class FileHandler {
    public static void saveToFile(List<Employee> employees, String fileName) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Employee e : employees) {
                writer.write(e.getFirstName() + "," + e.getLastName() + "," + e.getAge() + "," + e.getPosition());
                writer.newLine();
            }
        }
    }

    public static List<Employee> loadFromFile(String fileName) throws IOException {
        List<Employee> employees = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                employees.add(new Employee(data[0], data[1], Integer.parseInt(data[2]), data[3]));
            }
        }
        return employees;
    }
}