import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get file paths from the user
        System.out.print("Enter path to first file: ");
        String filePath1 = scanner.nextLine();
        System.out.print("Enter path to second file: ");
        String filePath2 = scanner.nextLine();

        compareFiles(filePath1, filePath2);
        scanner.close();
    }

    private static void compareFiles(String file1, String file2) {
        try (BufferedReader reader1 = new BufferedReader(new FileReader(file1));
             BufferedReader reader2 = new BufferedReader(new FileReader(file2))) {

            String line1, line2;
            int lineNumber = 1;
            boolean filesMatch = true;

            while ((line1 = reader1.readLine()) != null & (line2 = reader2.readLine()) != null) {
                if (!line1.equals(line2)) {
                    System.out.println("Difference found at line " + lineNumber + ":");
                    System.out.println("File 1: " + line1);
                    System.out.println("File 2: " + line2);
                    filesMatch = false;
                }
                lineNumber++;
            }

            // Check for extra lines in either file
            while ((line1 = reader1.readLine()) != null) {
                System.out.println("Extra line in first file at line " + lineNumber + ": " + line1);
                filesMatch = false;
                lineNumber++;
            }

            while ((line2 = reader2.readLine()) != null) {
                System.out.println("Extra line in second file at line " + lineNumber + ": " + line2);
                filesMatch = false;
                lineNumber++;
            }

            if (filesMatch) {
                System.out.println("Files are identical.");
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: One or both files not found.");
        } catch (IOException e) {
            System.out.println("Error reading files: " + e.getMessage());
        }
    }
}
