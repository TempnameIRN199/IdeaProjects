import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get file path from the user
        System.out.print("Enter the file path: ");
        String filePath = scanner.nextLine();

        findLongestLine(filePath);
        scanner.close();
    }

    private static void findLongestLine(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String longestLine = "";
            String currentLine;
            int maxLength = 0;

            while ((currentLine = reader.readLine()) != null) {
                if (currentLine.length() > maxLength) {
                    maxLength = currentLine.length();
                    longestLine = currentLine;
                }
            }

            if (maxLength > 0) {
                System.out.println("Longest line length: " + maxLength);
                System.out.println("Longest line: " + longestLine);
            } else {
                System.out.println("The file is empty.");
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found.");
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
    }
}
