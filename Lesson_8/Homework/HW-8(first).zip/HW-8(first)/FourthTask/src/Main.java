import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get file path from the user
        System.out.print("Enter the file path: ");
        String filePath = scanner.nextLine();

        System.out.print("Enter integers separated by spaces: ");
        String[] tokens = scanner.nextLine().split("\\s+");
        List<Integer> numbers = new ArrayList<>();

        for (String token : tokens) {
            try {
                numbers.add(Integer.parseInt(token));
            } catch (NumberFormatException e) {
                System.out.println("Skipping invalid number: " + token);
            }
        }

        writeArraysToFile(filePath, numbers);
        scanner.close();
    }

    private static void writeArraysToFile(String filePath, List<Integer> numbers) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            List<Integer> evens = new ArrayList<>();
            List<Integer> odds = new ArrayList<>();
            List<Integer> reversed = new ArrayList<>(numbers);
            Collections.reverse(reversed);

            for (int num : numbers) {
                if (num % 2 == 0) {
                    evens.add(num);
                } else {
                    odds.add(num);
                }
            }

            writer.write(numbers.toString().replaceAll("[\\[\\],]", ""));
            writer.newLine();
            writer.write(evens.toString().replaceAll("[\\[\\],]", ""));
            writer.newLine();
            writer.write(odds.toString().replaceAll("[\\[\\],]", ""));
            writer.newLine();
            writer.write(reversed.toString().replaceAll("[\\[\\],]", ""));
            writer.newLine();

            System.out.println("Data successfully written to file.");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
}
