import services.FileSrvc;

public class Main
{
	public static void main(String[] args)
	{
		try
		{
			FileSrvc tmpFileSrvc = new FileSrvc
			(
				"C:\\Users\\Administrator\\Desktop\\FirstTxtDoc.txt",
				"C:\\Users\\Administrator\\Desktop\\SecondTxtDoc.txt"
			);
			
			System.out.print(tmpFileSrvc.compare());
		}
		catch (Exception exc)
		{
			System.out.print("ERR: " + exc.getMessage());
		}
	}
}
