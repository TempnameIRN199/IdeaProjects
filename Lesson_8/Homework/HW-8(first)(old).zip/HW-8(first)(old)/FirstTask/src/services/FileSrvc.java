package services;

import java.io.IOException;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;

import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

public final class FileSrvc
{
	private ArrayList<String> firstFileContent;
	private ArrayList<String> secondFileContent;
	
	public ArrayList<String> getFirstFileContent()
	{ return firstFileContent; }
	
	public ArrayList<String> getSecondFileContent()
	{ return secondFileContent; }
	
	public FileSrvc(String firstFilePath, String secondFilePath) throws IOException
	{
		firstFileContent = new ArrayList<String>();
		secondFileContent = new ArrayList<String>();
		
		read(firstFilePath, this.firstFileContent);
		read(secondFilePath, this.secondFileContent);
	}
	
	public Map<String, String> compare()
	{
		HashMap<String, String> map = new HashMap<String, String>();
		
		for (int counter = 0; counter < this.firstFileContent.size() && counter < this.secondFileContent.size(); counter++)
		{
			if (!this.firstFileContent.get(counter).equals(this.secondFileContent.get(counter)))
			{
				map.put(this.firstFileContent.get(counter), this.secondFileContent.get(counter));
			}
		}
		
		return map;
	}
	
	private void read(String filePath, ArrayList<String> tgtStorage) throws IOException
	{ Files.lines(Paths.get(filePath)).forEach((line) -> tgtStorage.add(line)); }
}
