import services.ArrayFileSrvc;

import java.util.Random;

import java.util.stream.IntStream;

import java.io.*;

public class Main
{
	public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException
	{
		ArrayFileSrvc currArrFileSrvc = new ArrayFileSrvc();
		int[] firstCurrArr = new int[10], secondCurrArr = new int[10];
		
		initArrRand(firstCurrArr, -20, 20 + 1);
		initArrRand(secondCurrArr, -20, 20 + 1);
		
		{
			currArrFileSrvc.setFilePath("C:\\Users\\Administrator\\Desktop\\FirstBinFile.bin");
			currArrFileSrvc.setArr(firstCurrArr);
			
			currArrFileSrvc.write();
			currArrFileSrvc.read();
			
			firstCurrArr = currArrFileSrvc.getArr();
			
			System.out.println("FIRST MIN: " + IntStream.of(firstCurrArr).min().getAsInt());
			System.out.println("FIRST MAX: " + IntStream.of(firstCurrArr).max().getAsInt());
			System.out.println("FIRST SUM: " + IntStream.of(firstCurrArr).sum());			
		}
		
		System.out.println();
		
		{
			currArrFileSrvc.setFilePath("C:\\Users\\Administrator\\Desktop\\SecondBinFile.bin");
			currArrFileSrvc.setArr(secondCurrArr);
			
			currArrFileSrvc.write();
			currArrFileSrvc.read();
			
			secondCurrArr = currArrFileSrvc.getArr();
			
			System.out.println("SECOND MIN: " + IntStream.of(secondCurrArr).min().getAsInt());
			System.out.println("SECOND MAX: " + IntStream.of(secondCurrArr).max().getAsInt());
			System.out.println("SECOND SUM: " + IntStream.of(secondCurrArr).sum());		
		}
		
		System.out.println();
		
		{
			System.out.println("TWO SUM: " + IntStream.concat(IntStream.of(firstCurrArr), IntStream.of(secondCurrArr)).sum());
		}
	}
	
	public static void initArrRand(int[] arr, int min, int max)
	{
		Random currRandom = new Random();
		
		for (int counter = 0; counter < arr.length; counter++)
		{
			arr[counter] = currRandom.nextInt(min, max);
		}
	}
}
