import utils.ArrayFileSrvc;

import java.util.Random;

import java.util.stream.IntStream;

import java.io.*;

public class Main
{
	public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException
	{
		ArrayFileSrvc currArrFileSrvc = new ArrayFileSrvc();
		int[] firstCurrArr = new int[10];
		
		initArrRand(firstCurrArr, -20, 20 + 1);
		
		{
			currArrFileSrvc.setFilePath("C:\\Users\\Administrator\\Desktop\\FirstBinFile.bin");
			currArrFileSrvc.setArr(firstCurrArr);
			
			currArrFileSrvc.write();
			
			System.out.println("RAW ARRAY - DONE");
		}
		
		{
			currArrFileSrvc.setFilePath("C:\\Users\\Administrator\\Desktop\\SecondBinFile.bin");
			currArrFileSrvc.setArr(IntStream.of(firstCurrArr).filter((val) -> val % 2 == 0).toArray());
			
			currArrFileSrvc.write();	
			
			System.out.println("EVEN ARRAY - DONE");
		}
		
		{
			currArrFileSrvc.setFilePath("C:\\Users\\Administrator\\Desktop\\ThirdBinFile.bin");
			currArrFileSrvc.setArr(IntStream.of(firstCurrArr).filter((val) -> val % 2 != 0).toArray());
			
			currArrFileSrvc.write();
			
			System.out.println("ODD ARRAY - DONE");
		}
		
		{
			currArrFileSrvc.setFilePath("C:\\Users\\Administrator\\Desktop\\FourthBinFile.bin");
			currArrFileSrvc.setArr(IntStream.range(0, firstCurrArr.length)
                    .map(i -> firstCurrArr[firstCurrArr.length - 1 - i])
                    .toArray());
			
			currArrFileSrvc.write();
			
			System.out.println("REVERSED ARRAY - DONE");
		}
	}
	
	public static void initArrRand(int[] arr, int min, int max)
	{
		Random currRandom = new Random();
		
		for (int counter = 0; counter < arr.length; counter++)
		{
			arr[counter] = currRandom.nextInt(min, max);
		}
	}
}
