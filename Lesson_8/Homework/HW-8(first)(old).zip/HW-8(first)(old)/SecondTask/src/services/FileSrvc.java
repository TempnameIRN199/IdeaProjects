package services;

import java.util.ArrayList;

import java.io.IOException;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;

import java.util.stream.Stream;

public final class FileSrvc
{
	private ArrayList<String> fileContent;
	
	public FileSrvc(String filePath) throws IOException
	{
		this.fileContent = new ArrayList<String>();
		
		read(filePath, this.fileContent);
	}
	
	public String getLongestLine()
	{
		return this.fileContent.stream().max
				((firstVal, secondVal) -> Integer.compare(firstVal.length(), secondVal.length())).get();
	}
	
	private void read(String filePath, ArrayList<String> tgtStorage) throws IOException
	{ Files.lines(Paths.get(filePath)).forEach((line) -> tgtStorage.add(line)); }
}
