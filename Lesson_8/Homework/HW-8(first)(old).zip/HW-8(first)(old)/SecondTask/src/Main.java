import services.FileSrvc;

public class Main
{
	public static void main(String[] args)
	{
		FileSrvc currFileSrvc = null;
		
		try
		{
			String tmpStrVar = "";
			
			currFileSrvc = new FileSrvc("C:\\Users\\Administrator\\Desktop\\FirstTxtDoc.txt");
			
			tmpStrVar = currFileSrvc.getLongestLine();
			
			System.out.print(tmpStrVar + " - " + tmpStrVar.length());
		}
		catch(Exception exc)
		{
			System.out.println("ERR: " + exc.getMessage());
		}
	}
}
